#ifndef ST_BRANCH_LEN_FINDER_H
#define ST_BRANCH_LEN_FINDER_H

#include "GeneSpeciesTreeProb.h"

// Problem: given a tree topology (with initial branch length), use hill climbing
// to find the best branch length that maximize the likelihood of the given trees

void SetNumThreads(int nt);
int GetNumThreads();
GenericGeneSpeciesTreeProb *CreateGeneTreeProbComp(MarginalTree &treeSpecies, PhylogenyTreeBasic &treeGene);

//////////////////////////////////////////////////////////////////////////////////
// Finding branch length that makes the likelihood as large as possible
// note: this is a hill-climbing search only (i.e. not necessarily optimal)

class STBranchLenFinder
{
public:
	STBranchLenFinder( const vector<PhylogenyTreeBasic *> &listGTreePtrs, 
		const MarginalTree &stInit, double minBranchLen, double maxBranchLen );
	~STBranchLenFinder();

	double HillClimbBranchLen( MarginalTree &treeRes );
	void SetHillClimbRatioThres(double pthres) { YW_ASSERT_INFO( pthres > 0.0, "Hill climbing ratio must be positive" );  logHillClimbRatio = log(pthres); }
	void SetMultiplictyofTrees(const vector<int> &vecMultis) { listGTreeMultiplicty = vecMultis;}
	void SetBrentMode(bool f) { fBrentMode = f; }
	void SetKnownMaxLikeli(double v) {  knownLikeliOtherTree = v; }
    void SetGeneTreeProbComp( vector<GenericGeneSpeciesTreeProb *> &listGSTProbFinderIn ) { listGSTProbFinder = listGSTProbFinderIn; }
    //void SetNumThreads(int nt) { numThreads = nt; }
    
private:
	// implementaiton methods
	void Init();
	void TweakEdgeLen(int branch);
	void OptEdgeLenSearchBrent(int branch, int iterationIndex);
	double TempIncEdgeLen(int branch, double lenNew, vector< map<int,set< LineageConfig,LTLinCfg > > >  &listOrigCfgsSaved );;
	void RestoreSavedCfgs( vector< map<int,set< LineageConfig,LTLinCfg > > >  &listOrigCfgsSaved);
	void UpdateSTBranchLen(int br, double lenNew);
	bool CanSkipEdge(int br);
	bool IsEdgeSkipped(int br) { YW_ASSERT_INFO( br<(int)listEdgeCheckFlags.size(), "Out of bound" ); return listEdgeCheckFlags[br]; }

	// numerical algorithm
	double Func1DMinBrent( int branch, double ax, double bx, double cx, double tol, double *xmin );
	double EvaluateAt(int br, double lenTest);
    
    // speedup code
    double TempIncEdgeLenMultithread(int branch, double lenNew, vector< map<int,set< LineageConfig,LTLinCfg > > >  &listOrigCfgsSaved);


	// private data
	vector<PhylogenyTreeBasic *> listGTreePtrs;
	vector<int> listGTreeMultiplicty;
	MarginalTree speciesTreeBest;
	vector<GenericGeneSpeciesTreeProb *> listGSTProbFinder;
	double loglikeliCurBest;
	double minBranchLen;
	double maxBranchLen;
	double gridBranchLen;
	double logHillClimbRatio;
	vector<bool> listEdgeCheckFlags;
	bool fBrentMode;
	vector< map<int,set< LineageConfig,LTLinCfg > > >  listOrigCfgsSavedBrentSearch;
	double knownLikeliOtherTree;
    //int numThreads;
};



//////////////////////////////////////////////////////////////////////////////////



#endif
