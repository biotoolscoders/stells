#ifndef NUMERICAL_UTILS_H
#define NUMERICAL_UTILS_H 

// utility functions for numerical algorithms

// Brent's method for minimizing an one-dimensional function
double Func1DMinBrent( double ax, double bx, double cx, double (*f)(double), double tol, double *xmin) );


#endif

