//
//  FastGeneTreeProb.cpp
//  
//
//  Created by Yufeng Wu on 7/8/15.
//
//

#include "FastGeneTreeProb.h"
#include "Utils4.h"

///////////////////////////////////////////////////////////////////////////////
// main class for computing gene tree prob on species tree w/ two taxa
// note: gene tree is allowed to be non-binary


FastGeneTreeProbTwoSpecies :: FastGeneTreeProbTwoSpecies(MarginalTree &ts, PhylogenyTreeBasic &tg) : treeSpecies(ts), treeGene(tg),
gstHelper(ts, tg)
{
    Check();
    Init();
	treeSpecies.BuildDescendantInfo();
}

double FastGeneTreeProbTwoSpecies :: CalcProb()
{
    // figure out the range of pair lineage setting at the species split
    int na1LB = infoFGPT.setMaximalSTRootsTaxa[0].size();
    int na2LB = infoFGPT.setMaximalSTRootsTaxa[1].size();
    double res = 0.0;
    for(int na1=na1LB; na1<=infoFGPT.numAlleleTaxa1; ++na1)
    {
        for(int na2=na2LB; na2<=infoFGPT.numAlleleTaxa2; ++na2)
        {
            res += CalcProbPairLinNums(na1,na2);
        }
    }
    return res;
}

void FastGeneTreeProbTwoSpecies :: Check()
{
    // ensure proper input: there are only two species
    YW_ASSERT_INFO(treeSpecies.GetNumLeaves() == 2, "Can only allow two species");

}

void FastGeneTreeProbTwoSpecies :: Init()
{
    // collect all node info
    vector<TreeNode *> listNodes;
    treeGene.GetAllNodes( listNodes );
    for(int i=0; i<(int)listNodes.size(); ++i)
    {
        int numIntNodes = listNodes[i]->GetNumNodesUnder(true, true);
//cout << "NumIntnodes: " << numIntNodes << " for node: ";
//listNodes[i]->Dump();
        FGTPT_SUBTREE_INFO nodeInfo;
        nodeInfo.numIntNodes = numIntNodes;
        mapGeneTreeInfo.insert( map<TreeNode *, FGTPT_SUBTREE_INFO> :: value_type( listNodes[i], nodeInfo ) );
    }
    
    int lbl1 = treeSpecies.GetLabel(0 );
    set<int> geneAlleles1;
    gstHelper.GetGeneAllelesForSpecies(lbl1, geneAlleles1);
    infoFGPT.numAlleleTaxa1 = geneAlleles1.size();
    int lbl2 = treeSpecies.GetLabel(1 );
    set<int> geneAlleles2;
    gstHelper.GetGeneAllelesForSpecies(lbl2, geneAlleles2);
    infoFGPT.numAlleleTaxa2 = geneAlleles2.size();
    
    infoFGPT.lenTaxa1Branch = treeSpecies.GetEdgeLen(0);
    infoFGPT.lenTaxa2Branch = treeSpecies.GetEdgeLen(1);
    
    // collect subtree info
    for(int ns=0; ns<=1; ++ns)
    {
        int lbl = treeSpecies.GetLabel(ns );
        set<int> geneAlleles;
        gstHelper.GetGeneAllelesForSpecies(lbl, geneAlleles);
        
        // find all nodes
        set<TreeNode *> setLeaves;
        gstHelper.GetNodesForIds(geneAlleles, setLeaves);
        
        // find all the subtrees clustered
        set< set<TreeNode *> > setSubtreeClades;
        treeGene.FindCladeOfSubsetLeavesExact( setLeaves, setSubtreeClades );
        set< set<TreeNode *> > setSubtreeCladesMaximal;
        PhylogenyTreeBasic :: GroupLeavesToSubtrees( setLeaves,  setSubtreeClades, setSubtreeCladesMaximal);
        
        // collect all roots
       // vector<TreeNode *> listSubtreeRoots;
        for( set<set<TreeNode *> > :: iterator it = setSubtreeCladesMaximal.begin(); it != setSubtreeCladesMaximal.end(); ++it )
        {
            TreeNode *pp = treeGene.GetSubtreeRootForLeaves( *it );
            //listSubtreeRoots.push_back(pp);
            infoFGPT.setMaximalSTRootsTaxa[ns].insert(pp);
        }
        YW_ASSERT_INFO(infoFGPT.setMaximalSTRootsTaxa[ns].size() > 0, "List of uniform subtrees: empty");
        //PopulateSetByVecGen( infoFGPT.setMaximalSTRootsTaxa[ns], listSubtreeRoots );
    }

    // save the maximal version for now
    infoFGPT.setAllUniformSTRootsTaxa[0] = infoFGPT.setMaximalSTRootsTaxa[0];
	infoFGPT.setAllUniformSTRootsTaxa[1] = infoFGPT.setMaximalSTRootsTaxa[1];

    // also list the nodes of all internal nodes of maximal subtrees as roots of (non-maximal) uniform subtrees
    for(int ns=0; ns<=1; ++ns)
    {
      set<TreeNode *> resSetTemp;
      for( set<TreeNode *> :: iterator it1 = infoFGPT.setMaximalSTRootsTaxa[ns].begin(); it1 != infoFGPT.setMaximalSTRootsTaxa[ns].end(); ++it1)
      {
        set<TreeNode *> setDesc;
        (*it1)->GetAllDescendents(setDesc);
        for( set<TreeNode *> :: iterator it2 = setDesc.begin(); it2 != setDesc.end(); ++it2)
        {
          if( (*it2)->IsLeaf() == false )
          {
            resSetTemp.insert( *it2 );
          }
        }
      }
      // inc the newly found subtree roots
      UnionSetsGen(infoFGPT.setAllUniformSTRootsTaxa[ns], resSetTemp);
    }

    // also figure out the nummber of allowed coalescents (of two types) for each node
    vector<TreeNode *> listAllGTNodes;
    treeGene.GetAllNodes(listAllGTNodes);
    for(int i=0; i<(int)listAllGTNodes.size(); ++i)
    {
        pair<int,int> pp;
        pp.first = 0;
        pp.second = 0;

        // if it is maximal subtrees
        if( listAllGTNodes[i]->IsLeaf() == false )
        {
          set<TreeNode *> ss;
          listAllGTNodes[i]->GetAllLeavesUnder(ss);
          
	     if(  infoFGPT.setAllUniformSTRootsTaxa[0].find(listAllGTNodes[i]) != infoFGPT.setAllUniformSTRootsTaxa[0].end() )
          {
            pp.first = (int)ss.size()-1;
          }
          else if( infoFGPT.setAllUniformSTRootsTaxa[1].find(listAllGTNodes[i]) != infoFGPT.setAllUniformSTRootsTaxa[1].end() )
          {
            pp.second = (int)ss.size()-1;
          }
          else
          {
            // get all descendent nodes
            set<TreeNode *> setDesc;
            listAllGTNodes[i]->GetAllDescendents(setDesc);

            for( set<TreeNode *> :: iterator it = setDesc.begin(); it != setDesc.end(); ++it )
            {
              if( infoFGPT.setMaximalSTRootsTaxa[0].find(*it) != infoFGPT.setMaximalSTRootsTaxa[0].end() )
              {
                pp.first += GetNumCoalsUnder( *it, true );
              }
              else if( infoFGPT.setMaximalSTRootsTaxa[1].find(*it) != infoFGPT.setMaximalSTRootsTaxa[1].end() )
              {
                pp.second += GetNumCoalsUnder( *it, true );
              }
            }
          }
        }
        infoFGPT.mapNumCoalEvtsForNode.insert( map<TreeNode *, pair<int,int> > :: value_type(listAllGTNodes[i], pp) );
        
//cout << "Number of possible gene tree events of two types: " << pp.first << "," << pp.second;
//cout << " for gene tree node: ";
//listAllGTNodes[i]->Dump();
//    cout << endl;
    }
}

// calc prob for a particular lineage number settings (n1,n2)
double FastGeneTreeProbTwoSpecies :: CalcProbPairLinNums(int na1, int na2)
{
//cout << "CalcProbPairLinNums: na1: " << na1 << ", na2: " << na2 << endl;
//cout << "NumAllele1: " << infoFGPT.numAlleleTaxa1 << ", numAllele2: " << infoFGPT.numAlleleTaxa2 << endl;
//cout << "Branch lengths: " << infoFGPT.lenTaxa1Branch << ", " << infoFGPT.lenTaxa2Branch << endl;
    //
    double puv1 = gstHelper.CalcCoalProbBranch( infoFGPT.numAlleleTaxa1, na1, infoFGPT.lenTaxa1Branch );
    double puv2 = gstHelper.CalcCoalProbBranch( infoFGPT.numAlleleTaxa2, na2, infoFGPT.lenTaxa2Branch );
    double coeffTot = CalcCoeffPairLinNums( na1, na2 );
//cout << "puv1: " << puv1 << ", puv2: " << puv2 << ", ceoffTot: " << coeffTot << endl;
    double res= puv1*puv2*coeffTot;
    return res;
}

// calc coefficient of a particular lineage number settings (n1,n2)
double FastGeneTreeProbTwoSpecies :: CalcCoeffPairLinNums(int na1, int na2)
{
    // coefficient for AC(na1,na2) where na1=num of ancestral lineages of species 1 right at speciation
    // these are denominator terms
    double cd1 = gstHelper.CalcdbVal( infoFGPT.numAlleleTaxa1, infoFGPT.numAlleleTaxa1-na1 );
    double cd2 = gstHelper.CalcdbVal( infoFGPT.numAlleleTaxa2, infoFGPT.numAlleleTaxa2-na2 );
    double cd3 = gstHelper.CalcdbVal( na1+na2, na1+na2-1);
    // factorial terms 
    double c1Low1 = CalcProductBetween( 1, infoFGPT.numAlleleTaxa1- na1 );
    double c1Low2 = CalcProductBetween( 1, infoFGPT.numAlleleTaxa2- na2 );
    double c1Upper = CalcProductBetween( 1, na1+na2-1 );

    // coefficient terms which contains both lower and upper
    double c2 = CalcFacWbRatioForLinNums(na1,na2);
//cout << "CalcCoeffPairLinNums: na1: " << na1 << ", na2: " << na2 << ", cd1: " << cd1 << ", cd2: " << cd2 << ", cd3: " << cd3 << ", c1Low1: " << c1Low1 << ", c1Low2: " << c1Low2 << ", c1Upper: " << c1Upper << ", c2: " << c2 << endl;
    return c1Low1*c1Low2*c1Upper*c2/(cd1*cd2*cd3);
}

// calc factor ratio for entire tree conditional on the lineage number settings
double FastGeneTreeProbTwoSpecies :: CalcFacWbRatioForLinNums(int na1,int na2)
{
    //
    int coalTaxa1 = infoFGPT.numAlleleTaxa1-na1;
    int coalTaxa2 = infoFGPT.numAlleleTaxa2-na2;
    return CalcFacWbRatioForSpeciesAtNode(treeGene.GetRoot(), coalTaxa1, coalTaxa2);
}

double FastGeneTreeProbTwoSpecies :: CalcFacWbRatioForSpeciesAtNode(TreeNode *pnSTNode, int coalTaxa1, int coalTaxa2)
{
    // sum of all possible wb factors accumulated at the subtree rooted at pnSTNode, s.t.
    // the number of taxa1 coalescents = coalTaxa1 and number of taxa2 coalescents = coalTaxa2
    // Note: pnSTNode is above any maximal subtrees
    // first, at the subtree root, computes the factor 1/(num of coalescents below it in the root branch)
//cout << "****** CalcFacWbRatioForSpeciesAtNode: nodeid<" << pnSTNode->GetID() << ">: coalTaxa1:" << coalTaxa1 << ", coalTaxa2: " << coalTaxa2 << endl;
    
	// if there is coalescent to do, early return
	if( coalTaxa1+coalTaxa2==0)
	{
		// the whole subtree will be coalesced in the root branch in this case
		if( pnSTNode->IsLeaf() == false )
		{
			//
			int numCoalsUnder = GetNumCoalsUnder(pnSTNode, true);
			double resDir = CalcFacWbRatioComboForSubtree( pnSTNode, numCoalsUnder );
//cout << "------<EARLY RETURN: coalesce the whole subtree> CalcFacWbRatioForSpeciesAtNode: nodeid<" << pnSTNode->GetID() << ">: coalTaxa1:" << coalTaxa1 << ", coalTaxa2: " << coalTaxa2 << ", resDir = " << resDir << endl;
			return resDir;
		}
		
//cout << "------<EARLY RETURN: no coalescents> CalcFacWbRatioForSpeciesAtNode: nodeid<" << pnSTNode->GetID() << ">: coalTaxa1:" << coalTaxa1 << ", coalTaxa2: " << coalTaxa2 << endl;
		return 1.0;
	}
	
    // if this node is already at maximal subtree, invoke the maximal subtree function
    // but if the other count is not zero, return zero
    bool fSTRoot1= infoFGPT.setMaximalSTRootsTaxa[0].find(pnSTNode) != infoFGPT.setMaximalSTRootsTaxa[0].end();
    bool fSTRoot2=infoFGPT.setMaximalSTRootsTaxa[1].find(pnSTNode) != infoFGPT.setMaximalSTRootsTaxa[1].end();
    if( fSTRoot1 || fSTRoot2)
    {
        if( fSTRoot1 && fSTRoot2 )
        {
            // this should not happen
            YW_ASSERT_INFO(false, "Should not both be non-zero");
            return 0.0;
        }
        if( (fSTRoot2 && coalTaxa1 > 0) || ( fSTRoot1 && coalTaxa2 > 0) )
        {
            // this should not happen
            cout << "*******THIS SHOULD NOT HAPPEN.\n";
            cout << "coalTaxa1: " << coalTaxa1 << ", coalTaxa2: " << coalTaxa2;
            if( fSTRoot1)
            {
                cout << ".  STRoot1\n";
            }
            if( fSTRoot2)
            {
                cout << ". STRoot2\n";
            }
            return 0.0;
        }
        
        //if( fSTRoot1 )
        //{
        //    double res = CalcFacWbRatioComboForSubtree( //pnSTNode, coalTaxa1 );
//cout << "This is a taxa 1 subtree root: res=" << res << endl;
        //    return res;
        //}
        //else
        //{
            //
        //    double res= CalcFacWbRatioComboForSubtree( //pnSTNode, coalTaxa2 );
//cout << "This is a taxa 2 subtree root: res=" << res<< endl;
        //    return res;
        //}
    }
    
    // so there are choices to make, then should consider how we want to split the coalescents
    // collect all children and classify them based on how many type1 and type2 are allowed
    //YW_ASSERT_INFO(pnSTNode->GetChildrenNum() > 0, "Must have some children");
    
    // figure out settings
    int numCoalsUnder = GetNumCoalsUnder(pnSTNode, true);

    if( numCoalsUnder == 0 )
    {
//cout << "------<EARLY RETURN> CalcFacWbRatioForSpeciesAtNode: nodeid<" << pnSTNode->GetID() << ">: coalTaxa1:" << coalTaxa1 << ", coalTaxa2: " << coalTaxa2 << endl;
      return 1.0;
    }


    int numCoalsUnderInRootBranch = numCoalsUnder-coalTaxa1-coalTaxa2;
//cout << "CalcFacWbRatioForSpeciesAtNode: coalTaxa1: " << coalTaxa1 << ", coalTaxa2: " << coalTaxa2 << ", numCoalsUnderInRootBranch: " << numCoalsUnderInRootBranch << endl;
    YW_ASSERT_INFO(numCoalsUnderInRootBranch>=0, "Cannot be negative");

    // if all the subtree is to be coalesced, calc it directly
    if( numCoalsUnderInRootBranch == 0)
    {
      double resDir = 0.0;
      if( coalTaxa1 == 0 )
      {
        resDir = CalcFacWbRatioComboForSubtree( pnSTNode, coalTaxa2 );
      }
      else if( coalTaxa2 == 0 )
      {
        resDir = CalcFacWbRatioComboForSubtree( pnSTNode, coalTaxa1 );
      }
      else
      {
         YW_ASSERT_INFO(false, "FATAL error: coal1 and coal2 must have one zero.");
      }
//cout << "resDir = " << resDir << endl;
//cout << "----- <return>: CalcFacWbRatioForSpeciesAtNode: nodeid<" << pnSTNode->GetID() << ">: coalTaxa1:" << coalTaxa1 << ", coalTaxa2: " << coalTaxa2 << endl;
      return resDir;
    }
	
	// YW: should take care mulfurcating trees
	int numCoalsThisNode = GetNumCoalEvtsAtNode(pnSTNode);
	// if there is not enough coalescents at this node (above the root), then don't consider it
	if( numCoalsUnderInRootBranch < numCoalsThisNode )
	{
		return 0.0;
	}

    // have mixed
    //double facThisNode = 1.0/(numCoalsUnderInRootBranch );
	//double facThisNode = 1.0;
	//for(int i=0; i<numCoalsThisNode; ++i)
	//{
	//	facThisNode *= 1.0/( numCoalsUnderInRootBranch-i );
	//}
	// also multiply a comb. factor: the number of possible binary trees
	//facThisNode *= gstHelper.CalcdbVal(  );
	double facThisNode = CalcFactorAtSingleNode(numCoalsUnderInRootBranch, pnSTNode);
    
    double res = facThisNode*CalcFacWbRatioForSpeciesAtNodeSub( pnSTNode, coalTaxa1, coalTaxa2, 0 );
//cout << "This is not a subtree root: facThisNode=" << facThisNode <<", res=" << res << endl;
//cout << "++++++ <return> CalcFacWbRatioForSpeciesAtNode: nodeid<" << pnSTNode->GetID() << ">: coalTaxa1:" << coalTaxa1 << ", coalTaxa2: " << coalTaxa2 << endl;
    return res;
}

// auxilary of the previous function to handle multiple children
double FastGeneTreeProbTwoSpecies :: CalcFacWbRatioForSpeciesAtNodeSub(TreeNode *pnSTNode, int coalTaxa1, int coalTaxa2, int stStart)
{
    //
    YW_ASSERT_INFO(infoFGPT.mapNumCoalEvtsForNode.find(pnSTNode)!= infoFGPT.mapNumCoalEvtsForNode.end(), "Fail to find" );
    pair<int,int> countsTwoEvts = infoFGPT.mapNumCoalEvtsForNode[pnSTNode];
    double res = 0.0;
    
    // find out the bounds on the number of events that should occur at the current node
    int boundsUpperEvts[2];
    boundsUpperEvts[0] = 0;
    boundsUpperEvts[1] = 0;
    // how many possible evts can occur in the later nodes
    for(int ci = stStart+1; ci<pnSTNode->GetChildrenNum(); ++ci)
    {
        YW_ASSERT_INFO(infoFGPT.mapNumCoalEvtsForNode.find(pnSTNode->GetChild(ci))!=infoFGPT.mapNumCoalEvtsForNode.end(), "Fail to find1" );
        pair<int,int> countsNext = infoFGPT.mapNumCoalEvtsForNode[ pnSTNode->GetChild(ci) ];
//cout << "For ci=" << ci << ", countsNext: " << countsNext.first << "," << countsNext.second << endl;
        boundsUpperEvts[0] += countsNext.first;
        boundsUpperEvts[1] += countsNext.second;
    }
//cout << "boundsUpperEvts: " << boundsUpperEvts[0] << ", " << boundsUpperEvts[1] << endl;


    // this is at most how many events (of two types) can occur at the first child
    int boundsStartChild[2];
    YW_ASSERT_INFO(infoFGPT.mapNumCoalEvtsForNode.find(pnSTNode->GetChild(stStart))!=infoFGPT.mapNumCoalEvtsForNode.end(), "Fail to find1" );
    pair<int,int> countsCurChild = infoFGPT.mapNumCoalEvtsForNode[ pnSTNode->GetChild(stStart) ];
    boundsStartChild[0] = countsCurChild.first;
    boundsStartChild[1] = countsCurChild.second;

    
//cout << "CalcFacWbRatioForSpeciesAtNodeSub: node<"<<pnSTNode->GetID() <<"> startnode:" << stStart <<": coalTaxa1: " << coalTaxa1 << "boundCurChild1: " << boundsStartChild[0]  << ", bounds1:" << boundsUpperEvts[0] << ", countsTwoEvts.first:" << countsTwoEvts.first <<"   ---- coalTaxa2: " << coalTaxa2  << ", boundsStartChild[1]: " << boundsStartChild[1] << ", bounds2:" << boundsUpperEvts[1] << ", countsTwoEvts.second:" << countsTwoEvts.second << endl;
    // stop if we have too many
    //if( coalTaxa1 > boundsUpperEvts[0] + boundsStartChild[0] || coalTaxa2 > boundsUpperEvts[1] + boundsStartChild[1] )
    //{
//cout << "TWO MANY.\n";
    //    return 1.0;
    //}
    
    // calc the minimum evts we must use here
    int numEvts1Min = 0;
    int numEvts2Min = 0;
    if( coalTaxa1 - boundsUpperEvts[0] > 0  )
    {
        numEvts1Min = coalTaxa1 - boundsUpperEvts[0];
    }
    if( coalTaxa2 - boundsUpperEvts[1] > 0  )
    {
        numEvts2Min = coalTaxa2 - boundsUpperEvts[1];
    }
//cout << "numEvts1Min: " << numEvts1Min << ", numEvts2Min: " << numEvts2Min << endl;
    
    // try all possible split
    for(int coalTaxa1Step=numEvts1Min; coalTaxa1Step <=boundsStartChild[0] && coalTaxa1Step<=coalTaxa1; ++coalTaxa1Step )
    {
        for(int coalTaxa2Step=numEvts2Min; coalTaxa2Step<=boundsStartChild[1] && coalTaxa2Step<=coalTaxa2; ++coalTaxa2Step )
        {
            //
            double resStep = CalcFacWbRatioForSpeciesAtNode(pnSTNode->GetChild(stStart), coalTaxa1Step, coalTaxa2Step);
//cout << "coalTaxa1Step:node"<<pnSTNode->GetID()<<  coalTaxa1Step << ", coalTaxa2Step:" << coalTaxa2Step << ", resStep: " << resStep << ", res = " << res << endl;
            if( stStart < pnSTNode->GetChildrenNum()-1 )
            {
                double resStep2 = CalcFacWbRatioForSpeciesAtNodeSub( pnSTNode, coalTaxa1-coalTaxa1Step, coalTaxa2-coalTaxa2Step, stStart+1 );
                resStep *= resStep2;
//cout << "For ssStart: node<"<<pnSTNode->GetID() << "  "<< stStart << ": resStep2: " << resStep2 << ", resStep = " << resStep << endl;
            }
            
            res += resStep;
//cout << "Updating res: node<"<<pnSTNode->GetID() << ">: res=" << res << ", resStep:" << resStep << endl;
        }
    }
//cout << "CalcFacWbRatioForSpeciesAtNodeSub: node<"<<pnSTNode->GetID() <<"> startnode: res = " << res << ", stStart: " << stStart << endl;
    return res;
}

// calc factor of wb ratio for the case of single subtree rooted
double FastGeneTreeProbTwoSpecies :: CalcFacWbRatioComboForSubtree(TreeNode *pnSTNode, int numCoals)
{    
    // contain all terms of both lower and upper partitions of the subtree
    double res = CalcFacWbRatioForSubtree( pnSTNode, numCoals );
//cout << "CalcFacWbRatioComboForSubtree: res = " << res <<", numCoals=" << numCoals << endl;
    //for(set<TreeNode*> :: iterator it = listNodes.begin(); it != listNodes.end(); ++it)
    //{
    //    if( (*it)->IsLeaf() == true )
    //    {
    //        continue;
    //    }
    //    int numIntNodesUnder = GetNumCoalsUnder( *it, false );
    //    res *= 1.0/(1+numIntNodesUnder);
    //}
//cout << "After augmentation: res=" << res << endl;
    return res;
}

// calc factor of wb ratio for the case of single subtree rooted
double FastGeneTreeProbTwoSpecies :: CalcFacWbRatioForSubtree(TreeNode *pnSTNode, int numCoals)
{
    // only for the upper part
    // the subtree is maximal and uniformly containing only alleles from a single speices
    // this procedure computes a ratio factor suppose we take numCoals internal nodes
    int numIntNodes = pnSTNode->GetNumNodesUnder(true, true);
//cout << "CalcFacWbRatioForSubtree: numCoals = " << numCoals << ", numIntNodes: " << numIntNodes << endl;
    //if( numCoals > numIntNodes || numCoals == 0 )
    //if( numCoals > numIntNodes )
    //{
    //    YW_ASSERT_INFO(false, "Wrong.");
    //    return 1.0;     // no work needed
    //}
    if( numIntNodes == 0 )
    {
      // no coalescent below, then just return 1.0
      return 1.0;
    }
    //YW_ASSERT_INFO(numIntNodes == numCoals, "Must all coalesce");


	// calculate coeff at this node
	int numCoalEvtsThisNode = GetNumCoalEvtsAtNode( pnSTNode );
	//if( numCoalEvtsThisNode <= 0 )
	//{
	//	return 1.0;
	//}
	
	YW_ASSERT_INFO( numCoalEvtsThisNode>=1, "Must have at least one coalescednt events" );
	YW_ASSERT_INFO(numCoalEvtsThisNode<=numIntNodes, "Too few coalescents");
    //
    //double res = 1.0/numIntNodes;
	
	//double res = 1.0;
	//for(int i=0; i<numCoalEvtsThisNode; ++i)
	//{
	//	// 
	//	res *= 1.0/( numIntNodes-i );
	//}
	double res = CalcFactorAtSingleNode(numIntNodes, pnSTNode);
	
    //if( numCoals < numIntNodes)
    //{
    //    // now need to consider the number of coalescents under it, which should not be included
    //    int numCoalsUpper = numIntNodes-numCoals;
    //    //res = (1.0*numIntNodes)/(1.0*numCoalsUpper);
//cout << "Not all coalescents are used.\n";
    //    res = 1.0/numCoalsUpper;
    //}
    
    // process all the children
    if( numIntNodes > 1 )
    {
        // there are still things under
        // YW: I think it should not be numCoals-1, but rather num of internal nodes-numCoals
        //double resstep = CalcFacWbRatioForSubtreeSub(pnSTNode, numCoals-1, 0);
		double resstep = CalcFacWbRatioForSubtreeSub(pnSTNode, numCoals-numCoalEvtsThisNode, 0);
        res *= resstep;
//cout << "CalcFacWbRatioForSubtree: resstep: " << resstep << ", res: " << res << endl;
        //res *= CalcFacWbRatioForSubtreeSub(pnSTNode, numIntNodes-numCoals, 0);
    }
//cout << "CalcFacWbRatioForSubtree: res = " << res <<", numCoals = " << numCoals << endl;
    return res;
}

// auxillary function: only for subtrees indexed stStart and later
double FastGeneTreeProbTwoSpecies :: CalcFacWbRatioForSubtreeSub(TreeNode *pnSTNode, int numCoals, int stStart)
{
    // use recursion
    YW_ASSERT_INFO(stStart < pnSTNode->GetChildrenNum(), "Out of bound" );
    
    // if no coalescent for this subtree, then that is one
    if( numCoals <= 0 )
    {
        return 1.0;
    }
    
    TreeNode *pnc = pnSTNode->GetChild(stStart);
    int ncpnc = GetNumCoalsUnder(pnc, true);
//cout << "CalcFacWbRatioForSubtreeSub: ncpnc: " << ncpnc << ", numCoals: " << numCoals << ",stStart: " << stStart << endl;
    double res = 1.0;
    if( pnc->IsLeaf() == false)
	{
		res = CalcFacWbRatioForSubtree(pnc, ncpnc);
	}
    if(stStart < pnSTNode->GetChildrenNum()-1 )
    {
      double resStep2 = CalcFacWbRatioForSubtreeSub(pnSTNode, numCoals-ncpnc, stStart+1);
//cout << "CalcFacWbRatioForSubtreeSub: resstep2: " << resStep2 << endl;
      res *= resStep2;
    }
    return res;
}

int FastGeneTreeProbTwoSpecies :: GetNumCoalsUnder(TreeNode *pn, bool fIncSelf)
{
//cout << "GetNumCoalsUnder: pnid=" << pn->GetID() << endl;
    // num of internal node = num in the map -1 (self)
    YW_ASSERT_INFO( mapGeneTreeInfo.find(pn) != mapGeneTreeInfo.end(), "Node not found" );
    //int res = mapGeneTreeInfo[pn].numIntNodes;
	int res = 0;
	set<TreeNode *> setDesc;
	pn->GetAllDescendents(setDesc);
	for(set<TreeNode*> :: iterator it = setDesc.begin(); it != setDesc.end(); ++it)
	{
		if( (*it)->IsLeaf() == false )
		{
			//
			TreeNode *pnc = const_cast<TreeNode *>(*it);
			res += GetNumCoalEvtsAtNode(pnc);
		}
	}
//cout << "So far res=" << res << endl;
    if( res > 0 && fIncSelf == false )
    {
//cout << "Exluce self...\n";
        res -= GetNumCoalEvtsAtNode(pn);
		YW_ASSERT_INFO(res >=0, "Wrong");
    }
    return res;
}

int FastGeneTreeProbTwoSpecies :: GetNumCoalEvtsAtNode(TreeNode *pn)
{
	if( pn->IsLeaf() == true )
	{
		return 0;
	}
	
	//
	return pn->GetChildrenNum()-1;
}

double FastGeneTreeProbTwoSpecies :: CalcFactorAtSingleNode(int numCoalsUnderInRootBranch, TreeNode *pn)
{
	// when there are 
	// YW: should take care mulfurcating trees
	int numCoalsThisNode = GetNumCoalEvtsAtNode(pn);

	double facThisNode = 1.0;
	for(int i=0; i<numCoalsThisNode; ++i)
	{
		facThisNode *= 1.0/( numCoalsUnderInRootBranch-i );
	}
	// also multiply a comb. factor: the number of possible binary trees
	double facComb = gstHelper.CalcdbVal( numCoalsThisNode+1, numCoalsThisNode );
//cout << "CalcFactorAtSingleNode: facComb=" << facComb << ", facThisNode before = " << facThisNode << ", numCoalsUnderInRootBranch: " << numCoalsUnderInRootBranch <<", numCoalsThisNode: " << numCoalsThisNode << endl;
	facThisNode *= facComb;
	return facThisNode;
}

