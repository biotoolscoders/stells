//
//  FixedSTGeneTreeProb.h
//  
//
//  Created by Yufeng Wu on 7/22/15.
//  Compute gene tree probability faster (say polynomial time) for the case
//  where the number of species is small (i.e. constant)
// 

#ifndef ____FixedSTGeneTreeProb__
#define ____FixedSTGeneTreeProb__

#include "GeneSpeciesTreeProb.h"


///////////////////////////////////////////////////////////////////////////////
// For testing purpose

void TestProbCode(MarginalTree &treeSpecies, PhylogenyTreeBasic &treeGene);

//////////////////////////////////////////////////////////////////////////////////
// info about gene tree node

void DumpProfileInfo();

//////////////////////////////////////////////////////////////////////////////////
// Num of coalescents info

class FGTPFSProbHelper;

class FGTPFSAncesCfgCoalInfo
{
public:
    FGTPFSAncesCfgCoalInfo();
    FGTPFSAncesCfgCoalInfo(const map<int,int> &mapCoalLimits);
    FGTPFSAncesCfgCoalInfo(const FGTPFSAncesCfgCoalInfo &rhs);
    
	bool operator<(const FGTPFSAncesCfgCoalInfo& rhs) const;
    void GetEventList( map<int, int> &mapSTBranchCoalNumsOut ) const { mapSTBranchCoalNumsOut = mapSTBranchCoalNums; }
    
    // update the number of coals at a particular node in ST
    void SetCoalNumAt(int stnid, int numCoals);
    
    // among all the events (w/ non-zero), what is the number of events occuring at the topmost species tree branch
    int GetNumEvtLatest() const;
    
    // decrease the number of topmost event by one (if that ST branch no longer has events, erase the ST branch)
    void DecTopEventNum();
    
    // ensure the total number of coalescent events are valid
    bool TouchupTotCoalEvtsNum(const map<int,int> &ubSTBrCoalsUnder, FGTPFSProbHelper &helper);
    bool TouchupTotCoalEvtsNum(int numEvtTot, int rootST);
    
    // clean up un-used ones
    bool CleanUnusedSTBrs(const map<int,int> &ubSTBrCoalsUnder);
      
    //
    void Dump() const;
    
    // collect all possible entries by splitting it; setLins: if size=1, means entire subtree rooted at the single lin
    // if size>=2, refer to collect of subtrees under a common parent
    static void CollectAllCoeffInfos( const map<int,int> &ubCoalNumsSTBrs, FGTPFSProbHelper &helper, set<FGTPFSAncesCfgCoalInfo> &setCoalNums );
    
    // get num of coalescent events in the coalescent record under a speciic ST branch
    static int GetNumCoalsUnderSTNode(int stNode, const map<int,int> &mapCoalNumsSTBrs, FGTPFSProbHelper &helperFGTPFS);
    
private:
    
    // collect all possible entries by processing a particular ST node
    // this allows a bottom-up way of setting all coalescents along all ST branches
    static void CollectAllCoeffEntriesAtSTBranch( const map<int,int> &ubCoalNumsSTBrs, FGTPFSProbHelper &helper, set<FGTPFSAncesCfgCoalInfo> &setCoalNums, int stnid, int maxCoalOnSTBr );
    
    // setup root branch coal from the rest of coalescent events
    void SetupRootBranchCoals( const set<int> &setGTNids, const map<int,int> );
    
    // get the number of coalsced events under a particular ST node
    int GetNumCoalsUnderSTNode(int stNode, FGTPFSProbHelper &helperFGTPFS) const;
    
    
	// num of coalescents within this subtrees on each of the species tree branch
	// invariant: sum of these coal nums must equal to the num of coalescents under this subtree (incl. root)
	map<int, int> mapSTBranchCoalNums;
};



//////////////////////////////////////////////////////////////////////////////////
// For a given AC, compute the coefficients

class FGTPFSCoeffCompEntry
{
public:
    FGTPFSCoeffCompEntry();
	FGTPFSCoeffCompEntry( const set<TreeNode *> &setDescIn, const FGTPFSAncesCfgCoalInfo &STBranchCoalNumsIn);
	FGTPFSCoeffCompEntry(const FGTPFSCoeffCompEntry &rhs);
	bool operator<(const FGTPFSCoeffCompEntry &rhs) const;
	double Calc(FGTPFSProbHelper &helper);
    void SetValue(double coeffIn) { valCoeff = coeffIn; }
    double GetValue() const { return valCoeff; }
    int GetNumEvtLatest() const;
    void GetDescCoals( set<TreeNode*> &setDescIn) const { setDescIn = setDescCoals; }
    void DecTopEventNum();
    const FGTPFSAncesCfgCoalInfo &GetInfo() const { return cfgSTBranchCoalNums; }
    FGTPFSAncesCfgCoalInfo &GetInfoNC() { return cfgSTBranchCoalNums; }
    void Dump() const;
    
    // an entry is atomic if it has no enclosed coalescent and set of branches size = 2
    bool IsAtomic() const;
    
    // collect all possible entries by splitting it; setLins: if size=1, means entire subtree rooted at the single lin
    // if size>=2, refer to collect of subtrees under a common parent
    static void CollectAllCoeffEntries( const set<TreeNode *> &setGTLins, FGTPFSProbHelper &helper, set<FGTPFSCoeffCompEntry> &setCoalNums );

    // get the range of coals within subtree branches for a list of GT subtrees
    //static void FindCoalsUBForSiblingsAllPartitions( const set<TreeNode *> &setGtSiblings, FGTPFSProbHelper &helper, map<int,int> &mapSTCoalUBs );
    
    // obtain all feasible partitions
    static bool FindAllParitionsForInfo( const FGTPFSAncesCfgCoalInfo &coalInfoOrig, const map<int,int> &boundPart1, const map<int,int> &boundPart2, int rootST, FGTPFSProbHelper &helper, set<pair< map<int,int>, map<int,int>  > > &setParts );
    
    // get the range of coals within subtree branches for a list of GT subtrees
    static void FindCoalsUBForSiblings( const set<TreeNode *> &setGtSiblings, FGTPFSProbHelper &helper, map<int,int> &mapSTCoalUBs );
    
private:
    // get relevant ST branches where may have non-zero coalescents
    //static void GetRelevantSTBranches( const set<TreeNode *> &setGTLins, FGTPFSProbHelper &helper, set<int> &stBranches );
    
    
	// subtree root of gene tree
	//TreeNode *pnCurr;
	
	// important for mulfurcating trees: subset of lineages forming a clade
	// can be empty if (i) there is no coalescable subtrees below pnCurr or (ii) 
	// the entire subtree is considered
	set<TreeNode *> setDescCoals;
	
	// num of coalescents within this subtrees on each of the species tree branch
	// invariant: sum of these coal nums must equal to the num of coalescents under this subtree (incl. root)
	FGTPFSAncesCfgCoalInfo cfgSTBranchCoalNums;
    
    // value of coeff
    double valCoeff;
};

//////////////////////////////////////////////////////////////////////////////////
// Helper class for prob calculation

class FGTPFSProbHelper
{
public:
    FGTPFSProbHelper( MarginalTree &treeSpeciesIn, PhylogenyTreeBasic &treeGeneIn );

    //void GetMaxCoalEvtNumsForGTNode(TreeNode * pnCurr, FGTPFSAncesCfgCoalInfo &coalInfo);
    
    // is a ST branch under another branch (inclusive: i.e. branch a is considered to be under itself)
    bool IsSTBranchUnder(int snChild, int snAnc);
    
    // get taxa of all leaves under a subtree
    void GetTaxaUnderGTSubtree( TreeNode *gtSTNode, set<int> &setTaxa );
    
    // find the MRCA of a set of ST nodes
    int GetMRCASTNodes( const set<int> &setSTNodes );
    
    // get all ancestral ST branches (inclusive again)
    void GetAncesSTBranches(int stBr, set<int> &ancesBrs);
    
    // test ancestral relation
    bool IsSTBrAncestralTo( int brSTAnc, int brSTDest );
    
    // retrieve pre-computed coefficient
    double RetriveCoeff( FGTPFSCoeffCompEntry &entry );
    
    // get root of species tree, and misc
    int GetSTRoot() const { return treeSpecies.GetRoot(); }
    int GetSTLeftDesc(int sn) const { return treeSpecies.GetLeftDescendant(sn); }
    int GetSTRightDesc(int sn) const { return treeSpecies.GetRightDescendant(sn); }
    bool IsSTNodeLeaf(int sn) const { return treeSpecies.IsLeaf(sn); }
    double GetSTBranchLen(int sn) const;
    
    // get root of Gene tree
    TreeNode *GetGTRoot() const { return treeGene.GetRoot(); }
    void GetRootChildren(set<TreeNode *> &setRootChildren) const;
    
    // get num of gene alleles under a ST node
    int GetNumGeneAllelesUnderSTBr(int stBr);
    
    // get all ST branches that coalescent may occur on them from subtrees rooted at these nodes (self included)
    void GetAllCoalBoundsOnSTBrsForGTSTs( const set<TreeNode *> &setGTSubtrees, map<int,int> &mapSTNidBoundss );
    
    //
    GeneSpeciesTreeHelper &GetGTSTOrigHelper() { return helperOfFGTPFSProbHelper; }
    
    // cleanup a entryinfo by removing not-used ST events
    bool CleanUnusedSTBrs( FGTPFSCoeffCompEntry &entryToClean );
    
    //
    void Dump() const;
    
	
private:
    // initialize coefficients
    void Init();
    
    // build up a table holding coefficients for all possible node/subsets
    void ConsNodesCoalCoeffs();
    
    // calc over all consructed coeffs
    void CalcCoeffFor(FGTPFSCoeffCompEntry &entryCoeff);
    
    // collect all possible coal infos at node
    void CollectAllCoalInfoAt(TreeNode *pnCurr);
    
    // for node, collect coalescent info at GT node
    void CollectCoalInfoAt(TreeNode *pnCurr);
    
    // get all ST branches that coalescent may occur on them from subtrees rooted at these nodes (self included)
    //void GetAllCoalBoundsOnSTBrsForOneGTST( TreeNode * gtSubtree, map<int,int> &mapSTNidBoundss );
    
    // construct UB for all sibling GT lins and each ST branches
    void CollectUBAllSibGTLinsSTBrs();
    
    // update UB info for a sibling GT lins
    void CollectUBForSibGTLins( const set<TreeNode *> &setGtSiblings );
    
    // split a entry into two children
    void SplitEntryToTwoPartitions( const FGTPFSCoeffCompEntry &entrySplit, const set<TreeNode *> &setLinsPart1, const set<TreeNode *> &setLinsPart2, set<pair<FGTPFSCoeffCompEntry, FGTPFSCoeffCompEntry> > &setPartsNew );
    
    
    // input ST/GT trees
    MarginalTree &treeSpecies;
	PhylogenyTreeBasic &treeGene;
    
    // helper from the more general case
    GeneSpeciesTreeHelper helperOfFGTPFSProbHelper;
    
    // key data structure for holding coefficients
    set< FGTPFSCoeffCompEntry > mapCoalCoeffsAll;
    
    // at each node, how many coalescents there are
    map<TreeNode *, int> mapNumCoalsAtSubtree;
    
    // upper bound on # of coalescents for a set of siblibing gene tree lineages at a specific ST branch
    map<set<TreeNode *>, map<int,int> > mapMaxCoalNumsAtSTBrSibGTBrs;
};


//////////////////////////////////////////////////////////////////////////////////
// For a given AC, compute the coefficients 

class FGTPFSCoeffComp
{
public:
	double CalcACCoeff( FGTPFSCoeffCompEntry &entryACCoeff );

private:
	// for each ST branch (ending at the given node)
	static map<FGTPFSCoeffCompEntry, double> cacheACCoeffs;
};


//////////////////////////////////////////////////////////////////////////////////
// Fixed species tree prob configuration. Spcify the number of
// gene lineages on top of each species tree branch (the topmost is always 1)

class FGTPFSAncesCfg
{
public:
    FGTPFSAncesCfg();
    FGTPFSAncesCfg(const FGTPFSAncesCfg &rhs);
    bool operator<(const FGTPFSAncesCfg &rhs) const;
    bool IsEmpty() const { return mapNumCoalsOnSTBranch.size() == 0; }
    
    // add an entry
    void AddLinEntry(int stBr, int numGTLinsTop);
    
    // calculate the probability of this AC
    double CalcProb( FGTPFSProbHelper &helper ) const;
    
    // calculate the log-probability of this AC
    double CalcLogProb( FGTPFSProbHelper &helper ) const;
    
    // get num of GT lineages under a ST branch
    int GetNumGTLinsDesc( int stBr, FGTPFSProbHelper &helper ) const;

    //
    void Dump() const;
    
private:
    // calculate the coalescent coefficient
    double CalcCoalCoeff( FGTPFSProbHelper &helper ) const;
    // calculate branch prob
    double CalcBranchProb( FGTPFSProbHelper &helper) const;
    // calc db values
    double CalcdbVal(FGTPFSProbHelper &helper) const;
    // calc log-db values
    double CalcLogdbVal(FGTPFSProbHelper &helper) const;
    
    // get num of bottom gene tree lineages (i.e. entering from below)
    int GetNumBottomGTLins( int snid, FGTPFSProbHelper &helper) const;
    
    // convert to coal event style
    void ConsCoalInfo( FGTPFSProbHelper &helper, FGTPFSAncesCfgCoalInfo &coalInfo) const;
    
	// for each ST branch (ending at the given node)
	map<int, int> mapNumCoalsOnSTBranch;
};


//////////////////////////////////////////////////////////////////////////////////
// Fixed species tree prob

class FastGeneTreeProbFixedSpecies : public GenericGeneSpeciesTreeProb
{
public:
    FastGeneTreeProbFixedSpecies( MarginalTree &treeSpecies, PhylogenyTreeBasic &treeGene );
    virtual double CalcProb();
    virtual double CalcLogProb();
    // attempt to change a branch to a new length, and update the prob. Since we may need to recover the original
    // unchanged probs, we just save those changed one (i.e. keep a copy of what was there before)
    virtual double TestNewBranchLenAt(int branch, double lenNew, map<int,set< LineageConfig,LTLinCfg > > &origLinCfgs, bool fSetBrlen );
    virtual void SetLinCfgs(map<int,set< LineageConfig,LTLinCfg > > &linCfgsToSet);	// useful when we want to un-do the effect of the previous tweaking of branch length
    virtual void SetSTBranchLen(int br, double brLen) { treeSpecies.SetBranchLen(br, brLen); }
    virtual void GetSpeciesTree(MarginalTree &spTree) const { spTree = treeSpecies; }
	virtual int GetTaxaAtLeafST(int snid) { return helperGTST.GetGTSTOrigHelper().GetTaxaAtLeafST(snid); }
	virtual void GetGeneAllelesForSpecies( int taxon, set<int> &geneAlleles) { helperGTST.GetGTSTOrigHelper().GetGeneAllelesForSpecies( taxon, geneAlleles); }
    
private:
    
    // get the species tree bracn len
    double GetSTBranchLen(int br) { return treeSpecies.GetEdgeLen(br); }
    
    // collect all ACs
    void CollectAllACs( set< FGTPFSAncesCfg > &setAllACs );
    
    // collect UBs/LBs on gene lineages for each ST branch (top)
    void CollectBoundsGTLinsForSTBrs( map<int, pair<int,int> > &mapGTBoundsOnSTBr );
    
 
    // helper on
    MarginalTree &treeSpecies;
	PhylogenyTreeBasic &treeGene;
    FGTPFSProbHelper helperGTST;
};





#endif /* defined(____FixedSTGeneTreeProb__) */
