//
//  FastGeneTreeProb.h
//  
//
//  Created by Yufeng Wu on 7/8/15.
//  Compute gene tree probability faster (say polynomial time) for some
//  restricted cases
// 

#ifndef ____FastGeneTreeProb__
#define ____FastGeneTreeProb__

#include "GeneSpeciesTreeProb.h"

//////////////////////////////////////////////////////////////////////////////////
// info about gene tree node

struct FGTPT_SUBTREE_INFO
{
public:
    int numIntNodes;
};

struct FGPT_INFO
{
public:
    double lenTaxa1Branch;
    double lenTaxa2Branch;
    int numAlleleTaxa1;
    int numAlleleTaxa2;
    set<TreeNode *> setMaximalSTRootsTaxa[2];
	set<TreeNode *> setAllUniformSTRootsTaxa[2];
    map<TreeNode *, pair<int,int> > mapNumCoalEvtsForNode;
};

//////////////////////////////////////////////////////////////////////////////////
// Two species

class FastGeneTreeProbTwoSpecies
{
public:
    FastGeneTreeProbTwoSpecies( MarginalTree &treeSpecies, PhylogenyTreeBasic &treeGene );
    double CalcProb();
    
private:
    void Init();
    void Check();   // ensure proper input
    
    // calc prob for a particular lineage number settings (n1,n2)
    double CalcProbPairLinNums(int na1, int na2);
    
    // calc coefficient of a particular lineage number settings (n1,n2)
    double CalcCoeffPairLinNums(int na1, int na2);
    
    // calc factor ratio for entire tree conditional on the lineage number settings
    double CalcFacWbRatioForLinNums(int na1,int na2);
    double CalcFacWbRatioForSpeciesAtNode(TreeNode *pnSTNode, int coalTaxa1, int coalTaxa2);
    double CalcFacWbRatioForSpeciesAtNodeSub(TreeNode *pnSTNode, int coalTaxa1, int coalTaxa2, int stStart);
    
    // calc factor of wb ratio for one species
    //double CalcFacWbRatioForSpecies(int ns, int numCoals);
    // calc factor of wb ratio for one species by restricting to some subtrees
    //double CalcFacWbRatioForSpeciesSub(const vector<TreeNode *> &listSubtreeRoots, int numCoals, int stStart);
    // calc factor of wb ratio for the case of single subtree rooted
    double CalcFacWbRatioComboForSubtree(TreeNode *pnSTNode, int numCoals);
    double CalcFacWbRatioForSubtree(TreeNode *pnSTNode, int numCoals);
    double CalcFacWbRatioForSubtreeSub(TreeNode *pnSTNode, int numCoals, int stStart);
    int GetNumCoalsUnder(TreeNode *pn, bool fIncSelf);
	int GetNumCoalEvtsAtNode(TreeNode *pn);
	double CalcFactorAtSingleNode(int numCoalsUnderInRootBranch, TreeNode *pn);
    
    MarginalTree &treeSpecies;
	PhylogenyTreeBasic &treeGene;
    GeneSpeciesTreeHelper gstHelper;
    
    // useful info
    map<TreeNode *, FGTPT_SUBTREE_INFO> mapGeneTreeInfo;
    FGPT_INFO infoFGPT;
};




#endif /* defined(____FastGeneTreeProb__) */
