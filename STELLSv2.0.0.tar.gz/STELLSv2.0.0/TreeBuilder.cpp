//
//  TreeBuilder.cpp
//  
//
//  Created by Yufeng Wu on 9/11/15.
//
//

#include "TreeBuilder.h"
#include "Utils.h"

//***********************************************************************
void TestNJ()
{
    //
    PhyloDistance distNJ;
    distNJ.SetDistance(1,2,5.0);
    distNJ.SetDistance(1,3,9.0);
    distNJ.SetDistance(1,4,9.0);
    distNJ.SetDistance(1,5,8.0);
    distNJ.SetDistance(2,3,10.0);
    distNJ.SetDistance(2,4,10.0);
    distNJ.SetDistance(2,5,9.0);
    distNJ.SetDistance(3,4,8.0);
    distNJ.SetDistance(3,5,7.0);
    distNJ.SetDistance(4,5,3.0);

    DistanceTreeBuilder builder(distNJ);
    string treeNW = builder.NJ();
    cout << "Constructed NJ tree: " << treeNW << endl;
    //distNJ.Dump();
}


//***********************************************************************
// define distances between taxa


void PhyloDistance :: SetDistance(int node1, int node2, double dist)
{
    //
    pair<int,int> pp(node1,node2);
    mapDists.insert( map< pair<int,int>, double> :: value_type(pp, dist) );
}

double PhyloDistance :: GetDistance(int node1, int node2) const
{
    //
    PhyloDistance *pthis = const_cast<PhyloDistance *> (this);
    pair<int,int> pp1(node1, node2), pp2(node2, node1);
    if( mapDists.find(pp1) != mapDists.end() )
    {
        //
        return pthis->mapDists[pp1];
    }
    if( mapDists.find(pp2) != mapDists.end() )
    {
        //
        return pthis->mapDists[pp2];
    }
    YW_ASSERT_INFO(false, "Fail to find");
    return 0.0;
}

double PhyloDistance :: GetDistanceNonNeg( int node1, int node2 ) const
{
    //
    double dist = GetDistance(node1, node2);
    if( dist < 0.0)
    {
        dist = 0.0;
    }
    return dist;
}

void PhyloDistance :: GetAllNodes( set<int> &nodesAll) const
{
    //
    nodesAll.clear();
    for(map< pair<int,int>, double> :: const_iterator it = mapDists.begin(); it != mapDists.end(); ++it)
    {
        nodesAll.insert(it->first.first);
        nodesAll.insert(it->first.second);
    }
}

void PhyloDistance :: Dump() const
{
    //
    for(map< pair<int,int>, double> :: const_iterator it = mapDists.begin(); it != mapDists.end(); ++it)
    {
        cout << "[" << it->first.first << "," <<it->first.second << "]: " << it->second << endl;
    }
}




// distance based tree builder

DistanceTreeBuilder :: DistanceTreeBuilder(PhyloDistance &distPairwiseTaxaIn) : distPairwiseTaxa(distPairwiseTaxaIn)
{
    //
}

// build tree using neighbor joining
string DistanceTreeBuilder :: NJ()
{
    // get all the things into the search set
    set<int> nodesToSearch;
    distPairwiseTaxa.GetAllNodes( nodesToSearch );
    
    // must have at least two nodes
    YW_ASSERT_INFO(nodesToSearch.size() >=2, "Must have two nodes at least");
    
    // get the next largest one
    int nodeToUse = 1 + (*nodesToSearch.rbegin());
    
    // build a Newick string
    string strNW;
    map<int,string> mapSubtreeStr;
    for( set<int> :: iterator it = nodesToSearch.begin(); it != nodesToSearch.end(); ++it )
    {
        //
        char buf[100];
        sprintf(buf, "%d", *it);
        string strName = buf;
        mapSubtreeStr.insert( map<int,string> :: value_type(*it, strName) );
//cout << "Init node: " << *it << ": string: " << strName << endl;
    }
    
    int ngbr1 = -1, ngbr2 = -1;
    while( nodesToSearch.size() >= 3 )
    {
        NJFindNgbrs( nodeToUse, nodesToSearch, ngbr1, ngbr2 );
//cout << "Neighbors found: " << ngbr1 << ", " << ngbr2 << ", and merged into node: " << nodeToUse << endl;
        
        char buf1[100];
        sprintf(buf1, "%f", distPairwiseTaxa.GetDistanceNonNeg(nodeToUse, ngbr1) );
        string strDist1 = buf1;
        char buf2[100];
        sprintf(buf2, "%f", distPairwiseTaxa.GetDistanceNonNeg(nodeToUse, ngbr2) );
        string strDist2 = buf2;
        
        string strSubtree = "(" + mapSubtreeStr[ngbr1]+":" +strDist1 + "," + mapSubtreeStr[ngbr2] + ":" +strDist2 + ")" ;
        mapSubtreeStr.insert( map<int,string> :: value_type(nodeToUse,strSubtree) );
//cout << "For node: " << nodeToUse << ": string: " << strSubtree << endl;
        ++nodeToUse;
    }
    
    // create a root
    int rootNode = nodeToUse;
    int ngbr1Final = *(nodesToSearch.begin());
    int ngbr2Final = *(nodesToSearch.rbegin());
    double distRootBranch = distPairwiseTaxa.GetDistanceNonNeg( ngbr1Final, ngbr2Final );
    double distNew = 0.5*distRootBranch;
    distPairwiseTaxa.SetDistance( rootNode, ngbr1Final, distNew );
    distPairwiseTaxa.SetDistance( rootNode, ngbr2Final, distNew );
    
    // final subtree
    char buf1[100];
    sprintf(buf1, "%f", distNew);
    string strDist = buf1;
    string strSubtree = "(" + mapSubtreeStr[ngbr1Final] + ":" + strDist  + "," + mapSubtreeStr[ngbr2Final] + ":" + strDist + ")" ;
//cout << "Final neighbor joining tree: " << strSubtree << endl;
    // now dump out all distances
    //distPairwiseTaxa.Dump();
    
    return strSubtree;
}
    
void DistanceTreeBuilder :: NJFindNgbrs( int nodeIdNew, set<int> &nodesToSearch, int &ngbr1, int &ngbr2 )
{
//cout << "set of nodes to search: ";
//DumpIntSet( nodesToSearch);
    // find two best ngbrs from the nodes to search (which are
    // ngbr1 and ngbr2, and remove these two from the nodes to search)
    // create a new node with the given id, add into nodestosearch, update dists
    
    // first compute ave distances of all current nodes
    map<int, double> mapAveDists;
    for( set<int> :: iterator it = nodesToSearch.begin(); it != nodesToSearch.end(); ++it )
    {
        //
        double dist = NJCalcAveDist(*it, nodesToSearch);
//cout << "single node distance for " << *it << ": " << dist << endl;
        mapAveDists.insert( map<int, double> :: value_type(*it, dist) );
    }
    
    // search all pair to find the best one to merge
    double distNJMin = HAP_MAX_INT*1.0;
    int node1Min = -1;
    int node2Min = -1;
    double dist12Min = 0.0;
    for(set<int> :: iterator it1 = nodesToSearch.begin(); it1 != nodesToSearch.end(); ++it1)
    {
        int node1cur = *it1;
        double dist1 = mapAveDists[node1cur];
        
        set<int> :: iterator it2 = it1;
        ++it2;
        
        for(; it2 != nodesToSearch.end(); ++it2)
        {
            int node2cur = *it2;
            double dist12 = distPairwiseTaxa.GetDistance( node1cur, node2cur );
            double dist2 = mapAveDists[node2cur];
            double distNJ = dist12 - dist1 - dist2;
//cout << "For nodes: " << node1cur << ", " << node2cur << ", dist1=" << dist1 << ", dist2: " << dist2 << ", dist12: " << dist12 << ", distNJ: " << distNJ << endl;
            if( distNJ < distNJMin)
            {
                distNJMin=distNJ;
                node1Min = node1cur;
                node2Min = node2cur;
                dist12Min = dist12;
            }
        }
    }
    
    // add the new node with right dist
    YW_ASSERT_INFO(node1Min >=0 && node2Min >=0, "Wrong");
    double dist1toNew = 0.5*dist12Min+0.5*( mapAveDists[node1Min] - mapAveDists[node2Min] );
    double dist2toNew = 0.5*dist12Min+0.5*( mapAveDists[node2Min] - mapAveDists[node1Min] );
    distPairwiseTaxa.SetDistance( nodeIdNew, node1Min, dist1toNew );
    distPairwiseTaxa.SetDistance( nodeIdNew, node2Min, dist2toNew );
    
    // calc remaining distances
    for( set<int> :: iterator it = nodesToSearch.begin(); it != nodesToSearch.end(); ++it )
    {
        int nodecur = *it;
        if( nodecur == node1Min || nodecur == node2Min )
        {
            continue;
        }
        double distNew = 0.5*(distPairwiseTaxa.GetDistance( nodecur, node1Min ) + distPairwiseTaxa.GetDistance(nodecur, node2Min) - distPairwiseTaxa.GetDistance( node1Min, node2Min ) );
                              //dist12Min);
        distPairwiseTaxa.SetDistance(nodeIdNew, nodecur, distNew);
    }
    
    // maintain the search set
    nodesToSearch.insert( nodeIdNew );
    nodesToSearch.erase( node1Min );
    nodesToSearch.erase( node2Min );
    
    ngbr1 = node1Min;
    ngbr2 = node2Min;
}

double DistanceTreeBuilder :: NJCalcAveDist(int nodecur, const set<int> &nodesToSearch)
{
    // calc average distance from nodecur to all nodes in the search set
    // must have at least three nodes
    YW_ASSERT_INFO( nodesToSearch.size() >= 3, "Too few nodes" );
    //YW_ASSERT_INFO( nodesToSearch.find(nodecur) != nodesToSearch.end(), "current node must be in the set");
    double res = 0.0;
    for( set<int> :: const_iterator it = nodesToSearch.begin(); it != nodesToSearch.end(); ++it )
    {
        if( *it != nodecur )
        {
            res += distPairwiseTaxa.GetDistance( nodecur, *it );
        }
    }
    return res/(nodesToSearch.size()-2);
}


