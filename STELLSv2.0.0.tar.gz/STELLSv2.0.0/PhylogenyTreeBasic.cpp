#include <stack>
#include <fstream>
#include <iostream>
#include "PhylogenyTreeBasic.h"
#include "Utils3.h"
#include "Utils4.h"

// ***************************************************************************
// The following code is largely based on Gusfield's 1991 Paper
// ***************************************************************************
extern void OutputQuotedString(ofstream &outFile, const char *buf);


string GetStringFromId(int id)
{
	char buf[100];
	sprintf( buf, "%d", id );
	return buf;
}


int GetNewickNumLeaves(const string &strNewick, char chSepLeft, char chSepRight, char midSep )
{
	// the number of leaves of newick is equal to the number of separator char plus one
	int res = 0;
	bool fCount = false;	// only count when seeing left sep (
	for(int i=0; i<(int)strNewick.length(); ++i)
	{
		if( strNewick[i] == chSepLeft)
		{
			fCount = true;
		}
		else if( strNewick[i] == chSepRight)
		{
			if( fCount == true)
			{
				// add the last one
				res ++;
			}

			fCount = false;
		}
		else if( strNewick[i] == midSep  )
		{
			if( fCount == true )
			{
				res ++;
			}
			else
			{
				fCount = true;
			}
		}
	}
	return res;
}

bool GetTripleType( TreeNode *pn1,  TreeNode *pn2, TreeNode *pn3, pair<pair<TreeNode *, TreeNode *>, TreeNode *> &triple )
{
	TreeNode *pmrca12 = pn1->GetMRCA(pn2);
	TreeNode *pmrca13 = pn1->GetMRCA(pn3);
	TreeNode *pmrca23 = pn2->GetMRCA(pn3);
	// 
	int dummy;
	if( pmrca13 != pmrca12)
	{
		if(  pmrca13->IsAncesterOf(pmrca12, dummy) == true )
		{
			triple.first.first = pn1;
			triple.first.second = pn2;
			triple.second = pn3;
			return true;
		}
		else if( pmrca12->IsAncesterOf(pmrca13, dummy) == true )
		{
			triple.first.first = pn1;
			triple.first.second = pn3;
			triple.second = pn2;
			return true;
		}
		else
		{
			YW_ASSERT_INFO(false, "Impossible");
		}
	}
	//if( pmrca23 != pmrca12 &&  pmrca12->IsAncesterOf(pmrca23, dummy) == true )
	else if( pmrca23 != pmrca12 )
	{
		triple.first.first = pn1;
		triple.first.second = pn2;
		triple.second = pn3;
		return true;
	}
	// triple not found
	return false;
}

// different from Marginal tree, we allow mulfurcating trees here
// this can be convenient in some cases
bool ReadinPhyloTreesNewick( ifstream &inFile, int numLeaves, vector<PhylogenyTreeBasic *> &treePtrList, TaxaMapper *pTMapper)
{
	// NOTE: RETURN TRUE IF NO LABEL ADJUSTMENT IS DONE
	// RETURN FALSE IF WE SWITCHED LABEL BY DECREASING BY ONE
	// figure out leave num
	bool fNoChange = true;
	int nLvs = numLeaves;
	
	// read marginal trees in newick format
	// here there is no preamble, one line per tree
	while( inFile.eof() == false )
	{
		string treeNewick;
		inFile >> treeNewick;
		if( treeNewick.size() == 0 )
		{
			break;
		}
//cout << "newick tree = " << treeNewick << endl;

//#if 0
		// update numleaves
		multiset<string> setLabels;
		NewickUtils :: RetrieveLabelSet( treeNewick, setLabels);
		nLvs = setLabels.size();
//#endif
		//
		PhylogenyTreeBasic *pphTree = new PhylogenyTreeBasic;
		//if( fDup == false )
		//{
		pphTree->ConsOnNewick(treeNewick, -1, false, pTMapper);
//cout << "Done phylogenetic tree construction...\n";
//pphTree->OutputGML("tmp.gml");
		//}
		//else
		//{
		//	phTree.ConsOnNewickDupLabels(treeNewick, pTMapper);
		//}

		if( pTMapper != NULL)
		{
			pTMapper->SetInitialized(true);
		}
//string strTr;
//pphTree->ConsNewick(strTr);
//cout << "After reconstruction: strTr = " << strTr << endl;
		//see if zero is in, if not, must have 1 and decrease by 1
		set<int> lvids;
		pphTree->GetLeaveIds(lvids);
//cout << "lvids : ";
//DumpIntSet( lvids );
		int idInternal = lvids.size();
		YW_ASSERT_INFO( lvids.find(0) != lvids.end(), "Must adjust leaf label first (to start with 0)" );
		
		//	YW_ASSERT_INFO( lvids.find(1) != lvids.end(), "Wrong" );

		// decrease by one
		PhylogenyTreeIterator itorTree(*pphTree);
		itorTree.Init();
		//pphTree->InitPostorderWalk();
		while(itorTree.IsDone() == false)
		{
//				TreeNode *pn = pphTree->NextPostorderWalk( ) ;
			TreeNode *pn = itorTree.GetCurrNode() ;
			itorTree.Next();
			if( pn == NULL)
			{
				break;      // done with all nodes
			}
			if( pn->IsLeaf() == false )
			{
				pn->SetID( idInternal++ );
			}
		}

			// mark the change
		//	fNoChange = false;

		vector<int> nidsList, nparsList;
		pphTree->GetNodeParInfo(nidsList, nparsList);
		//phTree.GetNodeParInfoNew(nidsList, nparsList);
		//phTree.GetNodeParInfo(nidsList, nparsList);
		//if( nLvs <= 0 )
		//{
//string strTrNW;
//pphTree->ConsNewick(strTrNW);
//cout << "strTrNW: " << strTrNW << endl;
        treePtrList.push_back( pphTree );
//cout << "Newick format of this marginal tree: ";
//cout << tree.GetNewick() << endl;
	}
	return fNoChange;
}

// create a random tree
void InitRandomTree(PhylogenyTreeBasic &treeToInit, int numTaxa, int rndSeed )
{
    //
    if( rndSeed >= 0 )
    {
        InitRandom( rndSeed );
    }
    // create leaves first
    int idToUseNext = 0;
    vector<TreeNode *> listActiveNodes;
    for(int i=0; i<numTaxa; ++i)
    {
        //
        TreeNode *pLeaf = new TreeNode( idToUseNext++);
        // label it
        pLeaf->SetLabel( GetStringFromId( i ) );
        listActiveNodes.push_back( pLeaf );
    }
    // now create random coalescence
    while( listActiveNodes.size() > 1 )
    {
        // get two random nodes and coalesce them
        int rndpos1 = (int)( listActiveNodes.size()* GetRandFraction());
        YW_ASSERT_INFO( rndpos1 < (int)listActiveNodes.size(), "overflow");
        TreeNode *node1 = listActiveNodes[rndpos1];
        RemoveVecElementAt( listActiveNodes, rndpos1 );
        int rndpos2 = (int)( listActiveNodes.size()* GetRandFraction());
        YW_ASSERT_INFO( rndpos2 < (int)listActiveNodes.size(), "overflow");
        TreeNode *node2 = listActiveNodes[rndpos2];
        RemoveVecElementAt( listActiveNodes, rndpos2 );
        //
        TreeNode *pnodeNew = new TreeNode(idToUseNext++);
        vector<int> listEmpty;
        pnodeNew->AddChild(node1,listEmpty);
        pnodeNew->AddChild(node2,listEmpty);
        // add this node to list of active nodes
        listActiveNodes.push_back( pnodeNew );
    }
    // now here is the root
    YW_ASSERT_INFO(listActiveNodes.size() == 1, "Only one root");
    treeToInit.SetRoot( listActiveNodes[0]);
}

void CreatePhyTreeWithRootedSplits( PhylogenyTreeBasic &treeToProc, int numTaxa, const set< set<int> > &setGivenSplits )
{
    // create a phy tree with the given rooted splits
    // ASSUME: taxa starts from 0 to numTaxa-1
    // result can be a non-binary tree
    // first order them
    vector< set<set<int> > > listGivenSplits( numTaxa+1 );
    for( set<set<int> > :: const_iterator it = setGivenSplits.begin(); it != setGivenSplits.end(); ++it )
    {
        int sz = it->size();
        listGivenSplits[sz].insert(*it);
    }
    // if the whole set is not in, add it so that we have a single lin in the end
    if( listGivenSplits[numTaxa].size() == 0 )
    {
        //
        set<int> sall;
        PopulateSetWithInterval(sall, 0, numTaxa-1);
        listGivenSplits[numTaxa].insert( sall );
    }
//cout << "Set of given splits: ";
//for(int i=0; i<(int)listGivenSplits.size(); ++i)
//{
//if( listGivenSplits[i].size() > 0 )
//{
//for( set<set<int> > :: iterator it = listGivenSplits[i].begin(); it != listGivenSplits[i].end(); ++it)
//{
//DumpIntSet( *it );
//}
//}
//}
    
    // active list of lineages indexed by their set
    map< set<int>, TreeNode *> mapActiveLins;
    // initially all the leaf lins
    int idToUse = 0;
    for(int i=0; i<numTaxa; ++i)
    {
        TreeNode *pLeaf = new TreeNode(idToUse++);
        set<int> sint;
        sint.insert(i);
        string strLbl = GetStringFromId(i);
        pLeaf->SetLabel( strLbl );
        mapActiveLins.insert( map< set<int>, TreeNode *> :: value_type( sint, pLeaf ) );
    }
    // now scan through the entire list
    for(int k=2; k<(int)listGivenSplits.size(); ++k)
    {
        // start from 2 so that avoid trivial sets
        if( listGivenSplits[k].size() == 0 )
        {
            continue;
        }
        // for each input list, find those lins that is contained within the clusters
        for( set<set<int> > :: iterator it2 = listGivenSplits[k].begin(); it2 != listGivenSplits[k].end(); ++it2)
        {
            // each subset corresponds to a new internal node
            TreeNode *pnode = new TreeNode(idToUse++);
            
//cout << "list of active lins: ";
//for( map< set<int>, TreeNode *> :: iterator iggg = mapActiveLins.begin(); iggg != mapActiveLins.end(); ++iggg )
//{
//    DumpIntSet( iggg->first);
//}
//cout << "Considering given split: ";
//DumpIntSet( *it2 );
            // find the proper node in the previous set
            set< set<int> > setMatached;
            int szTot = 0;
            for( map< set<int>, TreeNode *> :: iterator it3= mapActiveLins.begin(); it3 != mapActiveLins.end(); ++it3 )
            {
                //
//cout <<  "treat this active lineage: ";
//DumpIntSet( it3->first );
                if( IsSetContainer( *it2, it3->first ) == true )
                {
//cout << "yes, continer!\n";
                    //
                    setMatached.insert( it3->first );
                    szTot += it3->first.size();
                    //
                    vector<int> sempty;
                    pnode->AddChild( it3->second, sempty );
                }
            }
            YW_ASSERT_INFO( szTot == (int)it2->size(), "Size: mismatch" );
            // remove the old ones and add the newly created one
            for( set< set<int> > :: iterator it4 = setMatached.begin(); it4 != setMatached.end(); ++it4 )
            {
                mapActiveLins.erase( *it4 );
            }
            mapActiveLins.insert( map< set<int>, TreeNode *> :: value_type( *it2, pnode ) );
        }
    }
    YW_ASSERT_INFO( mapActiveLins.size() == 1, "Wrong: must have only a single lineage left" );
    treeToProc.SetRoot( mapActiveLins.begin()->second );
    
//string strNW;
//treeToProc.ConsNewick(strNW);
//cout << "Result of createtreebyrootedplits: " << strNW << endl;
//cout << "SetGivenSplits: \n";
//for(set<set<int> > :: iterator it = setGivenSplits.begin(); it != setGivenSplits.end(); ++it)
//{
//DumpIntSet( *it);
//}
//cout << "numTaxa: " << numTaxa << endl;
}


// ***************************************************************************
void NewickUtils :: RetrieveLabelSet( const string &strNW, multiset<string> &setLabels )
{
//cout << "RetrieveLabelSet: strNW = " << strNW << endl;
	//
	setLabels.clear();

	string strIdDirect = strNW;
	int curpos = 0;
	int lastposOut = 0;
	//char *strIdBuf = (char *)strIdDirect.c_str();
	while( curpos<(int) strNW.length() )
	{
//cout << "curpos = " << curpos << endl;
		bool fIdentifier = false;
		if( (strNW[curpos] == '(' || strNW[curpos] == ',' ) && ( curpos == (int)strNW.length()-1 || strNW[curpos+1] != '(' )     )
		{
			fIdentifier = true;
		}
//cout << "Adding it: " << strId[curpos] << endl;
		lastposOut ++;
		curpos ++;

		// should we search for id
		if( fIdentifier == true )
		{
//cout << "Now searching for identifier\n";
			// now scan to the right to find the position to read the identifier
			while( curpos<(int) strNW.length() )
			{
				if(  strNW[curpos] != ')' && strNW[curpos] != ':' && strNW[curpos] != ',' )
				{
					curpos++;
				}
				else
				{
					break;
				}
			}
			// 
			//curpos--;
			string strFoundId;
//cout << "lastposOut = " << lastposOut << ", curpos = " << curpos << endl;
			strFoundId = strNW.substr( lastposOut, curpos-lastposOut );
			setLabels.insert( strFoundId );
			lastposOut = curpos;
//cout << "One identifier found: " << strFoundId << endl;
		}
	}
}

bool NewickUtils :: FindSplitIn( const string &strNW, string &strPart1, string &strPart2)
{
	// break up the NW into two parts by the center ,
	// return false if atomic
	int posSplit = -1;
	int level = 0;
	for(int i=0; i<(int)strNW.length(); ++i)
	{
		if( strNW[i] == '(')
		{
			level ++;
		}
		else if(strNW[i] == ')' )
		{
			level --;
		}
		else if( strNW[i] == ',' )
		{
			if( level == 1 )
			{
				posSplit = i;
				break;
			}
		}
	}

	if( posSplit < 0 )
	{
		return false;
	}
	// 
	int posLeft = strNW.find('(');
	int posRight = strNW.rfind(')');
	strPart1 = strNW.substr( posLeft+1, posSplit-posLeft-1 );
	strPart2 = strNW.substr( posSplit+1, posRight-posSplit-1 );

	return true;
}

void NewickUtils :: UpdateLabells( string &strNW, const map<string,string> &mapOldLabelToNew )
{
    // change the taxa name in the old newick format to the new ones as recorded in the map
    string strNWNew;
    string strIdDirect = strNW;
	int curpos = 0;
	int lastposOut = 0;
    map<string,string> &mapOldLabelToNewRef = const_cast<map<string,string> &>(mapOldLabelToNew);
    //bool fOutputCurChar = true;
	//char *strIdBuf = (char *)strIdDirect.c_str();
	while( curpos<(int) strNW.length() )
	{
        //cout << "curpos = " << curpos << endl;
		bool fIdentifier = false;
		if( (strNW[curpos] == '(' || strNW[curpos] == ',' ) && ( curpos == (int)strNW.length()-1 || strNW[curpos+1] != '(' )     )
		{
			fIdentifier = true;
		}
        
        // add it always since this is deliminator
        strNWNew += strNW[curpos];
        
        //cout << "Adding it: " << strId[curpos] << endl;
		lastposOut ++;
		curpos ++;
        
		// should we search for id
		if( fIdentifier == true )
		{
            //cout << "Now searching for identifier\n";
			// now scan to the right to find the position to read the identifier
			while( curpos<(int) strNW.length() )
			{
				if(  strNW[curpos] != ')' && strNW[curpos] != ':' && strNW[curpos] != ',' )
				{
					curpos++;
				}
				else
				{
					break;
				}
			}
			//
			//curpos--;
			string strFoundId;
            //cout << "lastposOut = " << lastposOut << ", curpos = " << curpos << endl;
			strFoundId = strNW.substr( lastposOut, curpos-lastposOut );
            
            //
            YW_ASSERT_INFO( mapOldLabelToNew.find(strFoundId) != mapOldLabelToNew.end(), "Fail to find the id in the map");
            strNWNew.append( mapOldLabelToNewRef[strFoundId] );
            
			lastposOut = curpos;
            //cout << "One identifier found: " << strFoundId << endl;
            
            // now move back by one letter
            //--curpos;
		}
	}

//cout << "UpdateLabells: before update, newick = " << strNW << ", after update: " << strNWNew << endl;
    strNW = strNWNew;
}

// ***************************************************************************

TaxaMapper :: TaxaMapper() 
{ 
	curId = 0; 
	fInit = false;
} 

// utility
bool TaxaMapper :: IsEmpty() 
{ 
	return mapStrToId.size() == 0; 
}

int TaxaMapper :: AddTaxaString(const string &str) 
{
//cout << "AddTaxaString : curId = " << curId  << " for new taxa string " << str << endl;
	if( mapStrToId.find( str ) == mapStrToId.end() )
	{
		mapStrToId.insert( map<string,int> :: value_type(str, curId) );
		mapIdToStr.insert( map<int,string> :: value_type(curId, str) );
		curId ++;
	}
	//else
	//{
	return mapStrToId[str];
	//}
}


int TaxaMapper :: GetId(const string &str)
{
//cout << "Num of entries in str mapper : " << mapStrToId.size() << endl;
//for( map<string,int> :: iterator it =mapStrToId.begin(); it != mapStrToId.end(); ++it )
//{
//cout << it->first << ", " << it->second << endl;
//}

	if(mapStrToId.find(str) == mapStrToId.end() )
	{
		cout << "This taxa: " << str << " seems to be wrong\n";
		YW_ASSERT_INFO( false, "Fail to find the taxa" );
	}
	return mapStrToId[str];
}
bool TaxaMapper :: IsIdIn( int id)
{
	return mapIdToStr.find(id) != mapIdToStr.end();
}
string TaxaMapper :: GetString(const int id)
{
	if(mapIdToStr.find(id) == mapIdToStr.end() )
	{
		cout << "This taxa id: " << id << " seems to be wrong\n";
		YW_ASSERT_INFO( false, "Fail to find the taxa" );
	}
	return mapIdToStr[id];
}

string TaxaMapper :: ConvIdStringWithOrigTaxa(const string &strId)
{
//cout << "Num of entries in str mapper : " << mapIdToStr.size() << endl;
//for( map<int,string> :: iterator it =mapIdToStr.begin(); it != mapIdToStr.end(); ++it )
//{
//cout << it->first << ", " << it->second << endl;
//}
	// convert a string with id (i.e. integer-based identifier) back
	// to user-specified format
	// Simple approach: find everything bebetween ( and , (or :),  and ) and convert to
	string res;
	string strIdDirect = strId;
	int curpos = 0;
	int lastposOut = 0;
//	char *strIdBuf = (char *)strIdDirect.c_str();
	while( curpos<(int) strId.length() )
	{
//cout << "curpos = " << curpos << ", res = " << res << endl;
		bool fIdentifier = false;
		if( (strId[curpos] == '(' || strId[curpos] == ',' ) && ( curpos == (int)strId.length()-1 || strId[curpos+1] != '(' )     )
		{
			fIdentifier = true;
		}
//cout << "Adding it: " << strId[curpos] << endl;
		res += strId[curpos];
		lastposOut ++;
		curpos ++;

		// should we search for id
		if( fIdentifier == true )
		{
//cout << "Now searching for identifier\n";
			// now scan to the right to find the position to read the identifier
			while( curpos<(int) strId.length() )
			{
				if(  strId[curpos] != ')' && strId[curpos] != ':' && strId[curpos] != ',' )
				{
					curpos++;
				}
				else
				{
					break;
				}
			}
//cout << "lastposOut: " << lastposOut << ", curpos = " << curpos << endl;
			// 
			//curpos--;
			int idnum = -1;
			string strSub = strId.substr(lastposOut, curpos-lastposOut);
			//char buftmp[100];
			//memcpy(buftmp, &strIdBuf[lastposOut], curpos-lastposOut );
			//sscanf(buftmp, "%d", &idnum);
			sscanf(strSub.c_str(), "%d", &idnum);
			string idNew = GetString(idnum);
//cout << "After searching, curpos = " << curpos << ", buftmp = " << buftmp  << ", idnum = " << idnum << ", idNew = " << idNew << endl;
//cout << "After searching, curpos = " << curpos << ", strSub = " << strSub  << ", idnum = " << idnum << ", idNew = " << idNew << endl;
			//char buf[100];
			//sprintf(buf, "%d", idNew);
			res += idNew;
			lastposOut = curpos;
		}
	}
	return res;
}

string TaxaMapper :: ExtractIdPartFromStr(const string &strIdNW)
{
    // extract id part of the string
    string strToUse = strIdNW;
    size_t posSeparator = strIdNW.find( ':' );
    
	if( posSeparator != string::npos )
	{
		strToUse = strIdNW.substr(0, (int)posSeparator  );
	}
    return strToUse;
}


int TaxaMapper :: GetIdFromStr( const string &strPart, TaxaMapper *pTMapper )
{
//cout << "GetIdFromStr: " << strPart << endl;
    
	string strToUse = strPart;
	size_t posSeparator = strPart.find( ':' );
    
	if( posSeparator != string::npos )
	{
		strToUse = strPart.substr(0, (int)posSeparator  );
	}
    
    // 05/07/15: it is also possible user add gene index (in # sign)
    size_t posSeparator2 = strToUse.find('#');
    if( posSeparator2 != string::npos )
	{
		strToUse = strToUse.substr(0, (int)posSeparator2  );
	}
//cout << "strPart: " << strPart << ",strUse: " << strToUse << endl;
    
	// get rid of 
	int res = -1;
	if( pTMapper == NULL)
	{
		sscanf( strToUse.c_str(), "%d", &res  );
//cout << "Empty mapper\n";
	}
	else
	{
		// are we reading in the first tree or not
		if( pTMapper->IsInitialized() == true )
		{
			res  = pTMapper->GetId(strToUse);
//cout << "GetIdFromStr: GetId: " << strToUse << ": " << res << endl;
		}
		else
		{
			// this is new
			res = pTMapper->AddTaxaString( strToUse );
//cout << "GetIdFromStr: New id: " << strToUse << ": " << res << endl;
		}
	}
	return res;
}

void TaxaMapper :: GetAllTaxaIds(set<int> &taxaIndices) const
{
	//
	taxaIndices.clear();
	for( map<int, string> :: const_iterator it = mapIdToStr.begin(); it != mapIdToStr.end(); ++it)
	{
		taxaIndices.insert(it->first);
	}
}

void TaxaMapper :: GetAllTaxaStrs(set<string> &setStrs) const
{
    //
    setStrs.clear();
	for( map<int, string> :: const_iterator it = mapIdToStr.begin(); it != mapIdToStr.end(); ++it)
	{
		setStrs.insert(it->second);
	}
}


void TaxaMapper :: InitToDec1Mode(int numTaxa)
{
    // assume taxa is in the format as 1, 2, 3 and so on
    // init as follows: 1 ==> 0, 2 ==> 1 and so on
    for(int taxa = 1; taxa <=numTaxa; ++taxa)
    {
        char buf[100];
        sprintf(buf, "%d", taxa);
        string strid = buf;
        AddTaxaString( strid );
    }
    SetInitialized(true);
}

void TaxaMapper :: Dump() const
{
    //
    cout << "curId = " << curId;
    if( fInit == true)
    {
        cout << "initialized. ";
    }
    else
    {
        cout << "not initialized yet. ";
    }
    for( map<string, int> :: const_iterator it = mapStrToId.begin(); it != mapStrToId.end(); ++it )
    {
        //
        cout << "Mapping taxa " << it->first << " to id: " << it->second << "  ";
    }
    cout << endl;
}

// ***************************************************************************
// Tree class functions
// ***************************************************************************
TreeNode :: TreeNode() :  parent(NULL), id(-1), label("-"), shape(PHY_TN_DEFAULT_SHAPE), lenBranchAbove(-1.0)
{
}

TreeNode :: TreeNode(int iid)  : parent(NULL), id(iid), label("-"), shape(PHY_TN_DEFAULT_SHAPE), lenBranchAbove(-1.0)
{
//    id = iid;
//    cout << "Creating tree node " << iid << endl;
}

TreeNode :: ~TreeNode()
{
//    cout << "Deleting tree node " << id << endl;
    // We recursively delete all its children here
    for(int i=0; i<(int)listChildren.size(); ++i)
    {
        delete listChildren[i];
    }
    listChildren.clear();
}

void TreeNode:: Dump() const
{
    //
    cout << "<node: " <<  GetLabel() << ", id=" << GetID();
    if( lenBranchAbove >= 0.0)
    {
        cout << ", length = " << lenBranchAbove;
    }
    cout << ", num of child = " << GetChildrenNum() << ">   ";
}

void TreeNode :: AddChild( TreeNode *pChild, const vector<int> &labels)
{
    // This function add an edge. The edge can be labeled with a set of labels (for now, only integers)
    YW_ASSERT( pChild != NULL);

    // make sure this child is not already a children
    // not sure if really need it

    pChild->parent = this;
    listChildren.push_back( pChild );
    listEdgeLabels.push_back( labels );
}
    
void TreeNode :: RemoveChild(TreeNode *pChild)
{
	YW_ASSERT_INFO(pChild != NULL, "RemoveChild: wrong");
	pChild->parent = NULL;
    vector< TreeNode *> listChildrenNew;
    vector< vector<int> > listEdgeLabelsNew;       
	YW_ASSERT_INFO( listChildrenNew.size() == listEdgeLabelsNew.size(), "must be same size" );
	for(int i=0; i<(int) listChildren.size(); ++i)
	{
		if( listChildren[i] != pChild )
		{
			listChildrenNew.push_back( listChildren[i] );
			listEdgeLabelsNew.push_back( listEdgeLabels[i] );
		}
	}
	// update
	listChildren = listChildrenNew;
	listEdgeLabels = listEdgeLabelsNew;
}

void TreeNode :: RemoveAllChildren()
{
    // remove all children of this node
    //listChildren.clear();
    //listEdgeLabels.clear();
    while( GetChildrenNum() > 0 )
    {
        TreeNode *pc = GetChild(0);
//cout << "Removing pc = ";
//pc->Dump();
//cout << endl;
        RemoveChild(pc);
    }
//cout << "Done with removeallchildren\n";
}

void TreeNode :: GetDescendentLabelSet( set<int> &labelSet ) 
{
    // This function accumulate the set of descendents in the label sets
    // CAUTION: assume labelset is EMPTY!!!!
    //if( IsLeaf() == true)
    //{
    string lbl = GetLabel();
//cout << "lbl = " << lbl << endl;

    if( lbl != "-" && lbl != "?" && lbl != "()" && lbl != "(?)" )
    {
        const char *buf = lbl.c_str();
        int rowIndex;
        if( buf[0] < '0' || buf[0] > '9' )
        {
            sscanf( buf+1, "%d", &rowIndex );
        }
        else
        {
            // This is a plain label, use it
            sscanf( buf, "%d", &rowIndex );
        }
//cout << "rowIndex = " << rowIndex << endl;
        labelSet.insert( rowIndex );
    }
    else if( nodeValues.size() >= 1 )
    {
            // simply insert a single value here
            //labelSet.insert( nodeValues[0] );
    }

#if 0
        // set every label into the set
        for(int i=0; i<nodeValues.size(); ++i)
        {
            if( nodeValues[i] >= 0 )
            {
                labelSet.insert( nodeValues[i] );
            }
        }
#endif
    //}
    //else
    if( IsLeaf() == false)
    {
        for(int i=0; i<GetChildrenNum(); ++i)
        {
            GetChild(i)->GetDescendentLabelSet( labelSet );
        }
    }
}

bool TreeNode :: IsAncesterOf(TreeNode *pAssumedDescend, int &branchIndex)
{
    // This function check to see if pAssumedDescend is descedent of the current node
    // If so, we also find the branch index that comes to this node
    if( pAssumedDescend == NULL)
    {
        return false;
    }
    if( pAssumedDescend == this)
    {
        branchIndex = -1;
        return true;
    }

    TreeNode *pCurrent = pAssumedDescend;
    TreeNode *pParent = pAssumedDescend->parent;

    while(pParent != NULL)
    {
        if(pParent == this)
        {
            // Find out which branch leads to it
            branchIndex = -1;
            for(int i=0; i<(int)listChildren.size();++i)
            {
                if(listChildren[i] == pCurrent)
                {
                    branchIndex = i;
                }
            }
            YW_ASSERT( branchIndex >= 0);
            // Tell the good news
            return true;
        }
        pCurrent = pParent;
        pParent = pParent->parent;
    }
    

    return false;
}

void TreeNode :: GetAllDescendents(set<TreeNode *> &setDescendents)
{
	// Note: include itself
	setDescendents.insert( this );
    for(int i=0; i<(int)listChildren.size();++i)
    {
		listChildren[i]->GetAllDescendents( setDescendents );
	}
}

void TreeNode :: GetAllLeavesUnder(set<TreeNode *> &setDescendents)
{
	// Note: include itself
    if( this->IsLeaf() == true )
    {
        setDescendents.insert( this );
    }
    for(int i=0; i<(int)listChildren.size();++i)
    {
		listChildren[i]->GetAllLeavesUnder( setDescendents );
	}
}

void TreeNode :: GetAllLeavesIdUnder(set<int> &setDescendents)
{
    set<TreeNode *> ss;
    GetAllLeavesUnder(ss);
    setDescendents.clear();
    for(set<TreeNode *> :: iterator it = ss.begin(); it != ss.end(); ++it)
    {
        setDescendents.insert( (*it)->GetID() );
    }
}

void TreeNode :: GetAllLeafLabeles(vector<string> &listLeafLabels)
{
	//
	if(IsLeaf() == true)
	{
		listLeafLabels.push_back(GetLabel());
	}
	else
	{
		for(int i=0; i<(int)listChildren.size();++i)
		{
			listChildren[i]->GetAllLeafLabeles( listLeafLabels );
		}
	}
}


string TreeNode :: GetShapeLabel(const set<int> &idTerms, map<int,int> &mapNodeLabel) const
{
//cout << "idTerms = ";
//DumpIntSet( idTerms );
	string res;

	// return a shape label:
	// at present, shape label is like ((),(())). That is, no leaf labels
	// just the type of topology. Note if we have (S1,S2), then S1 <= S2
	if( idTerms.find(GetID() ) != idTerms.end() )
	{
		int idNum = 1;
		if(mapNodeLabel.find(GetID() ) != mapNodeLabel.end() )
		{
			idNum = mapNodeLabel[ GetID() ];
		}
		char buf[100];
		sprintf(buf, "%d", idNum);
		res = buf;
		//string str1 = "A";
		//return str1;
	}
	//else
	//	{
	//		string strEmpty;
	//		res = strEmpty;
	//	}
	//}
	else
	{
		// otherwise get its descendent
		vector<string> listLabels; 
		for(int i=0; i<(int)listChildren.size();++i)
		{
			listLabels.push_back( listChildren[i]->GetShapeLabel( idTerms, mapNodeLabel ) ) ;
		}
		// now sort it
		for(int i=0;i<(int)listLabels.size();++i)
		{
			for(int j=i+1; j<(int)listLabels.size();++j)
			{
				// swap if needed
				if( listLabels[i] > listLabels[j] )
				{
					string tmp = listLabels[i];
					listLabels[i] = listLabels[j];
					listLabels[j] = tmp;
				}
			}
		}

		// how many are not empty?
		int numNonEmpty = 0;
		for( int i=0; i<(int)listLabels.size(); ++i )
		{
			if( listLabels[i].length() > 0 )
			{
				numNonEmpty ++;
			}
		}

		// add it
		bool fStart = false;
		for( vector<string> :: iterator it = listLabels.begin(); it != listLabels.end(); ++it )
		{
			if( it->length() > 0 )
			{
				if( fStart == false)
				{
					if(  numNonEmpty > 1 )
					{
						// add a header
						res = "(";
					}
				}
				else
				{
					res += ",";
				}
				res += *it;

				fStart = true;
			}
		}
		if( fStart == true  && numNonEmpty > 1)
		//if( fStart == true  )
		{
			res += ")";
		}
	}
//cout << "res label for this node: " << res << endl;
	return res;
}


// differeent from above, this one will apply label to the string label
string TreeNode :: GetShapeLabel(const set<int> &idTerms, bool fSort) const
{
//cout << "idTerms = ";
//DumpIntSet( idTerms );
	string res;

	// return a shape label:
	// at present, shape label is like ((),(())). That is, no leaf labels
	// just the type of topology. Note if we have (S1,S2), then S1 <= S2
	if( idTerms.find(GetID() ) != idTerms.end() )
	{
		//int idNum = 1;
        if( fSort == true)
        {
            res = "1";
        }
        else
        {
            char buf[100];
            sprintf(buf, "%d", GetID() );
            res = buf;
        }
	}

	else
	{
		// otherwise get its descendent
		vector<string> listLabels; 
		for(int i=0; i<(int)listChildren.size();++i)
		{
			listLabels.push_back( listChildren[i]->GetShapeLabel( idTerms, fSort ) ) ;
		}
		// now sort it
        if( fSort == true )
        {
            for(int i=0;i<(int)listLabels.size();++i)
            {
                for(int j=i+1; j<(int)listLabels.size();++j)
                {
                    // swap if needed
                    if( listLabels[i] > listLabels[j] )
                    {
                        string tmp = listLabels[i];
                        listLabels[i] = listLabels[j];
                        listLabels[j] = tmp;
                    }
                }
            }
        }

		// how many are not empty?
		int numNonEmpty = 0, numEmpty = 0;
		for( int i=0; i<(int)listLabels.size(); ++i )
		{
			if( listLabels[i].length() > 0 )
			{
				numNonEmpty ++;
			}
			else
			{
				numEmpty ++;
			}
		}

		// add it
		bool fStart = false;
		//bool fFirst = true;
        bool fParenth = false;
		//bool fSpaceAdded = false;
		for( vector<string> :: iterator it = listLabels.begin(); it != listLabels.end(); ++it )
		{
            // YW: only add "(" if there are more than 1 non-empty below
			if( fStart == false && it->length()> 0 )
			{
                // YW: just add a "("
				//if(  (numNonEmpty >= 1 && numEmpty > 0 ) || numNonEmpty >= 2  )
				//{
                // add a header
                if( numNonEmpty > 1 )
                {
                    res = "(";
                    fParenth = true;
                }
                res += *it;
                fStart = true;
				//}
			}
			else if(  fStart == true )
			{
                // YW: only add "," if there is something
				if( it->length()>0)
				{
					res += ",";
				}
				//fFirst = false;
				if(  it->length() > 0 )
				{

					res += *it;
					//fStart = true;
				}
                // YW: donot add anything if the branch is empty
#if 0
				else
				{
					// for empty branches, put a mark to it
					// when there is something under it (that is shrink the entire subtree of unknown to a symbol -
					if(numNonEmpty >= 1 && fSpaceAdded == false)
					{
						// 
						res += ",-";
						fSpaceAdded = true;
					}
				}
#endif
			}
		}
		//if( fStart == true  && numNonEmpty >= 1)
		if( fParenth == true  )
		{
			res += ")";
		}
	}
//cout << "res label for this node: " << res << endl;
	return res;
}

string TreeNode:: GetShapeLabelNodeBrNum( map<TreeNode *, pair<int,int> > &mapNodeNumBrannches, vector<int> &listOrderedLeaves)
{
    // format: <num of underlying branches, event id>, negative for internal nodes
    // the ordered leaves: correspond to their order of appearing in the output newick shape string
    // this can be useful when you want to know how to match the leaves when some sort of comparision is needed
    // get shape label. Different from above, the input is: <treenode, #ofbranches out of this node>
    // convention: if #br < 0, it means all branches have descendents
    listOrderedLeaves.clear();
    if( this->IsLeaf() == true)
    {
        YW_ASSERT_INFO( mapNodeNumBrannches.find(this) != mapNodeNumBrannches.end(), "Leaf: not in map" );
//cout << "Find one leaf: " << mapNodeNumBrannches[this].second << endl;
        listOrderedLeaves.push_back( mapNodeNumBrannches[this].second );
        return string("()");
    }
    else
    {
        YW_ASSERT_INFO(mapNodeNumBrannches.find(this) != mapNodeNumBrannches.end(), "Fail to find222");
        //const TreeNode *pn = const_cast<const TreeNode *>( this );
        int numBrWOChildRecur = mapNodeNumBrannches[this].first;
//cout << "numBrWOChildRecur = " << numBrWOChildRecur << endl;
        multiset<string> setDescStrings;
        map<string, set< vector<int> > > mapStringToVecLeaves;
        for(int i=0; i<(int)GetChildrenNum(); ++i)
        {
            //
            TreeNode *pnchild = GetChild(i);
            //
            if( mapNodeNumBrannches.find(pnchild) != mapNodeNumBrannches.end() )
            {
                //
                vector<int> listOrderedLeavesStep;
                string str = pnchild->GetShapeLabelNodeBrNum(mapNodeNumBrannches, listOrderedLeavesStep);
                setDescStrings.insert(str);
                if( mapStringToVecLeaves.find( str) == mapStringToVecLeaves.end() )
                {
                    //
                    set<vector<int> > ssint;
                    mapStringToVecLeaves.insert( map<string, set<vector<int> > > :: value_type(str, ssint) );
                }
                mapStringToVecLeaves[str].insert( listOrderedLeavesStep );
                
                //
                --numBrWOChildRecur;
            }
        }
        // add the remaiing by just filling the item
        //vector<int> listLvIds;
        for(int i=0; i<numBrWOChildRecur; ++i)
        {
            string strLv = "()";
            setDescStrings.insert(strLv);
            
            //
            if( mapStringToVecLeaves.find( strLv) == mapStringToVecLeaves.end() )
            {
                //
                set<vector<int> > ssint;
                mapStringToVecLeaves.insert( map<string, set<vector<int> > > :: value_type(strLv, ssint) );
            }
            vector<int> vec1;
            vec1.push_back( mapNodeNumBrannches[this].second );
            mapStringToVecLeaves[strLv].insert( vec1 );
        }
//cout << "setdescstrings: ";
//for(multiset<string> :: iterator itgg = setDescStrings.begin(); itgg != setDescStrings.end(); ++itgg)
//{
//cout << *itgg << "   ";
//}
//cout << endl;
        // now creat the contacation
        YW_ASSERT_INFO(setDescStrings.size() > 1, "Can not be empty");
        string res = "(";
        for(multiset<string> :: iterator it = setDescStrings.begin(); it !=setDescStrings.end(); ++it)
        {
            if( it != setDescStrings.begin() )
            {
                res += ",";
            }
            res += *it;
        }
        res += ")";
        
        // now assemble the list of ordered nodes
        for( map<string, set<vector<int> > > :: iterator itg = mapStringToVecLeaves.begin(); itg != mapStringToVecLeaves.end(); ++itg  )
        {
            for( set<vector<int> > :: iterator itg2 = itg->second.begin(); itg2 != itg->second.end(); ++itg2 )
            {
//cout << "In GetShapeLabelNodeBrNum: find a vector of sites: ";
//DumpIntVec(*itg2);
                ConcatIntVec( listOrderedLeaves, *itg2 );
            }
        }
        
        return res;
    }
}

int TreeNode :: GetLevel() const
{
	// choose a not efficient but simple coding
	int res = 0;
	for(int i=0; i<(int)listChildren.size();++i)
	{
		int lvDesc = listChildren[i]->GetLevel( );
		if( lvDesc + 1 > res )
		{
			res = lvDesc + 1;
		}
	}
	return res;
}

void TreeNode :: GetEdgeLabelsToChild( TreeNode *pChild, vector<int> &lbls )
{
	YW_ASSERT_INFO(listChildren.size() == listEdgeLabels.size(), "Child num and edge label num do not match");
	lbls.clear();
	for(int i=0; i<(int)listChildren.size();++i)
	{
		if(listChildren[i] == pChild  )
		{
			GetEdgeLabelsAtBranch(i, lbls);
		}
	}
	//YW_ASSERT_INFO(false, "GetEdgeLabelsToChild :: Fail to find such child");
}

TreeNode * TreeNode :: GetMRCA(TreeNode *pOther)
{
	TreeNode *pRes = this;
	int dummy;
	while( pRes != NULL && pRes->IsAncesterOf( pOther, dummy ) ==  false )
	{
		pRes = pRes->GetParent();
	}
	YW_ASSERT_INFO(pRes != NULL, "Fail to find MRCA");
	return pRes;
}

void TreeNode :: GetSiblings( vector<TreeNode *> &listSibs )
{
	// siblings are parent's children (except itself)
	listSibs.clear();
	if( this->GetParent() != NULL )
	{
		//
		for(int i=0; i<this->GetParent()->GetChildrenNum(); ++i)
		{
			TreeNode *pn = this->GetParent()->GetChild(i);
			if( pn != this)
			{
				listSibs.push_back( pn );
			}
		}
	}

}

void TreeNode :: Order()
{
	// do nothing if leaf
	if( IsLeaf() == true )
	{
		return;
	}
	// first order the leaves
	for(int i=0; i<(int)listChildren.size();++i)
	{
		listChildren[i]->Order();
	}

	// 
	vector<multiset<string> > listDescLeaves;
	for(int i=0; i<(int)listChildren.size();++i)
	{
		vector<string> vecLeafStrings;
		listChildren[i]->GetAllLeafLabeles(vecLeafStrings);
		multiset<string> setLeafStrings;
		for(int j=0; j<(int)vecLeafStrings.size(); ++j)
		{
			setLeafStrings.insert(vecLeafStrings[j]);
		}
		listDescLeaves.push_back(setLeafStrings);
	}
	// 
	YW_ASSERT_INFO(listEdgeLabels.size() == listChildren.size(), "Same size must be");
	for(int i=0; i<(int)listChildren.size();++i)
	{
		for(int j=i+1; j<(int)listChildren.size();++j)
		{
			// 
			if( listDescLeaves[i] > listDescLeaves[j] )
			{
				// exhcnage everything
				TreeNode *ptmp = listChildren[i];
				listChildren[i] = listChildren[j];
				listChildren[j] = ptmp;

				vector<int> vtmp = listEdgeLabels[i];
				listEdgeLabels[i] = listEdgeLabels[j];
				listEdgeLabels[j] = vtmp;

				// 
				multiset<string> stmp = listDescLeaves[i];
				listDescLeaves[i] = listDescLeaves[j];
				listDescLeaves[j] = stmp;
			}
		}
	}
}

int TreeNode :: GetIntLabel() const
{
	int res = -1;
	sscanf(label.c_str(), "%d", &res );
	return res;
}

bool TreeNode :: IsMulfurcate()
{
	if( IsLeaf() == true)
	{
		return false;
	}
	else
	{
		if( GetChildrenNum() > 2)
		{
			return true;
		}
		for(int ii=0; ii<GetChildrenNum(); ++ii)
		{
			if( GetChild(ii)->IsMulfurcate() == true )
			{
				return true;
			}
		}

		return false;
	}
}

TreeNode * TreeNode :: GetRoot() const
{
    TreeNode *pself = const_cast<TreeNode *>(this);
    TreeNode *proot = pself;
    while( proot->GetParent() != NULL )
    {
        proot = proot->GetParent();
    }
    YW_ASSERT_INFO(proot != NULL, "Root is null");
    return proot;
}

void TreeNode :: GetAllAncestors(set<TreeNode *> &listAncestors)
{
    if( GetParent() != NULL )
    {
        listAncestors.insert(GetParent() );
        GetParent()->GetAllAncestors(listAncestors);
    }
}

void TreeNode :: GetAllChildren(set<TreeNode *> &setChildren) const
{
    //
    //TreeNode *pthis = const_cast<TreeNode *>(this);
    //PopulateSetByVecGen( setChildren, pthis->listChildren );
    setChildren.clear();
    for(int i=0; i<GetChildrenNum(); ++i)
    {
        setChildren.insert( listChildren[i] );
    }
}

int TreeNode :: GetChildIndex(TreeNode *pchild) const
{
    // get the index of this particular child; if not found, the error
    TreeNode *pself = const_cast<TreeNode *>(this);
    int res = -1;
    for(int i=0; i<(int)listChildren.size(); ++i)
    {
        if( pself->GetChild(i) == pchild )
        {
            res = i;
            break;
        }
    }
    YW_ASSERT_INFO(res >=0, "Fail to find666");
    return res;
}

void TreeNode :: RemoveLabels()
{
    // remove all edge labels (i.e. make them empty)
    int numLLs = listEdgeLabels.size();
    listEdgeLabels.clear();
    listEdgeLabels.resize( numLLs );
    
    // then reurrisve do it
    for(int i=0; i<GetChildrenNum(); ++i)
    {
        GetChild(i)->RemoveLabels();
    }
}

void TreeNode :: RemoveLabelsPar()
{
    // remove the parent to this node's label
    TreeNode *ppar = GetParent();
    if( ppar == NULL )
    {
        return;
    }
    int childIndex = ppar->GetChildIndex(this);
    YW_ASSERT_INFO( childIndex <(int) ppar->listEdgeLabels.size(), "Overflow" );
    ppar->listEdgeLabels[childIndex].clear();
}

void TreeNode :: Binarize(int &idToUseNext)
{
    // recursively make the tree binary
    // if this node has more than 2 children, create a new internal node
    if( GetChildrenNum() > 2 )
    {
        //
        TreeNode *pnode = new TreeNode(idToUseNext++);
        for(int i=1; i<GetChildrenNum(); ++i)
        {
            vector<int> ss;
            pnode->AddChild( GetChild(i), ss );
        }
        TreeNode *pn1 = GetChild(0);
        this->listChildren.clear();
        this->listChildren.push_back( pn1 );
        vector<int> ss;
        AddChild( pnode, ss );
    }
    
    for( int i=0; i<GetChildrenNum(); ++i )
    {
        //
        GetChild(i)->Binarize( idToUseNext );
    }
}

int TreeNode :: GetMaxIdWithinSubtree( ) const
{
    //
    int res = GetID();
    TreeNode *pthis = const_cast<TreeNode *> (this);
    for( int i=0; i<GetChildrenNum(); ++i)
    {
        TreeNode *pnc = pthis-> GetChild(i) ;
        int nc = pnc->GetMaxIdWithinSubtree();
        if( nc > res  )
        {
            //
            res = nc;
        }
    }
    return res;
}

int TreeNode :: GetNumNodesUnder(bool fInternalOnly, bool fAddNonBinary) const
{
    // fInternalOnly: true if only count internal node
    // include itself if this is an internal node
    // fAddNonBinary: true if an internal node is considered to have multiple (hidden) nodes
    int res = 0;
    if( fInternalOnly == false || IsLeaf() == false )
    {
        res = 1;
    }
    // recursively check all children
    TreeNode *pn = const_cast<TreeNode *>(this);
    for(int i=0; i<GetChildrenNum(); ++i)
    {
        res += pn->GetChild(i)->GetNumNodesUnder(fInternalOnly, fAddNonBinary);
    }
    return res;
}


// ***************************************************************************
// Utilites functions
// ***************************************************************************

void PhylogenyTreeIteratorBacktrack :: Init()
{
    while( stackNodesToExplore.empty() == false)
    {
        stackNodesToExplore.pop();
    }
//cout << "Nnow stack empty.\n";
    // Now recurisvely store the order of the walk
	TreeNode *rootNode = phyTree.GetRoot();
    if( rootNode != NULL)
    {
		stackNodesToExplore.push(rootNode);
    }
}

void PhylogenyTreeIteratorBacktrack :: Next()
{
    if( stackNodesToExplore.empty() == true)
    {
        return;
    }
    TreeNode *pn = stackNodesToExplore.top();
	// push its descendent in
    stackNodesToExplore.pop();
    for(int i=0; i<(int)pn->GetChildrenNum(); ++i)
	{
		//
		stackNodesToExplore.push( pn->GetChild(i) );
	}
}
void PhylogenyTreeIteratorBacktrack :: Back()
{
    if( stackNodesToExplore.empty() == true)
    {
        return;
    }
	// simply get rid of the current node
    stackNodesToExplore.pop();
}

bool PhylogenyTreeIteratorBacktrack :: IsDone()
{
	return stackNodesToExplore.empty();
}

TreeNode *PhylogenyTreeIteratorBacktrack :: GetCurrNode()
{
	if( IsDone() == false)
	{
		return stackNodesToExplore.top();
	}
	else
	{
		return NULL;
	}
}

///////////////////////////////////////////////////////////////////
void PhylogenyTreeIterator :: Init()
{
    while( stackPostorder.empty() == false)
    {
        stackPostorder.pop();
    }
//cout << "Nnow stack empty.\n";
    // Now recurisvely store the order of the walk
	TreeNode *rootNode = phyTree.GetRoot();
    if( rootNode != NULL)
    {
        phyTree.PostOrderPushStack( rootNode,  stackPostorder);
    }
}

void PhylogenyTreeIterator :: Next()
{
    if( stackPostorder.empty() == true)
    {
        return;
    }
    //TreeNode *pn = stackPostorder.top();
    stackPostorder.pop();
}

bool PhylogenyTreeIterator :: IsDone()
{
	return stackPostorder.empty();
}

TreeNode *PhylogenyTreeIterator :: GetCurrNode()
{
	if( IsDone() == false)
	{
		return stackPostorder.top();
	}
	else
	{
		return NULL;
	}
}



// ***************************************************************************
// Main functions
// ***************************************************************************

PhylogenyTreeBasic :: PhylogenyTreeBasic() :  rootNode(NULL), numLeaves(-1)
{
}

PhylogenyTreeBasic :: ~PhylogenyTreeBasic()
{
    // Should delete the tree
    if( rootNode != NULL)
    {
        delete rootNode;
        rootNode = NULL;
    }
}

void PhylogenyTreeBasic :: PostOrderPushStack( TreeNode *treeNode,  stack<TreeNode *> &stackPostorder)
{
    stackPostorder.push( treeNode);
//cout << "Pusing node " << treeNode->GetLabel() << endl;

    for(int i=0; i<(int)treeNode->listChildren.size(); ++i)
    {
        PostOrderPushStack( treeNode->listChildren[i],  stackPostorder);
    }
}

void PhylogenyTreeBasic :: ConsOnNewick( const string &nwString, int numLeaves, bool fBottomUp, TaxaMapper *pTMapper )
{
    // Here we try to reconstruct from a newick string here
    // This function creates the tree by creating and linking tree nodes
    // Make sure the tree is empty
    if( rootNode != NULL)
    {
        delete rootNode;
        rootNode = NULL;
    }

    // we perform this by recursively
    int invId = 10000;
	if( numLeaves > 0)
	{
		// here we assume leaf id starts from 0, will check it
		invId = numLeaves ;
	}
	int leafId = 0;
	rootNode = ConsOnNewickSubtree( nwString, leafId, invId, numLeaves, fBottomUp, pTMapper );
}

void PhylogenyTreeBasic :: ConsOnNewickDupLabels( const string &nwString, TaxaMapper *pTMapper  )
{
    // Here we try to reconstruct from a newick string here
    // This function creates the tree by creating and linking tree nodes
    // Make sure the tree is empty
    if( rootNode != NULL)
    {
        delete rootNode;
        rootNode = NULL;
    }

    // we perform this by recursively
	int numLeaves = GetNewickNumLeaves(nwString);
	// we start counting leaves from 0 
    int invId = numLeaves;
	int leafId = 0;
//cout << "Num of leaves = " << numLeaves << endl;
	rootNode = ConsOnNewickSubtreeDupLabels( nwString, invId, leafId, pTMapper );
}


void PhylogenyTreeBasic :: InitPostorderWalk( )
{
//cout << "InitPostorderWalk() entry\n";
    // when walk, return the value of the node if any
    // Clearup the previous storage if any
    while( stackPostorder.empty() == false)
    {
        stackPostorder.pop();
    }
//cout << "Nnow stack empty.\n";
    // Now recurisvely store the order of the walk
    if( rootNode != NULL)
    {
        PostOrderPushStack( rootNode,  stackPostorder);
    }
}

TreeNode *PhylogenyTreeBasic :: NextPostorderWalk( )
{
    // Return false, when nothing to go any more
    if( stackPostorder.empty() == true)
    {
        return NULL;
    }
    TreeNode *pn = stackPostorder.top();
    stackPostorder.pop();

//    node = pn;
#if 0
    if( pn->nodeValues.size() > 0 )
    {
        // There is valid node value stored here
        nodeValue = pn->nodeValues[0];
    }
    else
    {
        nodeValue = -1;     // no node value is stored here
    }
#endif
    return pn;
}

void PhylogenyTreeBasic :: OutputGML ( const char *inFileName )
{
	// Now output a file in GML format
	// First create a new name
	string name = inFileName;
//cout << "num edges = " << listEdges.size() << endl;

	DEBUG("FileName=");
	DEBUG(name);
	DEBUG("\n");
	// Now open file to write out
	ofstream outFile( name.c_str() );

	// First output some header info
	outFile << "graph [\n"; 
	outFile << "comment ";
	OutputQuotedString(outFile, "Automatically generated by Graphing tool");
	outFile << "\ndirected  1\n";
	outFile << "id  1\n";
	outFile << "label ";
	OutputQuotedString ( outFile, "Phylogeny Tree....\n");

	// Now output all the vertices
//	int i;
	stack<TreeNode *> nodesStack;
    if( rootNode != NULL)
    {
        nodesStack.push( rootNode );
    }
//cout << "a.1.1\n";
	while(  nodesStack.empty() == false )
	{
        TreeNode *pn = nodesStack.top();
        nodesStack.pop();

		outFile << "node [\n";

		outFile << "id " <<  pn->id  << endl;
		outFile << "label ";
 		string nameToUse = " ";
        if( pn->GetLabel()  != "-" )
        {
          nameToUse = pn->GetLabel();
        }
#if 0
        else
        {
            // we take the nonde value here
            char buf[100];
            if( pn->nodeValues.size() > 0 )
            {
                sprintf(buf, "(%d)", pn->nodeValues[0] );        // CAUTION, here we assume each leaf has exactly 1 label
                nameToUse = buf;
            }
            else
            {
                // if no nodes value is set, still use label
         //       nameToUse = pn->GetLabel();

                // YW: TBD change
                nameToUse.empty();
            }
        }
#endif
        const char *name = nameToUse.c_str();

// 		char name[100];
//       if( pn->IsLeaf() == false)
//        {
//		    name[0] = 'v'; 
//		    sprintf(&name[1], "%d", pn->id);
//        }
//        else
//        {
            // For leaf, we simply output their value (row number)
//            sprintf(name, "%d", pn->nodeValues[0] );        // CAUTION, here we assume each leaf has exactly 1 label
//        }
        OutputQuotedString (outFile,  name  ); 
		outFile << endl;

        // See if we need special shape here
        if( pn->GetShape() == PHY_TN_RECTANGLE)
        {
            outFile << "vgj [ \n shape  ";
            OutputQuotedString( outFile, "Rectangle");
    		outFile << "\n]\n";
        }
        else
        {
		    outFile << "defaultAtrribute   1\n";
        }
        
		outFile << "]\n";

        // Now try to get more nodes
        for(int i=0; i<(int)pn->listChildren.size(); ++i)
        {
            nodesStack.push( pn->listChildren[i] );
        }
//cout << "a.1.2\n";
	}
//cout << "a.1.3\n";

	// Now output all the edges, by again starting from root and output all nodes
    YW_ASSERT( nodesStack.empty() == true );
    if( rootNode != NULL)
    {
        nodesStack.push( rootNode );
    }
	while(  nodesStack.empty() == false )
	{
        TreeNode *pn = nodesStack.top();
        nodesStack.pop();
        
        for(int i=0; i<(int)pn->listChildren.size(); ++i)
        {
        
//cout << "Output an edge \n"; 
			outFile << "edge [\n";
			outFile << "source " << pn->id << endl; 
			outFile << "target  " << pn->listChildren[i]->id << endl; 
			outFile << "label " ;
            if( pn->listEdgeLabels[i].size() >0 )
            {
                string lblName;
		        char name[100];
//		        name[0] = 'e'; 
                for(int iel =0; iel<(int)pn->listEdgeLabels[i].size(); ++iel )
                {
		            sprintf(name, "e%d  ", pn->listEdgeLabels[i][iel]  );
                    lblName += name;
                }
			    OutputQuotedString( outFile,  lblName.c_str()  );
            }
            else
            {
			    OutputQuotedString( outFile,  ""  );
            }
			outFile << "\n";
			outFile << "]\n";
    
            // Store next one to stack
            nodesStack.push( pn->listChildren[i] );
		}
	}


	// Finally quite after closing file
	outFile << "\n]\n";
	outFile.close();
}

// construct a newick string for this tree
void PhylogenyTreeBasic :: ConsNewick( string &strNewick, bool wGridLen, double gridWidth  )
{
    strNewick.empty();

    // work from this node
	YW_ASSERT_INFO( rootNode != NULL, "Root is not set" );
    strNewick =  ConsNewickTreeNode( rootNode, wGridLen, gridWidth );
}

string PhylogenyTreeBasic :: ConsNewickTreeNode( TreeNode *pNode, bool wGridLen, double gridWidth  )
{	
//cout << "--------------------------------In ConsNewickTreeNode: I am here\n";
	string resNodeStr;
    // Is this node a leaf? If so, we output the label of it
    if( pNode->IsLeaf() == true )
    {
        // Add this label if this label is not there
        string tmpstr = pNode->GetUserLabel();
		resNodeStr = tmpstr;
    }
    else
    {
        string tmpstr = pNode->GetLabel();
        YW_ASSERT_INFO(pNode->listChildren.size() >=1, "Must have some children here.");

        // When there is only one child and no self-label
        if( tmpstr.size() <=2 &&  pNode->listChildren.size() == 1 )
        {
            resNodeStr =  ConsNewickTreeNode( pNode->listChildren[0], wGridLen, gridWidth  );
        }
		else
		{

			// Otherwise, we simply collect all sub strings here, and sepearate by a ,
			string comboStrName = "(";

			bool fAddSep = false;
			// does this node has a label by itself? if so, output it
			if( tmpstr.size() > 2 )
			{
				comboStrName += tmpstr.substr( 1, tmpstr.size()-2   );
				//comboStrName += ",";

				// all others should be added sep.
				fAddSep = true;
			}


			// handle its children
			for(unsigned int i=0; i<pNode->listChildren.size(); ++i)
			{
				string stepRes = ConsNewickTreeNode( pNode->listChildren[i], wGridLen, gridWidth  );

				if( stepRes.size() > 0 )
				{
					if( fAddSep == true )
					{
						comboStrName += ",";
					}

					comboStrName += stepRes;

					// from now on, add sep 
					fAddSep = true;

					//if( i+1 < pNode->listChildren.size() )
					//{
					//    comboStrName += ",";
					//}
				}
			}
			comboStrName += ")";
	//cout << "comboStrName = " << comboStrName << endl;
			resNodeStr = comboStrName;
		}
    }

	// now see if we need to add length info
	// 
	if(wGridLen == true)
	{
		// 
		TreeNode *pNodePar = pNode->GetParent();
		if( pNodePar != NULL)
		{
			double len = gridWidth*( pNodePar->GetLevel() -  pNode->GetLevel() );
//cout << "**************************PhylogenyTreeBasic::len = " << len << endl;
			char buf[100];
			sprintf(buf, ":%f", len);
			resNodeStr += buf;
		}
	}
    else if( pNode->GetLength() >= 0.0 )
    {
        // if length is set, add it
        resNodeStr += ":";
        resNodeStr += ConvToString(pNode->GetLength() );
    }

	return resNodeStr;



#if 0
    // Is this node a leaf? If so, we output the label of it
    if( pNode->IsLeaf() == true )
    {
        // Add this label if this label is not there
//        if( pNode->nodeValues.size() > 0 )
//        {
//            char buf[1024];
//            sprintf(buf, "%d", pNode->nodeValues[0] );        // CAUTION, here we assume each leaf has exactly 1 label
//            return buf;
        string tmpstr = pNode->GetLabel();


//        if( tmpstr.size() > 2 )
		// YW: change on 3/20/10 from > 2 to just return anything we have
		return tmpstr;
#if 0
        if( tmpstr.size() > 2 )
        {
            return tmpstr.substr( 1, tmpstr.size()-2   );
        }
        else
        {
            string emptyStr;
            return emptyStr;
        }
#endif
    }
    else
    {
        string tmpstr = pNode->GetLabel();
        YW_ASSERT_INFO(pNode->listChildren.size() >=1, "Must have some children here.");

        // When there is only one child and no self-label
        if( tmpstr.size() <=2 &&  pNode->listChildren.size() == 1 )
        {
            return ConsNewickTreeNode( pNode->listChildren[0]  );
        }


        // Otherwise, we simply collect all sub strings here, and sepearate by a ,
        string comboStrName = "(";

        bool fAddSep = false;
        // does this node has a label by itself? if so, output it
        if( tmpstr.size() > 2 )
        {
            comboStrName += tmpstr.substr( 1, tmpstr.size()-2   );
            //comboStrName += ",";

            // all others should be added sep.
            fAddSep = true;
        }


        // handle its children
        for(unsigned int i=0; i<pNode->listChildren.size(); ++i)
        {
            string stepRes = ConsNewickTreeNode( pNode->listChildren[i]  );

            if( stepRes.size() > 0 )
            {
                if( fAddSep == true )
                {
                    comboStrName += ",";
                }

                comboStrName += stepRes;

                // from now on, add sep 
                fAddSep = true;

                //if( i+1 < pNode->listChildren.size() )
                //{
                //    comboStrName += ",";
                //}
            }
        }
        comboStrName += ")";
//cout << "comboStrName = " << comboStrName << endl;
        return comboStrName;
    }
#endif

}



// This function adds a new tree node, and return it. Also set the parent node to the pareamter
TreeNode *PhylogenyTreeBasic :: AddTreeNode( TreeNode *parNode, int id )
{
    if( id < 0)
    {
        id = GetNumVertices();
    }

    TreeNode *pnode = new TreeNode(id);
    pnode->AddNodeValue( id );

    // Should delete the tree
    if(  parNode == NULL)
    {
        YW_ASSERT_INFO(rootNode == NULL, "Can not add a node with no parent if the tree is not empty");
        rootNode = pnode;
        return pnode;
    }

    // Otherwise, set the parent
    SEQUENCE emptySeq;
    parNode->AddChild( pnode,  emptySeq);
    return pnode;
}

int PhylogenyTreeBasic :: GetNumVertices() const
{
    int res = 0;
    stack<TreeNode *> stackNodes;
    if( rootNode != NULL )
    {
        stackNodes.push( rootNode );
    }
    while( stackNodes.empty() == false )
    {
        TreeNode *pcurr = stackNodes.top();
        stackNodes.pop();
        ++res;
        // Now enque its children
        for(int i=0; i<(int)pcurr->listChildren.size(); ++i)
        {
            stackNodes.push( pcurr->listChildren[i]  );
        }
    }
    return res;
}



//int PhylogenyTreeBasic :: GetIdFromStr( const string &strPart, TaxaMapper *pTMapper )
//{
//cout << "GetIdFromStr: " << strPart << endl; 
//	string strToUse = strPart;
//	size_t posSeparator = strPart.find( ':' );
//	if( posSeparator != string::npos )
//	{
//		strToUse = strPart.substr(0, (int)posSeparator  );
//	}
//	// get rid of 
//	int res = -1;
//	if( pTMapper == NULL)
//	{
//		sscanf( strToUse.c_str(), "%d", &res  );
//cout << "Empty mapper\n";
//	}
//	else
//	{
//		// are we reading in the first tree or not
//		if( pTMapper->IsInitialized() == true )
//		{
//			res  = pTMapper->GetId(strToUse);
//cout << "GetIdFromStr: GetId: " << strToUse << ": " << res << endl;
//		}
//		else
//		{
//			// this is new
//			res = pTMapper->AddTaxaString( strToUse );
//cout << "GetIdFromStr: New id: " << strToUse << ": " << res << endl;
//		}
//	}
//	return res;
//}


TreeNode * PhylogenyTreeBasic :: ConsOnNewickSubtree( const string & nwStringPart, int &leafId, int &invId, int numLeaves, bool fBottomUp, TaxaMapper *pTMapper )
{
//cout << "Entry nwStringPart = "<< nwStringPart << endl;
    
    TreeNode *pres = NULL;
    int posLenBegin = -1;
    

    // this function builds recursively subtrees for this part of string
    // First, is this string a leaf or not
    if( nwStringPart[0] != '('  )
    {
        //TreeNode *pLeaf = new TreeNode( nodeId  );
        //// also set its label this way
        //pLeaf->AddNodeValue( nodeId );


		// 7/27/10 YW: for now, we take this convention: 
		// tree node id = label  if no mapper is passed
		// Why? This case is by default for internal use only
		// while mapper is used for external (user) specified
        // Yes, this is a leaf
        int nodeId = TaxaMapper :: GetIdFromStr(nwStringPart, pTMapper);
		//	sscanf( nwStringPart.c_str(), "%d", &nodeId  );
       
		if( numLeaves > 0)
		{
			if( nodeId >= numLeaves )
			{
				cout << "Wrong: nodeId = " << nodeId << ", numLeaves = " << numLeaves << endl;
			}
			YW_ASSERT_INFO( nodeId < numLeaves, "We assume in phylogeny tree, leaf id starts from 0" );
		}
//cout << "node id = " << nodeId << endl;

		int idtouse = leafId;
		if( pTMapper == NULL )
		{
			// in this case take the same as node id
			idtouse = nodeId;
		}
		else
		{
			// update leafid since we are using it
			leafId ++;
		}

        TreeNode *pLeaf = new TreeNode( idtouse  );
        // also set its label this way
        pLeaf->AddNodeValue( idtouse );
		//leafId ++;


		// get rid of any part after : if there is length info
		//string strLeafLabel = nwStringPart;
		//if( strLa )
		//{
		//}
		string strLbl = GetStringFromId(nodeId);
        pLeaf->SetLabel( strLbl );
        
        string strLblUser = TaxaMapper :: ExtractIdPartFromStr( nwStringPart );
        pLeaf->SetUserLabel( strLblUser );
        
//cout << "ConsOnNewickSubtree: set leaf label: " << strLbl << endl;
        //return pLeaf;
        pres = pLeaf;
        
        size_t posLenSep = nwStringPart.find(':');
        if( posLenSep != string::npos )
        {
            //
            posLenBegin = posLenSep+1;
        }
    }
    else
    {
        // This is not a leaf
        // so we create underlying level for it
		int idToUse = 1000;
		if( fBottomUp == false )
		{
			idToUse = invId ++;
		}
        TreeNode *pInternal = new TreeNode( idToUse );
        int lastpos = 1;
        int curpos = 0;
        int parnet = 0; // (: +1, ) -1
        while( true )
        {
//cout << "curpos = " << curpos << endl;

            if( curpos >= (int) nwStringPart.size() )
            {
                // we are done
                break;
            }


            // keep balance
            if( nwStringPart[curpos] == '(' ) 
            {
                parnet ++;
            }
            else if( nwStringPart[curpos] == ')'  )
            {
                parnet --;

                // when parnet = 0, we know we end
                if( parnet == 0 )
                {
                    // now adding the last piece
                    // create a new node
                    int strl = curpos-lastpos;
                    string subs = nwStringPart.substr( lastpos, strl );
//    cout << "last subs = " << subs << endl; 
                    TreeNode *pChild = ConsOnNewickSubtree( subs, leafId, invId, numLeaves, fBottomUp, pTMapper );

                    // also append it as child
                    vector<int> empytLabels;
                    pInternal->AddChild( pChild, empytLabels );

                    // aslo update lastpos
                    lastpos = curpos+1;
                }

            }
            else if( nwStringPart[curpos] == ','  )
            {
                // Yes, this is a sepeartor, but we only start to process it when the
                // balance of parenetnis is right
                if( parnet == 1 )
                {
                    // create a new node
                    int strl = curpos-lastpos;
                    string subs = nwStringPart.substr( lastpos, strl );
//    cout << "subs = " << subs << endl; 
                    TreeNode *pChild = ConsOnNewickSubtree( subs, leafId, invId, numLeaves, fBottomUp, pTMapper );

                    // also append it as child
                    vector<int> empytLabels;
                    pInternal->AddChild( pChild, empytLabels );

                    // aslo update lastpos
                    lastpos = curpos+1;
                }
           }
            else if( nwStringPart[curpos] == ':' )
            {
                // keep track of length
                if( parnet == 0 )
                {
                    posLenBegin = curpos+1;
                }
            }


            // now move to next pos
            curpos ++;
        }

		// if we go bottom up labeling the node, we should re-label the node here
		if( fBottomUp == true )
		{
			pInternal->SetID( invId++ );
		}
        //return pInternal;
        pres = pInternal;
    }
    
    //
    if( posLenBegin >= 0 )
    {
        // also read in length
        size_t posRightExt = nwStringPart.find( ')', posLenBegin );
        int rightPos = (int)nwStringPart.size()-1;
        if( posRightExt != string::npos)
        {
            rightPos = posRightExt-1;
        }
        string subs = nwStringPart.substr( posLenBegin, posRightExt-posLenBegin+1 );
        double len = StrToDouble( subs );
        pres->SetLength(len);
    }
    return pres;
}

TreeNode * PhylogenyTreeBasic :: ConsOnNewickSubtreeDupLabels( const string & nwStringPart, int &invId, int &leafId, TaxaMapper *pTMapper )
{
//cout << "Entry nwStringPart = "<< nwStringPart << endl;

    // this function builds recursively subtrees for this part of string
    // First, is this string a leaf or not
    if( nwStringPart[0] != '('  )
    {
		// ensure no internal has every been set yet
		//YW_ASSERT_INFO( invId < 0, "invId should not be set when leaf is being processed" );

        // Yes, this is a leaf
        int nodeId = leafId;
		leafId ++;
		int leafLabel = TaxaMapper :: GetIdFromStr(nwStringPart, pTMapper);
        //sscanf( nwStringPart.c_str(), "%d", &leafLabel  );

//cout << "leaf id = " << nodeId << endl;
        TreeNode *pLeaf = new TreeNode( nodeId  );
        // also set its label this way
        pLeaf->AddNodeValue( nodeId );

		// get rid of any part after : if there is length info
		//string strLeafLabel = nwStringPart;
		//if( strLa )
		//{
		//}
		char buf[1000];
		sprintf(buf, "%d", leafLabel);
		string strLabel = buf;
        pLeaf->SetLabel( strLabel  );
        
        string strLabelUser = TaxaMapper :: ExtractIdPartFromStr( nwStringPart );
        pLeaf->SetUserLabel( strLabelUser );
        
//cout << "ConsOnNewickSubtree: set leaf label: " << strLabel << endl;
        return pLeaf;
    }
    else
    {

        // This is not a leaf
        // so we create underlying level for it
		int idToUse = invId;
        TreeNode *pInternal = new TreeNode( idToUse );
        int lastpos = 1;
        int curpos = 0;
        int parnet = 0; // (: +1, ) -1
        while( true )
        {
//cout << "curpos = " << curpos << endl;

            if( curpos >= (int) nwStringPart.size() )
            {
                // we are done
                break;
            }


            // keep balance
            if( nwStringPart[curpos] == '(' ) 
            {
                parnet ++;
            }
            else if( nwStringPart[curpos] == ')'  )
            {
                parnet --;

                // when parnet = 0, we know we end
                if( parnet == 0 )
                {
                    // now adding the last piece
                    // create a new node
                    int strl = curpos-lastpos;
                    string subs = nwStringPart.substr( lastpos, strl );
//    cout << "last subs = " << subs << endl; 
                    TreeNode *pChild = ConsOnNewickSubtreeDupLabels( subs, invId, leafId, pTMapper );

                    // also append it as child
                    vector<int> empytLabels;
                    pInternal->AddChild( pChild, empytLabels );

                    // aslo update lastpos
                    lastpos = curpos+1;
                }

            }
            else if( nwStringPart[curpos] == ','  )
            {
                // Yes, this is a sepeartor, but we only start to process it when the
                // balance of parenetnis is right
                if( parnet == 1 )
                {
                    // create a new node
                    int strl = curpos-lastpos;
                    string subs = nwStringPart.substr( lastpos, strl );
//    cout << "subs = " << subs << endl; 
                    TreeNode *pChild = ConsOnNewickSubtreeDupLabels( subs, invId, leafId, pTMapper );

                    // also append it as child
                    vector<int> empytLabels;
                    pInternal->AddChild( pChild, empytLabels );

                    // aslo update lastpos
                    lastpos = curpos+1;
                }
           }


            // now move to next pos
            curpos ++;
        }

		// if we go bottom up labeling the node, we should re-label the node here
		//if(invId < 0 )
		//{
		//	invId = leafId;
		//}

		pInternal->SetID( invId++ );
//cout << "Set internal node to " << pInternal->GetID() << endl;
        return pInternal;
    }
}




// Get nodes info
// 7/27/10: we want to get node label (NOT id!)
void PhylogenyTreeBasic :: GetNodeParInfo( vector<int> &nodeIds, vector<int> &parPos )
{
//cout << "GetNodeParInfo: \n";
	// simply put consecutive node ids but keep track of node parent positions
	// ensure we get the correct node mapping between id and pointer to node
	map<TreeNode *,int> mapNodeIds;

	// id is simply consecutive
	int numTotVerts = GetNumVertices();
	nodeIds.resize(numTotVerts);
	for(int i=0; i<numTotVerts; ++i)
	{
		nodeIds[i] = i;
	}
	parPos.resize(numTotVerts);
	for(int i=0; i<numTotVerts; ++i)
	{
		parPos[i] = -1;
	}

	// IMPORTANT: assume binary tree, otherwise all bets are off!!!!
	//int numLeaves = ( numTotVerts+1 )/2;
	int numLeaves = GetNumLeaves();
//cout << "numLeaves: " << numLeaves << endl;
	// do traversal
	int curNodeNum = 0;
	//InitPostorderWalk();
	PhylogenyTreeIterator itorTree(*this);
	itorTree.Init();
	while(itorTree.IsDone() == false)
	{
		TreeNode *pn = itorTree.GetCurrNode();
		itorTree.Next();
        //TreeNode *pn = NextPostorderWalk( ) ;
        if( pn == NULL)
        {
//cout << "No node here. Stop.\n";
            break;      // done with all nodes
        }

		// 
		if( pn->IsLeaf() == true  )
		{
			// skip it for now
			continue;
		}

		// 
		int nonleafInd = numLeaves + curNodeNum;
		curNodeNum++;
		// remember it
		mapNodeIds.insert( map<TreeNode *,int> :: value_type( pn, nonleafInd ) );
		// now set its descendents to this index, either leaf or non-leaf
		// if it is non-leaf, do a lookup of the stored id. Leaf: just go by its id
		for(int jj=0; jj<pn->GetChildrenNum(); ++jj)
		{
			TreeNode *pnjj = pn->GetChild(jj);
			int pnjjid;
			int pnjjlabel = -1;
			if( pnjj->IsLeaf() == true )
			{
				pnjjid = pnjj->GetID();
				// assume id is distinct, while label can be duplicate
				pnjjlabel = pnjj->GetIntLabel();
				YW_ASSERT_INFO( pnjjid >=0 && pnjjid < numLeaves, "Leaf id: out of range" );
			}
			else
			{
				YW_ASSERT_INFO( mapNodeIds.find( pnjj ) != mapNodeIds.end(), "Fail to find the node"  );
				pnjjid = mapNodeIds[pnjj];
			}
			parPos[pnjjid] = nonleafInd;
			// this says whether we change the label of the node
			// this is needed when there are duplicate labels in the tree
			if( pnjjlabel >= 0)
			{
				nodeIds[pnjjid] = pnjjlabel;
			}
		}
	}

// print out
//cout << "original tree:  ";
//string strTree;
//ConsNewick(strTree);
//cout << strTree << endl;
//cout << "Parent position : ";
//DumpIntVec( parPos );
}

void PhylogenyTreeBasic :: GetNodeParInfoNew( vector<int> &nodeIds, vector<int> &parPos )
{
	// the previous version has various of problems, but it is being used by some programs
	// so I decide to add a new function
	// Note this one assume all nodes are labeled consecutively
	// simply put consecutive node ids but keep track of node parent positions
	// ensure we get the correct node mapping between id and pointer to node
	//map<TreeNode *,int> mapNodeIds;

	// id is simply consecutive
	int numTotVerts = GetNumVertices();
	//nodeIds.resize(numTotVerts);
	//for(int i=0; i<numTotVerts; ++i)
	//{
	//	nodeIds[i] = i;
	//}
	//parPos.resize(numTotVerts);
	//for(int i=0; i<numTotVerts; ++i)
	//{
	//	parPos[i] = -1;
	//}

	// IMPORTANT: assume binary tree, otherwise all bets are off!!!!
	//int numLeaves = ( numTotVerts+1 )/2;
	int numLeaves = GetNumLeaves();
//cout << "Numleaves = " << numLeaves << endl;
	// do traversal
	//int curNodeNum = 0;
	//InitPostorderWalk();
	PhylogenyTreeIterator itorTree(*this);
	itorTree.Init();
	while(itorTree.IsDone() == false )
	{
		TreeNode *pn = itorTree.GetCurrNode();
		itorTree.Next();
        //TreeNode *pn = NextPostorderWalk( ) ;
        if( pn == NULL)
        {
//cout << "No node here. Stop.\n";
            break;      // done with all nodes
        }

		// 
		int curNodeId = pn->GetID();
//cout << "curNodeId: " << curNodeId << endl;
		YW_ASSERT_INFO(curNodeId < numTotVerts, "curNodeId exceeds limit (the node ids must be consecutive from 0)");
		if( pn->IsLeaf() == true  )
		{
			// skip it for now
			YW_ASSERT_INFO( curNodeId < numLeaves, "The tree violates assumption that tree leaf id start from 0" );
		}

		// add a record
		nodeIds.push_back( pn->GetID() );
		TreeNode *pnPar = pn->GetParent();
		if( pnPar == NULL)
		{
			parPos.push_back( -1 );
		}
		else
		{
			// simply its id
			parPos.push_back( pnPar->GetID() );
		}

		//	continue;
		//}
#if 0
		// 
		//int nonleafInd = numLeaves + curNodeNum;
		int nonleafInd = curNodeId;
		//curNodeNum++;
		// remember it
		mapNodeIds.insert( map<TreeNode *,int> :: value_type( pn, curNodeId ) );
		// now set its descendents to this index, either leaf or non-leaf
		// if it is non-leaf, do a lookup of the stored id. Leaf: just go by its id
		for(int jj=0; jj<pn->GetChildrenNum(); ++jj)
		{
			TreeNode *pnjj = pn->GetChild(jj);
			int pnjjid;
			if( pnjj->IsLeaf() == true )
			{
				pnjjid = pnjj->GetID();
				YW_ASSERT_INFO( pnjjid >=0 && pnjjid < numLeaves, "Leaf id: out of range" );
			}
			else
			{
				YW_ASSERT_INFO( mapNodeIds.find( pnjj ) != mapNodeIds.end(), "Fail to find the node"  );
				pnjjid = mapNodeIds[pnjj];
			}
			parPos[pnjjid] = nonleafInd;
#endif
		//}
	}

// print out
//cout << "original tree:  ";
//string strTree;
//ConsNewick(strTree);
//cout << strTree << endl;
//cout << "Parent position : ";
//DumpIntVec( parPos );
}

//
bool PhylogenyTreeBasic :: ConsOnParPosList( const vector<int> &parPos, int numLeaves, bool fBottupUpLabel  )
{
	// 
	string strNewick;
	if( ConvParPosToNewick(parPos, strNewick) == false  )
	{
		return false;
	}
//cout << "Newick string = " << strNewick << endl;
	ConsOnNewick(strNewick, numLeaves, fBottupUpLabel);
	return true;
}

bool PhylogenyTreeBasic :: ConvParPosToNewick( const vector<int> &parPos, string &strNewick )
{
	// convert par position representation to newick
	// we always assume the last item is -1
	YW_ASSERT_INFO( parPos[parPos.size()-1] == -1, "Must be -1 for the last value in parPos" );
	ConvParPosToNewickSubtree( parPos.size()-1, parPos, strNewick );
	return true;
}

void PhylogenyTreeBasic :: ConvParPosToNewickSubtree( int nodeInd, const vector<int> &parPos, string &strNewick )
{
	// this function generate under a single node (leaf or non-leaf), the newick under the subtree
	vector<int> listUnderNodeInds;
	for(int i=0; i<(int)parPos.size(); ++i)
	{
		if( parPos[i] == nodeInd )
		{
			listUnderNodeInds.push_back( i );
		}
	}
	// leaf if empty
	if( listUnderNodeInds.size() == 0 )
	{
		char buf[100];
		sprintf( buf, "%d", nodeInd );
		strNewick = buf;
		return;
	}
	YW_ASSERT_INFO(listUnderNodeInds.size() == 2, "Only binary trees are supported for now");

	// now get newick for the two part and merge it
	string strFirst, strSecond;
	ConvParPosToNewickSubtree( listUnderNodeInds[0], parPos, strFirst );
	ConvParPosToNewickSubtree( listUnderNodeInds[1], parPos, strSecond );
	strNewick = "(";
	strNewick += strFirst;
	strNewick += ",";
	strNewick += strSecond;
	strNewick += ")";
}


void PhylogenyTreeBasic ::  GetLeaveIds( set<int> &lvids )
{
	lvids.clear();

	PhylogenyTreeIterator itorTree(*this);
	itorTree.Init();
	while(itorTree.IsDone() == false )
	{
		TreeNode *pn = itorTree.GetCurrNode();
		itorTree.Next();
		if( pn == NULL)
		{
			break;      // done with all nodes
		}
		if( pn->IsLeaf() == true )
		{
			lvids.insert(  pn->GetID()  );
		}
	}
}

void PhylogenyTreeBasic:: GetLeavesIdsWithLabel(  const string &label, set<int> &lvids   )
{
	lvids.clear();
	PhylogenyTreeIterator itorTree(*this);
	itorTree.Init();
	while(itorTree.IsDone() == false )
	{
		TreeNode *pn = itorTree.GetCurrNode();
//cout << "GetLeavesIdsWithLabel: ";
//cout << pn->GetLabel() << endl;
		itorTree.Next();
		if( pn == NULL)
		{
			break;      // done with all nodes
		}
		if( pn->GetLabel() == label )
		{
			lvids.insert(  pn->GetID()  );
		}
	}
}
    
void  PhylogenyTreeBasic :: GetLeavesWithLabels( const set<string> &setLabels, set<TreeNode *> &setLvNodes )
{
    //
    setLvNodes.clear();
    PhylogenyTreeIterator itorTree(*this);
    itorTree.Init();
    while(itorTree.IsDone() == false )
    {
        TreeNode *pn = itorTree.GetCurrNode();
        //cout << "GetLeavesIdsWithLabel: ";
        //cout << pn->GetLabel() << endl;
        itorTree.Next();
        if( pn == NULL)
        {
            break;      // done with all nodes
        }
        if(  setLabels.find( pn->GetLabel() ) != setLabels.end() )
        {
            setLvNodes.insert(  pn  );
        }
    }
}

void PhylogenyTreeBasic :: UpdateIntLabel( const vector<int> &listLabels)
{
	// by assumption, id is from 0 to the following
	PhylogenyTreeIterator itorTree(*this);
	itorTree.Init();
	while(itorTree.IsDone() == false )
	{
		TreeNode *pn = itorTree.GetCurrNode();
		itorTree.Next();
		if( pn == NULL)
		{
			break;      // done with all nodes
		}
//cout << "node id = " << pn->GetID() << endl;

		YW_ASSERT_INFO( pn->GetID() < (int) listLabels.size(), "Tree id: over limit" );
		int lblInt = listLabels[pn->GetID()];
		char strbuf[100];
		sprintf(strbuf, "%d", lblInt);
		string lblNew = strbuf;
		pn->SetLabel(lblNew);
	}
}

void PhylogenyTreeBasic :: Reroot(TreeNode *pRootDesc)
{
	YW_ASSERT_INFO(pRootDesc != NULL, "Can not take NULL pointer");
	// if the node is set ot be root, nothing to be done
	if( pRootDesc == rootNode )
	{
		return;
	}
//cout << "pass1\n";
	// create a new node
	//vector<int> dummyLbls;
	TreeNode *pRootNew = new TreeNode(rootNode->GetID() );
	TreeNode *pRootOtherDesc = pRootDesc->GetParent();
	YW_ASSERT_INFO(pRootOtherDesc != NULL, "TBD");
	vector<int> lblsNew;	
	// for now, concerntrate the labels without SPLITTING
	pRootOtherDesc->GetEdgeLabelsToChild(pRootDesc, lblsNew);
	pRootOtherDesc->RemoveChild(pRootDesc);
	pRootNew->AddChild( pRootDesc, lblsNew );
//cout << "pass2\n";
	// 
	TreeNode *pCurNode = pRootOtherDesc;
	TreeNode *pCurNodePar = pRootNew;
	while(true)
	{
		// setup the ancestral relationship
		YW_ASSERT_INFO( pCurNode != NULL && pCurNodePar != NULL, "Something wrong" );
//cout << "BEFORE CHANGING...\n";
//cout << "pCurNode: label =" << pCurNode->GetLabel() << ", ID = " << pCurNode->GetID() << ", num of children " << pCurNode->GetChildrenNum() << endl;
//for( int pp=0; pp< pCurNode->GetChildrenNum(); ++pp )
//{
//cout << "** Child: " << pCurNode->GetChild(pp)->GetID() << endl;
//}
//cout << "pCurNodePar: label =" << pCurNodePar->GetLabel() << ", ID = " << pCurNodePar->GetID()  << ", num of children " << pCurNodePar->GetChildrenNum()  << endl;
//for( int pp=0; pp< pCurNodePar->GetChildrenNum(); ++pp )
//{
//cout << "** Child: " << pCurNodePar->GetChild(pp)->GetID() << endl;
//}
		vector<int> lblsNew;	
		pCurNode->GetEdgeLabelsToChild(pCurNodePar, lblsNew);
		TreeNode *pNodeNext = pCurNode->GetParent();
		pCurNode->RemoveChild( pCurNodePar );
		//pCurNode->SetParent(pCurNodePar);
		pCurNodePar->AddChild(pCurNode, lblsNew);


#if 0
		vector<TreeNode *> listParChildren;
		for(int c=0; c<(int)pCurNode->GetChildrenNum(); ++c  )
		{
			//if( pCurNode->GetChild(c) != pCurNode )
			//{
			listParChildren.push_back( pCurNode->GetChild(c) ) ;
			//}
		}
		for(int c=0; c<(int)listParChildren.size(); ++c  )
		{
			//if( pCurNode->GetChild(c) != pCurNode )
			//{
			pCurNode->RemoveChild( listParChildren[c] ) ;
			//}
		}
		// add these to the descendent of the new par
		for( int c=0; c<(int)listParChildren.size(); ++c )
		{
			vector<int> emptyLbls;
			pCurNodePar->AddChild(listParChildren[c], emptyLbls);
		}
#endif

//cout << "AFTER CHANGING...\n";
//cout << "pCurNode: label =" << pCurNode->GetLabel() << ", ID = " << pCurNode->GetID() << ", num of children " << pCurNode->GetChildrenNum() << endl;
//for( int pp=0; pp< pCurNode->GetChildrenNum(); ++pp )
//{
//cout << "** Child: " << pCurNode->GetChild(pp)->GetID() << endl;
//}
//cout << "pCurNodePar: label =" << pCurNodePar->GetLabel() << ", ID = " << pCurNodePar->GetID()  << ", num of children " << pCurNodePar->GetChildrenNum()  << endl;
//for( int pp=0; pp< pCurNodePar->GetChildrenNum(); ++pp )
//{
//cout << "** Child: " << pCurNodePar->GetChild(pp)->GetID() << endl;
//}

		// find the other descendents of the par
		if(pNodeNext == NULL)
		{
			vector<TreeNode *> listParChildren;
			for(int c=0; c<(int)pCurNode->GetChildrenNum(); ++c  )
			{
				//if( pCurNode->GetChild(c) != pCurNode )
				//{
				listParChildren.push_back( pCurNode->GetChild(c) ) ;
				//}
			}
			for(int c=0; c<(int)listParChildren.size(); ++c  )
			{
				//if( pCurNode->GetChild(c) != pCurNode )
				//{
				pCurNode->RemoveChild( listParChildren[c] ) ;
				//}
			}
			// add these to the descendent of the new par
			for( int c=0; c<(int)listParChildren.size(); ++c )
			{
				vector<int> lblsNew;	
				pCurNode->GetEdgeLabelsToChild(listParChildren[c], lblsNew);

				//vector<int> emptyLbls;
				pCurNodePar->AddChild(listParChildren[c], lblsNew);
			}
			pCurNodePar->RemoveChild( pCurNode );

//cout << "FINALLY...\n";
//cout << "pCurNode: label =" << pCurNode->GetLabel() << ", ID = " << pCurNode->GetID() << ", num of children " << pCurNode->GetChildrenNum() << endl;
//for( int pp=0; pp< pCurNode->GetChildrenNum(); ++pp )
//{
//cout << "** Child: " << pCurNode->GetChild(pp)->GetID() << endl;
//}
//cout << "pCurNodePar: label =" << pCurNodePar->GetLabel() << ", ID = " << pCurNodePar->GetID()  << ", num of children " << pCurNodePar->GetChildrenNum()  << endl;
//for( int pp=0; pp< pCurNodePar->GetChildrenNum(); ++pp )
//{
//cout << "** Child: " << pCurNodePar->GetChild(pp)->GetID() << endl;
//}
			// done. pCurNode is the root, we should by-pass this node and assign
			// their children to pCurNodePar
			break;
		}
		// 
		pCurNodePar = pCurNode;
		pCurNode = pNodeNext;
	}


	// finally get rid of the original root
	delete rootNode;
	rootNode = pRootNew;
}

int PhylogenyTreeBasic :: GetNumLeaves()  
{
	if( numLeaves > 0 )
	{
		return numLeaves;
	}
	set<int> lvids; 
	GetLeaveIds(lvids); 
	numLeaves = lvids.size(); 
	return numLeaves;
}

void PhylogenyTreeBasic :: GetAllLeafNodes( vector< TreeNode *> &listLeafNodes) const
{
	listLeafNodes.clear();

    PhylogenyTreeBasic &refSelf = const_cast<PhylogenyTreeBasic &>(*this);
	PhylogenyTreeIterator itorTree(refSelf);
	itorTree.Init();
	while(itorTree.IsDone() == false )
	{
		TreeNode *pn = itorTree.GetCurrNode();
		itorTree.Next();
		if( pn == NULL)
		{
			break;      // done with all nodes
		}
		if( pn->IsLeaf() == true )
		{
			listLeafNodes.push_back( pn );
		}
	}
}

void PhylogenyTreeBasic :: GetAllNodes( vector< TreeNode *> &listLeafNodes) const
{
    listLeafNodes.clear();
    
    PhylogenyTreeBasic &refSelf = const_cast<PhylogenyTreeBasic &>(*this);
    PhylogenyTreeIterator itorTree(refSelf);
    itorTree.Init();
    while(itorTree.IsDone() == false )
    {
        TreeNode *pn = itorTree.GetCurrNode();
        itorTree.Next();
        if( pn == NULL)
        {
            break;      // done with all nodes
        }
        listLeafNodes.push_back( pn );
    }
}
    
// remove all leaf nodes without taxa ids
void PhylogenyTreeBasic :: CleanNonLabeledLeaves()
{
//cout << "CleanNonLabeledLeaves:\n";
	// mark all nodes that are on the path from a labeled leaf node to root
	set<TreeNode *> setNodesNonredundent;

	vector< TreeNode *> listLeafNodes;
	GetAllLeafNodes(listLeafNodes);
	for( int ii=0; ii<(int)listLeafNodes.size(); ++ii  )
	{
//cout << "Leaflabel: " << listLeafNodes[ii]->GetLabel() << endl;
		if( listLeafNodes[ii]->GetLabel().empty() == true || listLeafNodes[ii]->GetLabel() == "-" )
		{
			// 
//cout << "This leaf is REDUNDENT\n";
			continue;
		}

		TreeNode *pncurr = listLeafNodes[ii];
		while(pncurr != NULL && setNodesNonredundent.find( pncurr) == setNodesNonredundent.end() )
		{

			// 
			setNodesNonredundent.insert(pncurr);

			//
			pncurr = pncurr->GetParent();
		}
	}

	// now clean it by removing each node that does not appear in that
	PhylogenyTreeIterator itorTree(*this);
	itorTree.Init();
	vector<TreeNode *> listNodesToClean;
	while(itorTree.IsDone() == false )
	{
		TreeNode *pn = itorTree.GetCurrNode();
		itorTree.Next();
		if( pn == NULL)
		{
			break;      // done with all nodes
		}
//cout << "node id = " << pn->GetID() << endl;

		//
		if( setNodesNonredundent.find( pn) == setNodesNonredundent.end() )
		{
			// remove it
			listNodesToClean.push_back(pn);
		}
	}
	// now clean
	for(int ii=0; ii<(int)listNodesToClean.size(); ++ii)
	{
//cout << "Remove one node\n";
		RemoveNode( listNodesToClean[ii] );
	}

}

void PhylogenyTreeBasic :: RemoveNode( TreeNode *pn )
{
	// remove the node (but does not do anything to its descendent if it has; that is, we assume the node has no children)
	YW_ASSERT_INFO( pn->IsLeaf() == true, "Wrong: it still have children" );
	TreeNode *pnpar = pn->GetParent();
	if( pnpar != NULL )
	{
		pnpar->RemoveChild( pn );
	}
	delete pn;
}
    
void PhylogenyTreeBasic :: RemoveDescendentsFrom(set<TreeNode *> &setTreeNodes)
{
    // only keep those whose ancestor is ot in the set given
    set<TreeNode *> setTreeNodeNew;
    for( set<TreeNode *> :: iterator it = setTreeNodes.begin(); it != setTreeNodes.end(); ++it )
    {
        // check whether any of its parent is in the list
        bool fKeep = true;
        TreeNode *ppar = (*it)->GetParent();
        while( ppar != NULL )
        {
            if( setTreeNodes.find(ppar) != setTreeNodes.end() )
            {
                fKeep = false;
                break;
            }
            ppar = ppar->GetParent();
        }
        if( fKeep == true)
        {
            setTreeNodeNew.insert(*it);
        }
    }
    setTreeNodes = setTreeNodeNew;
}

// given a set of clusters (subsets of tree taxa), construct the corresponding phylo trees
// YW: need to allow mulfurcating trees
void PhylogenyTreeBasic :: ConsPhyTreeFromClusters( const set< set<int> > &setClusters )
{
//cout << "ConsPhyTreeFromClusters :: Cluseters: \n";
//for( set< set<int> > :: const_iterator it = setClusters.begin(); it != setClusters.end(); ++it )
//{
//DumpIntSet( *it );
//}
	// assume all leaves are given as singleton taxon. So first collect those singleton subsets
	set< set<int> > setSubsetsActive;
	TreeNode *nodeLast = NULL;
	map< set<int>, TreeNode *> mapClusterToNode;
	for( set< set<int> > :: const_iterator it = setClusters.begin(); it != setClusters.end(); ++it )
	{
		if( it->size() == 1)
		{
			// add in setClusters
			setSubsetsActive.insert( *it );
			// also create nodes
			TreeNode *pnode = new TreeNode( *(it->begin() ) );
			char buf[100];
			sprintf(buf, "%d", *(it->begin()) );
			string sbuf = buf;
			pnode->SetLabel( sbuf );
			nodeLast = pnode;
			mapClusterToNode.insert( map< set<int>, TreeNode *> :: value_type(*it, pnode) );
		}
	}
	// setup num of leaves now
	this->numLeaves = mapClusterToNode.size();

	// need to allow mulfurcating trees
	// approach: for each cluster, maintain a pointer that points to the cluster that is its parent
	// then, each time, loop through to find all parents
	map< set<int>, set<int> > mapClustrToPar;
	// try to see whether we can create new nodes
	for( set< set<int> > :: iterator it1 = setClusters.begin(); it1 != setClusters.end(); ++it1 )
	{
		set< set<int> > :: iterator it2 = setClusters.begin();
		++it2;
		for(; it2 !=setClusters.end(); ++it2 )
		{
			//
			set<int> sLarger = *it1;
			set<int> sSmaller = *it2;
			if( sLarger.size() < sSmaller.size() )
			{
				sLarger = *it2;
				sSmaller = *it1;
			}
			// can these two coalesce into a single cluster known
			if(  sLarger.size() > sSmaller.size() && IsSetContainer(sLarger, sSmaller) == true)
			{
				if( mapClustrToPar.find( sSmaller ) == mapClustrToPar.end() || mapClustrToPar[sSmaller].size() > sLarger.size() )
				{
					mapClustrToPar.erase(sSmaller);
					mapClustrToPar.insert( map< set<int>, set<int> > :: value_type(sSmaller, sLarger) ) ;
				}
			}
		}
	}

	// loop until there is only a single subset
	while( setSubsetsActive.size() > 1 )
	{
		set< set<int> > setSubsetsActiveNext = setSubsetsActive;
//cout << "Current active sets: \n";
//for( set< set<int> > :: const_iterator it = setSubsetsActiveNext.begin(); it != setSubsetsActiveNext.end(); ++it )
//{
//DumpIntSet( *it );
//}
		// try to find several clusters that have the same parent cluster
		// try to see whether we can create new nodes
		map<set<int>, set< set<int> > > mapClusterCoal;
		for( set< set<int> > :: iterator it1 = setSubsetsActive.begin(); it1 != setSubsetsActive.end(); ++it1 )
		{
			// get parent
			YW_ASSERT_INFO( mapClustrToPar.find(*it1) != mapClustrToPar.end(), "Cluster: not found" );
			if( mapClusterCoal.find(mapClustrToPar[*it1] ) == mapClusterCoal.end() )
			{
				set< set<int> > sempty;
				mapClusterCoal.insert( map<set<int>, set< set<int> > > :: value_type(mapClustrToPar[*it1], sempty) );
			}
//cout << "Having child cluster: ";
//DumpIntSet( mapClustrToPar[*it1] );
//cout << ", for child ";
//DumpIntSet(*it1);
			mapClusterCoal[ mapClustrToPar[*it1] ].insert(*it1);
		}
	

		// now process each record
		for( map<set<int>, set< set<int> > > :: iterator it2 = mapClusterCoal.begin(); it2 != mapClusterCoal.end(); ++it2)
		{
			//YW_ASSERT_INFO( it2->second.size() > 1, "Must have at least two coalescing" );
//cout << "Set parent: ";
//DumpIntSet(it2->first);
			set<int> sunion;
			for( set< set<int> > :: iterator it3=it2->second.begin(); it3 != it2->second.end(); ++it3 )
			{
//cout << "Set child: ";
//DumpIntSet(*it3);
				// can these two coalesce into a single cluster known
				UnionSets(sunion, *it3);
			}
//cout << "sunion = ";
//DumpIntSet( sunion );
			// ensure these do coal into some meaningful cluster
			if( setClusters.find(sunion) == setClusters.end() )
			{
//cout << "This set not complete\n";
				// this cluster not done yet
				continue;
			}
			
			// create this new node
			TreeNode *pnode = new TreeNode;
			nodeLast = pnode;
			for( set< set<int> > :: iterator it3=it2->second.begin(); it3 != it2->second.end(); ++it3 )
			{
//cout << "Processing first subset: ";
//DumpIntSet( *it1 );
//cout << "Processing second subset: ";
//DumpIntSet( *it2 );
				// these two add up to an input cluster and so create a new node for it
				YW_ASSERT_INFO( mapClusterToNode.find(*it3) != mapClusterToNode.end(), "Fail1" );
				vector<int> emptyLabels;
				pnode->AddChild( mapClusterToNode[*it3], emptyLabels );
				setSubsetsActiveNext.erase( *it3 );
			}
			mapClusterToNode.insert( map< set<int>, TreeNode *> :: value_type(sunion, pnode) );
			setSubsetsActiveNext.insert( sunion );
//cout << "Creating node: " << endl;
		}
		// must make progress
		YW_ASSERT_INFO( setSubsetsActive != setSubsetsActiveNext, "Did not make progress" );
		setSubsetsActive = setSubsetsActiveNext;
	}
	YW_ASSERT_INFO( nodeLast != NULL, "nodeLast: NULL" );
	SetRoot( nodeLast );

#if 0
	// loop until there is only a single subset
	while( setSubsetsActive.size() > 1 )
	{
		set< set<int> > setSubsetsActiveNext = setSubsetsActive;
		// try to see whether we can create new nodes
		for( set< set<int> > :: iterator it1 = setSubsetsActive.begin(); it1 != setSubsetsActive.end(); ++it1 )
		{
			if( setSubsetsActiveNext.find(*it1) == setSubsetsActiveNext.end() ) 
			{
				// should move on if this subset has been used
				continue;
			}

			set< set<int> > :: iterator it2 = setSubsetsActive.begin();
			++it2;
			for(; it2 !=setSubsetsActive.end(); ++it2 )
			{
				if( setSubsetsActiveNext.find(*it2) == setSubsetsActiveNext.end() )
				{
					continue;
				}
				// can these two coalesce into a single cluster known
				set<int> sunion = *it1;
				UnionSets(sunion, *it2);
				if( sunion.size() != it1->size() + it2->size() )
				{
					// must be disjoint
					continue;
				}
				
				if( setClusters.find( sunion) != setClusters.end() )
				{
//cout << "Processing first subset: ";
//DumpIntSet( *it1 );
//cout << "Processing second subset: ";
//DumpIntSet( *it2 );
					// these two add up to an input cluster and so create a new node for it
					YW_ASSERT_INFO( mapClusterToNode.find(*it1) != mapClusterToNode.end(), "Fail1" );
					YW_ASSERT_INFO( mapClusterToNode.find(*it2) != mapClusterToNode.end(), "Fail2" );
					TreeNode *pnode = new TreeNode;
					nodeLast = pnode;
					vector<int> emptyLabels;
					pnode->AddChild( mapClusterToNode[*it1], emptyLabels );
					pnode->AddChild( mapClusterToNode[*it2], emptyLabels );
					mapClusterToNode.insert( map< set<int>, TreeNode *> :: value_type(sunion, pnode) );
					setSubsetsActiveNext.erase( *it1 );
					setSubsetsActiveNext.erase( *it2 );
					setSubsetsActiveNext.insert( sunion );
 
				}
			}
		}
		// must make progress
		YW_ASSERT_INFO( setSubsetsActive != setSubsetsActiveNext, "Did not make progress" );
		setSubsetsActive = setSubsetsActiveNext;
	}
	YW_ASSERT_INFO( nodeLast != NULL, "nodeLast: NULL" );
	SetRoot( nodeLast );
#endif
}

// find the set of clades in the subtree specified by the given leaf nodes
void PhylogenyTreeBasic :: FindCladeOfSubsetLeaves( const set<TreeNode *> &setLeaves, set< set<TreeNode *> > &setSubtreeClades  )
{
    // caution: do not check whether these are true leaves
    TreeNode *pRoot = this->GetRoot();
    set<TreeNode *> setAllNodes;
    pRoot->GetAllDescendents(setAllNodes);
    
    //
    for( set<TreeNode *> :: iterator it = setAllNodes.begin(); it != setAllNodes.end(); ++it )
    {
        //
        set<TreeNode *> setLeavesUnder;
        (*it)->GetAllLeavesUnder( setLeavesUnder );
        set<TreeNode *> setLeavesSS;
        JoinSetsGen( setLeavesUnder, setLeaves, setLeavesSS );
        if( setLeavesSS.size() > 0 )
        {
            setSubtreeClades.insert( setLeavesSS );
        }
    }
}

// find the set of clades in the subtree specified by the given leaf nodes
void PhylogenyTreeBasic :: FindCladeOfSubsetLeavesExact( const set<TreeNode *> &setLeaves, set< set<TreeNode *> > &setSubtreeClades  )
{
    // caution: do not check whether these are true leaves
    TreeNode *pRoot = this->GetRoot();
    set<TreeNode *> setAllNodes;
    pRoot->GetAllDescendents(setAllNodes);
        
    //
    for( set<TreeNode *> :: iterator it = setAllNodes.begin(); it != setAllNodes.end(); ++it )
    {
        //
        set<TreeNode *> setLeavesUnder;
        (*it)->GetAllLeavesUnder( setLeavesUnder );
        set<TreeNode *> setLeavesSS;
        JoinSetsGen( setLeavesUnder, setLeaves, setLeavesSS );
        if( setLeavesSS == setLeavesUnder )
        {
            setSubtreeClades.insert( setLeavesSS );
        }
    }
}
    
void PhylogenyTreeBasic :: GroupLeavesToSubtrees( const set<TreeNode *> &setLeaves,  const set<set<TreeNode *> > &cladeNodesToProc, set< set<TreeNode *> > &setSubtreeClades  )
{
    // group the leaves into subtrees (i.e. the subtrees contains exactly those appear in the leaves
    // YW: note this is not the most realistic way (say you have one noisy leaf sepearting two otherwise fully connected catepillar tree,
    // then the result willl be a lot more trees to use). But this servers as a starting point
    // YW: here, we are given some subset out of some pre-specified leaf set, and some subsets (clades) over these leaves; 
    // we want to find the set of maximal clades containing partition these leaves
    //TreeNode *pRoot = this->GetRoot();
    //set<TreeNode *> setAllNodes;
    //pRoot->GetAllDescendents(setAllNodes);
    
    // order based on the size
    map<int, set<set<TreeNode *> > > mapSubtreeSz;
    //for( set<TreeNode *> :: iterator it = setAllNodes.begin(); it != setAllNodes.end(); ++it)
    for( set<set<TreeNode *> > :: const_iterator it = cladeNodesToProc.begin(); it != cladeNodesToProc.end(); ++it )
    {
        // 
        //set<TreeNode *> setLeavesUnder;
        //(*it)->GetAllLeavesUnder( setLeavesUnder );
        if( mapSubtreeSz.find( it->size() ) == mapSubtreeSz.end() )
        {
            set<set<TreeNode *> > ss;
            mapSubtreeSz.insert( map<int, set<set<TreeNode *> > > :: value_type(it->size(), ss) );
        }
        mapSubtreeSz[it->size()].insert( *it );
    }
    
    // reverse order
    set<TreeNode *> setNodesProc = setLeaves;
    for( map<int, set<set<TreeNode *> > > :: reverse_iterator rit = mapSubtreeSz.rbegin(); rit != mapSubtreeSz.rend(); ++rit )
    {
        //
        for( set<set<TreeNode *> > :: iterator itg = rit->second.begin(); itg != rit->second.end(); ++itg )
        {
            //
            set<TreeNode *> setLeavesSS;
            JoinSetsGen( *itg, setNodesProc, setLeavesSS );
            if(  setLeavesSS.size() == itg->size() )
            {
                // find a good match here, use it
                setSubtreeClades.insert(*itg);
                SubtractSetsGen( setNodesProc, *itg );
            }
        }
        if( setNodesProc.size() == 0 )
        {
            break;
        }
    }
    YW_ASSERT_INFO( setNodesProc.size() == 0, "Fail to classify all subtrees" );
}
    
void PhylogenyTreeBasic :: GroupLeavesToSubtreesSamePar( const set<TreeNode *> &setLeaves,  const set<set<TreeNode *> > &cladeNodesToProc, set< set<TreeNode *> > &setSubtreeClades  )
{
    // group leaves that form subtrees w/ same parents. Difference from above: for two subtrees that share the same parent
    // but could be other branches, put the together
    GroupLeavesToSubtrees( setLeaves, cladeNodesToProc, setSubtreeClades );
    // now see whether we can combine subtrees s.t. the combined one is still contined in some parent
    map< set<TreeNode *>, set<TreeNode *> > mapSubtreesToPar;
    for( set< set<TreeNode *> > :: iterator it = setSubtreeClades.begin(); it != setSubtreeClades.end(); ++it )
    {
        for( set<set<TreeNode *> > :: iterator itg = cladeNodesToProc.begin(); itg != cladeNodesToProc.end(); ++itg)
        {
            //
            if( *itg != *it && itg->size() > it->size() && (  mapSubtreesToPar.find(*it) == mapSubtreesToPar.end() || mapSubtreesToPar[*it].size() > itg->size() ) )
            {
                //
                set<TreeNode *> sint;
                JoinSetsGen(*itg, *it, sint);
                if( sint.size() == it->size() )
                {
                    //
                    if( mapSubtreesToPar.find( *it) == mapSubtreesToPar.end() )
                    {
                        mapSubtreesToPar.insert( map< set<TreeNode *>, set<TreeNode *> > :: value_type(*it, *itg) );
                    }
                    else
                    {
                        mapSubtreesToPar[*it] = *itg;
                    }
                }
            }
        }
    }
    map< set<TreeNode *>, set<TreeNode *> > mapRevParToSubtrees;
    for( map< set<TreeNode *>, set<TreeNode *> > :: iterator it = mapSubtreesToPar.begin(); it != mapSubtreesToPar.end(); ++it )
    {
        //
        if( mapRevParToSubtrees.find(it->second) == mapRevParToSubtrees.end() )
        {
            mapRevParToSubtrees.insert( map< set<TreeNode *>, set<TreeNode *> > :: value_type(it->second, it->first) );
        }
        else
        {
            UnionSetsGen( mapRevParToSubtrees[it->second], it->first );
        }
    }
    setSubtreeClades.clear();
    for(map< set<TreeNode *>, set<TreeNode *> > :: iterator it = mapRevParToSubtrees.begin(); it != mapRevParToSubtrees.end(); ++it )
    {
        setSubtreeClades.insert( it->second );
    }
}

    
void PhylogenyTreeBasic :: GetAllClades(set<set<int> > &setClades)
{
    //
    setClades.clear();
    // now clean it by removing each node that does not appear in that
	PhylogenyTreeIterator itorTree(*this);
	itorTree.Init();
	while(itorTree.IsDone() == false )
	{
		TreeNode *pn = itorTree.GetCurrNode();
		itorTree.Next();
		if( pn == NULL)
		{
			break;      // done with all nodes
		}
        //cout << "node id = " << pn->GetID() << endl;
        set<TreeNode *> setDescendents;
        pn->GetAllLeavesUnder(setDescendents);
        set<int> sint;
        for(set<TreeNode *> :: iterator itg=setDescendents.begin(); itg != setDescendents.end(); ++itg)
        {
            sint.insert( (*itg)->GetIntLabel() );
        }
        setClades.insert( sint );
        
	}
}
    
void PhylogenyTreeBasic :: GetAllCladesById(set<set<int> > &setClades)
{
    //
    setClades.clear();
    // now clean it by removing each node that does not appear in that
    PhylogenyTreeIterator itorTree(*this);
    itorTree.Init();
    while(itorTree.IsDone() == false )
    {
        TreeNode *pn = itorTree.GetCurrNode();
        itorTree.Next();
        if( pn == NULL)
        {
            break;      // done with all nodes
        }
        //cout << "node id = " << pn->GetID() << endl;
        set<TreeNode *> setDescendents;
        pn->GetAllLeavesUnder(setDescendents);
        set<int> sint;
        for(set<TreeNode *> :: iterator itg=setDescendents.begin(); itg != setDescendents.end(); ++itg)
        {
            sint.insert( (*itg)->GetID() );
        }
        setClades.insert( sint );
        
    }
}

    
void PhylogenyTreeBasic :: GetAllCladeNodess(set<set<TreeNode *> > &setClades)
{
    //
    setClades.clear();
    // now clean it by removing each node that does not appear in that
    PhylogenyTreeIterator itorTree(*this);
    itorTree.Init();
    while(itorTree.IsDone() == false )
    {
        TreeNode *pn = itorTree.GetCurrNode();
        itorTree.Next();
        if( pn == NULL)
        {
            break;      // done with all nodes
        }
        //cout << "node id = " << pn->GetID() << endl;
        set<TreeNode *> setDescendents;
        pn->GetAllLeavesUnder(setDescendents);
        
        setClades.insert( setDescendents );
        
    }
}
    
TreeNode * PhylogenyTreeBasic :: GetSubtreeRootForLeaves( const set<TreeNode *> &setLvNodes )
{
    PhylogenyTreeIterator itorTree(*this);
    itorTree.Init();
    while(itorTree.IsDone() == false )
    {
        TreeNode *pn = itorTree.GetCurrNode();
        itorTree.Next();
        if( pn == NULL)
        {
            break;      // done with all nodes
        }
        //cout << "node id = " << pn->GetID() << endl;
        set<TreeNode *> setDescendents;
        pn->GetAllLeavesUnder(setDescendents);
        
        if( setLvNodes ==  setDescendents )
        {
            return pn;
        }
        
    }
    return NULL;
    
}


void PhylogenyTreeBasic :: GroupNodesWithCommonPars( const set<TreeNode *> &setNodes, map<TreeNode *, set<TreeNode *> >  &mapNodesWithSamePar )
{
    //
    mapNodesWithSamePar.clear();
    for( set<TreeNode *> :: const_iterator it = setNodes.begin(); it != setNodes.end(); ++it )
    {
        //
        TreeNode *ppar = (*it)->GetParent();
        if( mapNodesWithSamePar.find( ppar) == mapNodesWithSamePar.end() )
        {
            set<TreeNode *> ss;
            mapNodesWithSamePar.insert( map<TreeNode *, set<TreeNode *> > :: value_type(ppar, ss) );
        }
        mapNodesWithSamePar[ppar].insert( *it );
    }
}
    
void PhylogenyTreeBasic :: RemoveEdgeLabels()
{
    //
    this->rootNode->RemoveLabels();
}

void PhylogenyTreeBasic :: RemoveEdgeLabelsToLeaves()
{
    // get all leaves
    vector<TreeNode *> vecLeaves;
    GetAllLeafNodes( vecLeaves );
    for(int i=0; i<(int)vecLeaves.size(); ++i)
    {
        vecLeaves[i]->RemoveLabelsPar();
    }
}
    
string PhylogenyTreeBasic :: GetShapeLabelNodeBrNum( map<TreeNode *, pair<int,int> > &mapNodeNumBrannches, vector<int> &listOrderedLeaves)
{
    // format: <num of underlying branches, event id>, negative for internal nodes
    map<TreeNode *,pair<int,int> > mapNodeNumBrannchesUse = mapNodeNumBrannches;
    // given: num of branches at each node,
    // return shape label as empty Newick format
    // for this, first need to find out all nodes that all descendents have appeared in the tree
    set<TreeNode *> setAncesNotGiven;
    for( map<TreeNode *,pair<int,int> > :: iterator it = mapNodeNumBrannches.begin(); it != mapNodeNumBrannches.end(); ++it )
    {
        set<TreeNode *> setAllAnces;
        it->first->GetAllAncestors(setAllAnces);
        for( set<TreeNode *> :: iterator itg = setAllAnces.begin(); itg != setAllAnces.end(); ++itg)
        {
            if( mapNodeNumBrannches.find(*itg) == mapNodeNumBrannches.end() )
            {
                //
                pair<int,int> pp(-1,-1);
                mapNodeNumBrannchesUse.insert( map<TreeNode*,pair<int,int> > :: value_type(*itg,pp) );
            }
        }
    }
    // now call the root to find the label
    return this->rootNode->GetShapeLabelNodeBrNum(mapNodeNumBrannchesUse, listOrderedLeaves);
}
    
void PhylogenyTreeBasic :: MakeSubtreeUnrefined(TreeNode *pSubtree)
{
    // make this subtree unrefined (i.e. each leaf points to the root
    // CAUTION: all edge labels are LOST!!!!
    set<TreeNode *> setAllLeavesUnder;
    pSubtree->GetAllLeavesUnder( setAllLeavesUnder );
//cout << "setAllLeavesUnder: ";
//for( set<TreeNode *> :: iterator it = setAllLeavesUnder.begin(); it != setAllLeavesUnder.end(); ++it)
//{
//(*it)->Dump();
//}
//cout << endl;
    set<TreeNode *> setAllDescUnder;
    pSubtree->GetAllDescendents( setAllDescUnder );
//cout << "setAllDescUnder: ";
//for( set<TreeNode *> :: iterator it = setAllDescUnder.begin(); it != setAllDescUnder.end(); ++it)
//{
//(*it)->Dump();
//}
//cout << endl;
    
    // detach all leaves from their parent
    for( set<TreeNode *> :: iterator it = setAllLeavesUnder.begin(); it != setAllLeavesUnder.end(); ++it )
    {
        //
        TreeNode *ppar = (*it)->GetParent();
        ppar->RemoveChild(*it);
    }
    
    pSubtree->RemoveAllChildren();

    // remove all descendent except the leaves
    for( set<TreeNode *> :: iterator it = setAllDescUnder.begin(); it != setAllDescUnder.end(); ++it)
    {
        // need to be careful b/c node deletion is recurisvely
        if( setAllLeavesUnder.find(*it) == setAllLeavesUnder.end() && (*it) != pSubtree && ( (*it)->GetParent() == pSubtree ) )
        {
//cout << "Delete this node: ";
//(*it)->Dump();
            delete *it;
        }
    }
    // then add the leaves directly under the subtree root
    for( set<TreeNode *> :: iterator it = setAllLeavesUnder.begin(); it != setAllLeavesUnder.end(); ++it )
    {
        vector<int> lblEmpty;
        pSubtree->AddChild( *it, lblEmpty );
    }
//string strTree;
//ConsNewick(strTree);
//cout << "After MakeSubtreeUnrefiined: tree is " << strTree << endl;
}
    
void PhylogenyTreeBasic :: Binarize()
{
    // make the tree binary
    int idToUseNext = this->rootNode->GetMaxIdWithinSubtree() + 1;
    this->rootNode->Binarize( idToUseNext );
//string strTree;
//ConsNewick(strTree);
//cout << "After binarization: tree is " << strTree << endl;
}
    
void PhylogenyTreeBasic :: CreatePhyTreeFromLeavesWithLabels( const set<string> &setLeafLabels, PhylogenyTreeBasic &treeSubsetLeaves)
{
    // given a set of leaf labels, construct another phylogenetic tree that is extracted
    // from the current tree by only taking those leaves with one of the given labels
    // YW: caution: all taxa names are mapped to arbitary 0,1,2,...
    set<int> setSubsetLeaves;
    map<int, string> mapOrigIdToOrigStrLbl;
    int idToUseFirst=0;
    for( set<string> :: const_iterator it = setLeafLabels.begin(); it != setLeafLabels.end(); ++it)
    {
        string lblcur = *it;
        set<int> setSubsetLeavesStep;
        GetLeavesIdsWithLabel( lblcur, setSubsetLeavesStep );
//cout << "CreatePhyTreeFromLeavesWithLabels: lblcur: " << lblcur <<" setSubsetLeavesStep: ";
//DumpIntSet(setSubsetLeavesStep);
        UnionSets( setSubsetLeaves, setSubsetLeavesStep );
        
        
        char buf[100];
        sprintf(buf,"%d", idToUseFirst++);
        string lblToUse = buf;
        
        for( set<int> :: iterator it2 = setSubsetLeavesStep.begin(); it2 != setSubsetLeavesStep.end(); ++it2 )
        {
            //mapOrigIdToOrigStrLbl.insert( map<int,string> :: value_type(*it2, lblcur) );
            mapOrigIdToOrigStrLbl.insert( map<int,string> :: value_type(*it2, lblToUse) );
//cout << "mapOrigIdToOrigStrLbl: " << *it2 << ", lblToUse: " << lblToUse << endl;
        }
    }
    
    // get all clades first
    set<set<int> > setClades;
    GetAllCladesById( setClades );
//cout << "All clades: \n";
//for(set<set<int> > :: iterator it = setClades.begin(); it != setClades.end(); ++it)
//{
//DumpIntSet(*it);
//}
    
    // map the remaining id to 0,1,2....
    map<int,int> mapIdToContinue;
    map<int, string> mapContIdToOrigStr;
    int idToUse = 0;
    for(set<int> :: iterator it = setSubsetLeaves.begin(); it != setSubsetLeaves.end(); ++it)
    {
        YW_ASSERT_INFO(mapOrigIdToOrigStrLbl.find(*it) != mapOrigIdToOrigStrLbl.end(), "Fail" );
        mapContIdToOrigStr.insert( map<int,string> :: value_type(idToUse, mapOrigIdToOrigStrLbl[*it] ) );
//cout << "mapContIdToOrigStr: idtouse: " << idToUse << ", string orig: " << mapOrigIdToOrigStrLbl[*it] << endl;
        mapIdToContinue.insert( map<int,int> :: value_type( *it, idToUse++ ) );
    }
    
    
    set<set<int> > setCladesSub;
    // now extract those with only those given
    for( set<set<int> > :: iterator it = setClades.begin(); it != setClades.end(); ++it )
    {
        set<int> sintstep;
        JoinSets(*it, setSubsetLeaves, sintstep);
        if( sintstep.size() > 0 )
        {
            // convert to continuios id first
            set<int> sintstep2;
            MapIntSetTo(sintstep, mapIdToContinue, sintstep2);
            
            setCladesSub.insert( sintstep2 );
            
//cout << "Adding a clade: ";
//DumpIntSet( sintstep2);
//cout << "for orig clade: ";
//DumpIntSet(sintstep);
        }
    }
    
    // now build a tree with these labels
    CreatePhyTreeWithRootedSplits( treeSubsetLeaves, setSubsetLeaves.size(), setCladesSub);
    
    // now map the leaves of the new tree to the original ids
    treeSubsetLeaves.AssignLeafLabels( mapContIdToOrigStr );
    
//cout << "This is the phylogenetic tree constructed from subset of leaves: "
//this->OutputGML("tree1.gml");
//treeSubsetLeaves.OutputGML("t1.gml");
//exit(1);
}
    
void PhylogenyTreeBasic :: AssignLeafLabels( const map<int,string> &mapLeafLbls )
{
    // assign labels stored in the map (format: node id to lbl)
    vector< TreeNode *> listLeafNodes;
    GetAllLeafNodes( listLeafNodes);
    for(int i=0; i<(int)listLeafNodes.size(); ++i)
    {
        int idn = listLeafNodes[i]->GetID();
        map<int,string> :: const_iterator itg = mapLeafLbls.find(idn);
        YW_ASSERT_INFO(itg != mapLeafLbls.end(), "Fail");
        string strLblNew = itg->second;
        listLeafNodes[i]->SetLabel( strLblNew );
        listLeafNodes[i]->SetUserLabel(strLblNew);
    }
}
    
int PhylogenyTreeBasic :: GetMaxDegree() const
{
    int res = 0;
    
    PhylogenyTreeBasic &thisTree = const_cast<PhylogenyTreeBasic &>(*this);
    PhylogenyTreeIterator itor(thisTree);
    itor.Init();
    while(itor.IsDone() == false )
    {
        TreeNode *pn = itor.GetCurrNode();

        int degThis = pn->GetChildrenNum();
        if( degThis > res )
        {
            res = degThis;
        }
        
        itor.Next();
    }
    return res;
}
    
void PhylogenyTreeBasic :: Dump() const
{
    // dump all nodes
    PhylogenyTreeBasic &thisTree = const_cast<PhylogenyTreeBasic &>(*this);
    PhylogenyTreeIterator itor(thisTree);
    itor.Init();
    while(itor.IsDone() == false )
    {
        TreeNode *pn = itor.GetCurrNode();
        pn->Dump();
        cout << endl;
        itor.Next();
    }
}
    
