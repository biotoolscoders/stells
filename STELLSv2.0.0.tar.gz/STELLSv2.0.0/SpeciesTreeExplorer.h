#ifndef SPECIES_TREE_EXPLOER_H
#define SPECIES_TREE_EXPLOER_H

#include "GeneSpeciesTreeProb.h"

// Explore the space of species trees (topology only) 
// it takes some starting trees and then explore the neighbors
// in order to find the best species trees


//////////////////////////////////////////////////////////////////////////////////
// Finding candidate trees from a single tree through NNI

class NNINgbrTreesFinder
{
public:
	// take a single tree and explore its NNI trees
	NNINgbrTreesFinder(PhylogenyTreeBasic &speciesTreeCur);

	// find NNI neighbor trees (represented by Newick)
	void Find(set<string> &setNgbrNWTrees);

private:
	void GetTempChangedTreeAt( TreeNode *tnchange1, TreeNode *tnchange2, string & nwtreetmp );

	PhylogenyTreeBasic &speciesTreeCur;
};


//////////////////////////////////////////////////////////////////////////////////
// Interface ccode


class SpeciesTreeExplorer
{
public:
	SpeciesTreeExplorer( int numSpecies, vector<PhylogenyTreeBasic *> &listGeneTreePtrs, const vector<int> &listMP, TaxaMapper &mapperTaxaIds );
    ~SpeciesTreeExplorer();

	// explore from a set of 
	void ExploreFrom( const vector<string> &listNWTreesInit );
	void SetSearchNgbrTreesFlag(bool f) { fExploreNeighorTrees = f; }
	void SetBrentMode(bool f) { fBrentMode = f; }
	void SetNumNearOptTreesKept(int n) { numNearOptTreesKept = n; }
    void SetOutputTreeHere(bool f) { fOutputTreeHere = f; }
	void OutputNearOptTrees(string fileNameInit);
    void SetBranchLenRange(double minBL, double maxBL);
    void GetBestSTBranchLens(vector<double> &listBrLens) const { bestSpciesMargTree.GetTreeEdgeLen( listBrLens ); }
    string GetBestInfSpeicesTree() const;


private:
	void ExploreFromOneTree(const string &treeNWInit, bool fEvaluateInit, double initLogLikeli);
	double EvaluateOneTree(const string &treeNWInit);

	int GetNumSpecies() { return numSpecies; }
	double GetCurBestLoglikeli() { return curLoglikeli; }
	double GetDummyWorseLoglikeli() { return  -1.0*HAP_MAX_INT; }
    void PreCreateListGTPComp( MarginalTree &treeSpec, vector<PhylogenyTreeBasic *> &listGeneTreePtrs, vector<GenericGeneSpeciesTreeProb *> &listGSTProbFinder );
    void PreCreateListGTPCompMultithread( MarginalTree &treeSpec, vector<PhylogenyTreeBasic *> &listGeneTreePtrs, vector<GenericGeneSpeciesTreeProb *> &listGSTProbFinder );

	// which gene tree to explore
	int numSpecies;
	vector<PhylogenyTreeBasic *> &listGeneTreePtrs;
	vector<int> listMultiplicity;
	TaxaMapper &mapperTaxaIds;
    
	// tree explore properties
	PhylogenyTreeBasic spciesTreeCur;
	MarginalTree bestSpciesMargTree;
	double curLoglikeli;

	// tree exploring info
	int numNewTreesExplored;

	// configuration for search
	double minBranchLenHillClimb;
	double maxBranchLenHillClimb;
	bool fExploreNeighorTrees;
	bool fBrentMode;
	int numNearOptTreesKept;
    bool fOutputTreeHere;


	// act as a cache to avoid re-evaluation: <tree,prob>
	map<string, pair<double,MarginalTree> > processedNWTrees;

};




#endif
