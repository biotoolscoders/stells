//
//  FixedSTGeneTreeProb.cpp
//  
//
//  Created by Yufeng Wu on 7/8/15.
//
//

#include "FixedSTGeneTreeProb.h"
#include "Utils4.h"
#include <stack>
#include <cmath>

///////////////////////////////////////////////////////////////////////////////
// For profiling purpose

static int numUselessInfo = 0;
static int numUselessEntry = 0;
static int numCalcProbCalls = 0;
static int numRecalcProbCalls = 0;
static int numInitProb = 0;
static double totCalcProbCalls = 0.0;
static double totReCalcProbCalls = 0.0;
static double totInitProbTime = 0.0;
static std::clock_t tmStartCalcProb;
static std::clock_t tmStartReCalcProb;
static std::clock_t tmInitProb;

static void IncUselessInfo()
{
    ++numUselessInfo;
}
static void IncUselessEntry()
{
    ++numUselessEntry;
}

static void StartCalcProbCall()
{
    //
    GetCurrentCPUTime(tmStartCalcProb);
}

static void StartReCalcProbCall()
{
    //
    GetCurrentCPUTime(tmStartReCalcProb);
}

static void StartInitProbCall()
{
    //
    GetCurrentCPUTime(tmInitProb);
}

static void DoneCalcProbCall()
{
    ++numCalcProbCalls;
    totCalcProbCalls += GetElapseCPUTime(tmStartCalcProb);
}

static void DoneReCalcProbCall()
{
    ++numRecalcProbCalls;
    totReCalcProbCalls += GetElapseCPUTime(tmStartReCalcProb);
}

static void DoneInitProbCall()
{
    ++numInitProb;
    totInitProbTime += GetElapseCPUTime(tmInitProb);
}

void DumpProfileInfo()
{
    cout << "Number of CalcProb calls: " << numCalcProbCalls << endl;
    cout << "Average time for CalcProb calls: " << totCalcProbCalls/numCalcProbCalls << endl;
    cout << "Number of RE-CalcProb calls: " << numRecalcProbCalls << endl;
    cout << "Average time for CalcProb calls: " << totReCalcProbCalls/numRecalcProbCalls << endl;
    cout << "Number of Init Prob calls: " << numInitProb << endl;
    cout << "Average time for Init Prob calls: " << totInitProbTime/numInitProb << endl;
}


///////////////////////////////////////////////////////////////////////////////
// For testing purpose

void TestProbCode(MarginalTree &treeSpecies, PhylogenyTreeBasic &treeGene)
{
    // check up speed of calculation and re-calculation
    std::clock_t tmStart;
    GetCurrentCPUTime(tmStart);
    //long tstart1 = GetCurrentTimeTick();
    FastGeneTreeProbFixedSpecies fgtpProb( treeSpecies, treeGene );
    double probOther = fgtpProb.CalcLogProb();
    cout.precision(10);
    cout << "The new code prob =  " << probOther << endl;
    //cout << "Elapsed time for computing the probability of the gene tree for the first time = " << GetElapseTime( tstart1 ) << " seconds." << endl;
    cout << "Elapshed CPU time: " << GetElapseCPUTime(tmStart) << " seconds." << endl;
    
    const int NUM_RUNs = 1000;
    const int BRANCH_ID = 1;
    double brLenOld = treeSpecies.GetEdgeLen( BRANCH_ID );
    map<int,set< LineageConfig,LTLinCfg > > origLinCfgs;
    GetCurrentCPUTime(tmStart);
    //tstart1 = GetCurrentTimeTick();
    for(int i=0; i<NUM_RUNs; ++i)
    {
        double probOld = fgtpProb.TestNewBranchLenAt(BRANCH_ID, brLenOld, origLinCfgs, true );
        if( i == 0 )
        {
            cout << "The new code prob =  " << probOld << endl;
        }
    }
    //cout << "Elapsed time for recompute the probability of the gene tree for << " << NUM_RUNs  << " times = " << GetElapseTime( tstart1 ) << " seconds." << endl;
    cout << "Elapsed CPU time: for << " << NUM_RUNs  << " times = " << GetElapseCPUTime(tmStart) << " seconds." << endl;
}


///////////////////////////////////////////////////////////////////////////////
// main class for computing gene tree prob on species tree w/ fixed number of taxa
// note: gene tree is allowed to be non-binary

//////////////////////////////////////////////////////////////////////////////////
// Num of coalescents info

FGTPFSAncesCfgCoalInfo :: FGTPFSAncesCfgCoalInfo()
{
    // nothing
}

FGTPFSAncesCfgCoalInfo :: FGTPFSAncesCfgCoalInfo(const map<int,int> &mapCoalLimits) : mapSTBranchCoalNums(mapCoalLimits)
{
    //
}

FGTPFSAncesCfgCoalInfo :: FGTPFSAncesCfgCoalInfo(const FGTPFSAncesCfgCoalInfo &rhs) : mapSTBranchCoalNums(rhs.mapSTBranchCoalNums)
{
    //
}

bool FGTPFSAncesCfgCoalInfo :: operator<(const FGTPFSAncesCfgCoalInfo& rhs) const
{
    //
    return mapSTBranchCoalNums < rhs.mapSTBranchCoalNums;
}

void FGTPFSAncesCfgCoalInfo :: Dump() const
{
    //
    FGTPFSAncesCfgCoalInfo &pthis = const_cast<FGTPFSAncesCfgCoalInfo &>(*this);
    for( map<int, int> :: iterator it = pthis.mapSTBranchCoalNums.begin(); it != pthis.mapSTBranchCoalNums.end(); ++it )
    {
        //
        cout << "(s" << it->first << "): " << it->second;
    }
}

// update the number of coals at a particular node in ST
void FGTPFSAncesCfgCoalInfo :: SetCoalNumAt(int stnid, int numCoals)
{
    //
    mapSTBranchCoalNums.insert( map<int,int> :: value_type( stnid, numCoals ) );
}

// collect all possible entries by splitting it; setLins: if size=1, means entire subtree rooted at the single lin
// if size>=2, refer to collect of subtrees under a common parent
void FGTPFSAncesCfgCoalInfo :: CollectAllCoeffInfos( const map<int,int> &ubCoalNumsSTBrs, FGTPFSProbHelper &helper, set<FGTPFSAncesCfgCoalInfo> &setCoalNums ) 
{
    setCoalNums.clear();
    
    // consider each possible ST branch from low (small) to high (large)
    for( map<int, int> :: const_iterator it = ubCoalNumsSTBrs.begin(); it != ubCoalNumsSTBrs.end(); ++it)
    {
        CollectAllCoeffEntriesAtSTBranch( ubCoalNumsSTBrs, helper, setCoalNums, it->first, it->second );
    }
}


// collect all possible entries by processing a particular ST node
// this allows a bottom-up way of setting all coalescents along all ST branches
void FGTPFSAncesCfgCoalInfo :: CollectAllCoeffEntriesAtSTBranch( const map<int,int> &ubCoalNumsSTBrs, FGTPFSProbHelper &helper, set<FGTPFSAncesCfgCoalInfo> &setCoalNums, int stnid, int maxCoalOnSTBr )
{
//cout << "CollectAllCoeffEntriesAtSTBranch: stnid: " << stnid << ", maxCoalOnSTBr: " << maxCoalOnSTBr << endl;
    // find current entries to expand
    set<FGTPFSAncesCfgCoalInfo> setEntriesProc = setCoalNums;
    if( setEntriesProc.size() == 0 )
    {
        // if no prior entries are given, setup a single empty entry
        FGTPFSAncesCfgCoalInfo eInit;
        setEntriesProc.insert(eInit);
    }
    // for each current one, add as much as possible for the current ST
    set<FGTPFSAncesCfgCoalInfo> setEntriesProcNew;
    for( set<FGTPFSAncesCfgCoalInfo> :: iterator it = setEntriesProc.begin(); it != setEntriesProc.end(); ++it )
    {
        //
        int numCoalUnderBrInEntry = it->GetNumCoalsUnderSTNode(stnid, helper);
        int neLow = 0;
        if( stnid == helper.GetSTRoot() )
        {
            // at the root, must use all remaining
            neLow = maxCoalOnSTBr-numCoalUnderBrInEntry;
        }
        for(int ne = neLow; ne<=maxCoalOnSTBr-numCoalUnderBrInEntry; ++ne )
        {
            // create a new entry
            FGTPFSAncesCfgCoalInfo eNew = *it;
            eNew.SetCoalNumAt( stnid, ne );
            setEntriesProcNew.insert(eNew);
        }
    }
    
    // this is the set of entries obtained
    setCoalNums = setEntriesProcNew;
}

// get the number of coalsced events under a particular ST node (inclusive)
int FGTPFSAncesCfgCoalInfo :: GetNumCoalsUnderSTNode(int stNode, FGTPFSProbHelper &helperFGTPFS) const
{
    // for coalescents recorded, find those that falls under the st node 
    int res = 0;
    for( map<int, int> :: const_iterator it = mapSTBranchCoalNums.begin(); it != mapSTBranchCoalNums.end(); ++it )
    {
        if( helperFGTPFS.IsSTBranchUnder(it->first, stNode) == true )
        {
            res += it->second;
        }
    }
    return res;
}

int FGTPFSAncesCfgCoalInfo :: GetNumCoalsUnderSTNode(int stNode, const map<int,int> &mapCoalNumsSTBrs, FGTPFSProbHelper &helperFGTPFS)
{
    // get the number of coalescent events fo far under a particular ST node
    int res = 0;
    for( map<int, int> :: const_iterator it = mapCoalNumsSTBrs.begin(); it != mapCoalNumsSTBrs.end(); ++it )
    {
        if( helperFGTPFS.IsSTBranchUnder(it->first, stNode) == true )
        {
            res += it->second;
        }
    }
    return res;
}

// among all the events (w/ non-zero), what is the number of events occuring at the topmost species tree branch
int FGTPFSAncesCfgCoalInfo :: GetNumEvtLatest() const
{
    //
    FGTPFSAncesCfgCoalInfo *pthis = const_cast<FGTPFSAncesCfgCoalInfo *>(this);
    YW_ASSERT_INFO( mapSTBranchCoalNums.size() > 0, "Entry is empty" );
    // get the last non-zero by looking backward
    for( map<int,int> :: reverse_iterator it = pthis->mapSTBranchCoalNums.rbegin(); it != pthis->mapSTBranchCoalNums.rend(); ++it)
    {
        //
        if( it->second > 0 )
        {
            return it->second;
        }
    }
    YW_ASSERT_INFO(false, "Fail to fiind top event.");
    return -1;
}

// decrease the number of topmost event by one (if that ST branch no longer has events, erase the ST branch)
// for completeness, don't erase zero-entries
void FGTPFSAncesCfgCoalInfo :: DecTopEventNum()
{
    YW_ASSERT_INFO( mapSTBranchCoalNums.size() > 0, "Entry is empty" );
    // find the first non-zero entry BWT
    int stId = -1;
    
    for( map<int,int> :: reverse_iterator it = mapSTBranchCoalNums.rbegin(); it != mapSTBranchCoalNums.rend(); ++it)
    {
        //
        if( it->second > 0 )
        {
            stId = it->first;
            break;
        }
    }
    YW_ASSERT_INFO(stId >= 0, "Fatal error: coefficient entry: must have some coalescents");
    --mapSTBranchCoalNums[stId];
    //int numNew = 0;
    //if( mapSTBranchCoalNums.rbegin()->second > 1 )
    //{
    //    numNew = mapSTBranchCoalNums.rbegin()->second-1;
    //}
    //mapSTBranchCoalNums.erase( mapSTBranchCoalNums.rbegin()->first );
    //if( numNew > 0 )
    //{
    //    mapSTBranchCoalNums.insert( map<int,int> :: value_type( stId, numNew ) );
    //}
}

//#if 0
// ensure the total number of coalescent events are valid
bool FGTPFSAncesCfgCoalInfo :: TouchupTotCoalEvtsNum(const map<int,int> &ubSTBrCoalsUnder, FGTPFSProbHelper &helper)
{
    // Fix the entry by re-checking the validty of the entry
    // (1) examine each position to ensure the # of coal events under (inclusive) is not over the upper limit; if over the limit, return false
    // (2) ensure the root's #coal is compoensated s.t. the total number is exactly equal to total coal that need to occur
    //map<int,int> mapSTBranchCoalNumsNew;
    
    int stRoot = helper.GetSTRoot();
    
    for(map<int,int> :: const_iterator it = ubSTBrCoalsUnder.begin(); it != ubSTBrCoalsUnder.end(); ++it)
    {
        int stBrCur = it->first;
        int stUBCur = it->second;
        //int valBrCur = mapSTBranchCoalNums[stBrCur];
        
        // don't process the root
        if( stBrCur == stRoot)
        {
            continue;
        }
        
        // # of coals so far
        int numSoFar = 0;
        for( map<int, int> :: iterator it = mapSTBranchCoalNums.begin(); it != mapSTBranchCoalNums.end(); ++it )
        {
            //
            if( it->first <= stBrCur && helper.IsSTBrAncestralTo( stBrCur, it->first ) )
            {
                numSoFar += it->second;
            }
        }
        if( numSoFar > stUBCur )
        {
#if 0
            cout << "numSoFar = " << numSoFar << ", stUBCur: " << stUBCur << endl;
            Dump();
#endif
            return false;
        }
        
        //YW_ASSERT_INFO(numSoFar <= numEvtTot, "Overflow in event numbers");
        //if( mapSTBranchCoalNums.find( rootST) == mapSTBranchCoalNums.end() )
        //{
        //    cout << "This info does not make sense.\n";
        //    Dump();
        //}
        //YW_ASSERT_INFO( mapSTBranchCoalNums.find( rootST) != mapSTBranchCoalNums.end(), "Fial to find the root in info" );
        
        
        if( mapSTBranchCoalNums.find( stBrCur) == mapSTBranchCoalNums.end() )
        {
            cout << "stBrCur: " << stBrCur << endl;
            for(map<int,int> :: const_iterator itg =ubSTBrCoalsUnder.begin(); itg != ubSTBrCoalsUnder.end(); ++itg )
            {
                cout << "[" << itg->first << "," << itg->second << "]  ";
            }
            cout << endl;
            cout << "This info does not make sense.\n";
            Dump();
        }
        
        // if the root has already been assigned to a larger value, then bad
        YW_ASSERT_INFO( mapSTBranchCoalNums.find(stBrCur) != mapSTBranchCoalNums.end(), "Missing" );
        int valBrCur = mapSTBranchCoalNums[stBrCur];
        //if( numSoFar > stUBCur )
        //{
        //    valBrCur -= numSoFar-stUBCur;
        //}
        YW_ASSERT_INFO(valBrCur >= 0, "valBrCur: must be non-negative");
        mapSTBranchCoalNums[stBrCur] = valBrCur;
    }
    
    // now fix the root
    map<int,int> &ubSTBrCoalsUnderNC = const_cast<  map<int,int> & >(ubSTBrCoalsUnder);
    TouchupTotCoalEvtsNum( ubSTBrCoalsUnderNC[stRoot], stRoot );
    
    //mapSTBranchCoalNums = mapSTBranchCoalNumsNew;
    return true;
}
//#endif

//#if 0
// ensure the total number of coalescent events are valid
bool FGTPFSAncesCfgCoalInfo :: TouchupTotCoalEvtsNum(int numEvtTot, int rootST)
{
    // get the number of events in total
    int numSoFar = 0;
    for( map<int, int> :: iterator it = mapSTBranchCoalNums.begin(); it != mapSTBranchCoalNums.end(); ++it )
    {
        //
        if( it->first == rootST)
        {
            continue;
        }
        numSoFar += it->second;
    }
if( numSoFar > numEvtTot )
{
cout << "numSoFar = " << numSoFar << ", numEvtTot: " << numEvtTot << endl;
Dump();
}
    
    if( numSoFar > numEvtTot )
    {
        // this is not a good entry
        return false;
    }
    
    //YW_ASSERT_INFO(numSoFar <= numEvtTot, "Overflow in event numbers");
    if( mapSTBranchCoalNums.find( rootST) == mapSTBranchCoalNums.end() )
    {
        cout << "This info does not make sense.\n";
        Dump();
    }
    YW_ASSERT_INFO( mapSTBranchCoalNums.find( rootST) != mapSTBranchCoalNums.end(), "Fial to find the root in info" );
    
    // if the root has already been assigned to a larger value, then bad
    int valNewRoot = numEvtTot - numSoFar;
    //if( mapSTBranchCoalNums[rootST] > valNewRoot )
    //{
    //    return false;
    //}
    mapSTBranchCoalNums[rootST] = valNewRoot;
    return true;
}
//#endif

// clean up un-used ones
bool FGTPFSAncesCfgCoalInfo :: CleanUnusedSTBrs(const map<int,int> &ubSTBrCoalsUnder)
{
    // remove any entry if there are useless entries there (w/ event number = 0)
    // but if the event number is not zero, then cannot clean (return false)
    set<int> setSTBrToRemove;
    for( map<int,int>:: iterator it = this->mapSTBranchCoalNums.begin(); it != mapSTBranchCoalNums.end(); ++it )
    {
        //
        if( ubSTBrCoalsUnder.find( it->first) == ubSTBrCoalsUnder.end() )
        {
            if( it->second > 0 )
            {
                // cannot clean
                return false;
            }
            
            //YW_ASSERT_INFO(it->second == 0, "Cannot have assigned ones here");
            setSTBrToRemove.insert(it->first);
        }
    }
    for( set<int> :: iterator it = setSTBrToRemove.begin(); it != setSTBrToRemove.end(); ++it)
    {
        this->mapSTBranchCoalNums.erase(*it);
    }
    return true;
}

//////////////////////////////////////////////////////////////////////////////////
// For a given AC, compute the coefficients
// setDescCoals: set of descendents to coalesce within this event (if entire
// subtree coalesce into a single linage, then contain all children)


FGTPFSCoeffCompEntry :: FGTPFSCoeffCompEntry() : valCoeff(0.0)
{
    // 
}

FGTPFSCoeffCompEntry :: FGTPFSCoeffCompEntry(const set<TreeNode *> &setDescIn, const FGTPFSAncesCfgCoalInfo &STBranchCoalNumsIn) : setDescCoals(setDescIn), cfgSTBranchCoalNums(STBranchCoalNumsIn), valCoeff(0.0)
{
    //
}

FGTPFSCoeffCompEntry :: FGTPFSCoeffCompEntry(const FGTPFSCoeffCompEntry &rhs) : setDescCoals(rhs.setDescCoals), cfgSTBranchCoalNums(rhs.cfgSTBranchCoalNums), valCoeff(rhs.valCoeff)
{
    //
}

bool FGTPFSCoeffCompEntry :: operator<(const FGTPFSCoeffCompEntry &rhs) const
{
    // first the size of desc lineages should be considered the first
    if( setDescCoals.size() < rhs.setDescCoals.size() )
    {
        return true;
    }
    else if( setDescCoals.size() == rhs.setDescCoals.size() )
    {
        if( setDescCoals < rhs.setDescCoals )
        {
            return true;
        }
        else if(setDescCoals == rhs.setDescCoals)
        {
            if( cfgSTBranchCoalNums < rhs.cfgSTBranchCoalNums )
            {
                return true;
            }
        }
    }

    return false;
}

double FGTPFSCoeffCompEntry :: Calc(FGTPFSProbHelper &helper)
{
    // simply look up from the helper
    helper.RetriveCoeff(*this);
    return GetValue();
}

//
void FGTPFSCoeffCompEntry :: Dump() const
{
    //
    cout << "Entry: [" <<  this->GetValue() << "] <set of GT nodes: >: ";
    for(set<TreeNode *> :: iterator it = setDescCoals.begin(); it != setDescCoals.end(); ++it)
    {
        (*it)->Dump();
        cout << "  ";
    }
    cout << " coalnum settings: ";
    cfgSTBranchCoalNums.Dump();
    cout << endl;
}

// collect all possible entries by splitting it; setLins: if size=1, means entire subtree rooted at the single lin
// if size>=2, refer to collect of subtrees under a common parent
void FGTPFSCoeffCompEntry :: CollectAllCoeffEntries( const set<TreeNode *> &setGTLins, FGTPFSProbHelper &helper, set<FGTPFSCoeffCompEntry> &setCoalNums )
{
    // find the upper bounds on the number of coals on each species tree branch
    map<int,int> ubCoalNumsSTBrs;
    
    //map<int,int> ubCoalNumsSTBrsStep;
    helper.GetAllCoalBoundsOnSTBrsForGTSTs(setGTLins, ubCoalNumsSTBrs);
    //FindCoalsUBForSiblingsAllPartitions( setGTLins, helper, ubCoalNumsSTBrs );
#if 0
cout << "CollectAllCoeffEntries: ubCoalNumsSTBrs = ";
for( map<int,int> :: iterator it2 = ubCoalNumsSTBrs.begin(); it2 != ubCoalNumsSTBrs.end(); ++it2)
{
cout << "[" << it2->first << ", " << it2->second << "] ";
}
cout << endl;

    
cout << "CollectAllCoeffEntries: ubCoalNumsSTBrs = ";
for( map<int,int> :: iterator it2 = ubCoalNumsSTBrs.begin(); it2 != ubCoalNumsSTBrs.end(); ++it2)
{
cout << "[" << it2->first << ", " << it2->second << "] ";
}
cout << endl;
#endif
    
    // generate all the possible distribution based on the computed range
    set<FGTPFSAncesCfgCoalInfo> setCoalNumsStep;
    FGTPFSAncesCfgCoalInfo :: CollectAllCoeffInfos( ubCoalNumsSTBrs, helper, setCoalNumsStep );
    for( set<FGTPFSAncesCfgCoalInfo> :: iterator it = setCoalNumsStep.begin(); it != setCoalNumsStep.end(); ++it )
    {
        FGTPFSCoeffCompEntry eInfo( setGTLins, *it);
        setCoalNums.insert(eInfo);
    }
}


// get the range of coals within subtree branches for a list of GT subtrees
void FGTPFSCoeffCompEntry :: FindCoalsUBForSiblings( const set<TreeNode *> &setGtSiblings, FGTPFSProbHelper &helper, map<int,int> &mapSTCoalUBs )
{
    YW_ASSERT_INFO( setGtSiblings.size() >=2, "Size must be at least 2" );
    
    // we need one or more coalescents to coalesce the list of siblings
    // need to figure out what species branches this (or these) coalescents can happen
    //vector< set<int> > listTaxaGTSubtrees;
    set<int> taxaAllST;
    for( set<TreeNode *> :: iterator it = setGtSiblings.begin(); it != setGtSiblings.end(); ++it)
    {
        set<int> taxaGTSt;
        helper.GetTaxaUnderGTSubtree( *it, taxaGTSt );
        //listTaxaGTSubtrees.insert(taxaGTSt);
        
        UnionSets(taxaAllST, taxaGTSt);
    }

    // this coalescent (of all these lineages) must coalesce above the MRCA of this root
    int mrcaST = helper.GetMRCASTNodes( taxaAllST );
#if 0
cout << "FindCoalsUBForSiblings: mrcaST = " << mrcaST << " for taxaAllST: ";
DumpIntSet(taxaAllST);
cout << "setGtSiblings: ";
for( set<TreeNode *> :: iterator it2 = setGtSiblings.begin(); it2 != setGtSiblings.end(); ++it2)
{
(*it2)->Dump();
}
#endif
    set<int> ancesBrs;
    helper.GetAncesSTBranches(mrcaST, ancesBrs);
//cout << "AncesBrs: ";
//DumpIntSet(ancesBrs);
    for( set<int> :: iterator it = ancesBrs.begin(); it != ancesBrs.end(); ++it )
    {
        if( mapSTCoalUBs.find(*it) == mapSTCoalUBs.end() )
        {
            mapSTCoalUBs.insert( map<int,int> :: value_type( *it, 1 ) );
        }
        else
        {
            mapSTCoalUBs[ *it ] += 1;
        }
    }
}

// an entry is atomic if it has no enclosed coalescent and set of branches size = 2
bool FGTPFSCoeffCompEntry :: IsAtomic() const
{
    return setDescCoals.size() == 2 && (*setDescCoals.begin() )->IsLeaf() == true && (*setDescCoals.rbegin() )->IsLeaf() == true;
}

// among all the events (w/ non-zero), what is the number of events occuring at the topmost species tree branch
int FGTPFSCoeffCompEntry :: GetNumEvtLatest() const
{
    //
    return cfgSTBranchCoalNums.GetNumEvtLatest();
}

// decrease the number of topmost event by one (if that ST branch no longer has events, erase the ST branch)
void FGTPFSCoeffCompEntry :: DecTopEventNum()
{
    cfgSTBranchCoalNums.DecTopEventNum();
}

// obtain all feasible partitions
bool FGTPFSCoeffCompEntry :: FindAllParitionsForInfo( const FGTPFSAncesCfgCoalInfo &coalInfoOrig, const map<int,int> &boundPart1, const map<int,int> &boundPart2, int rootST, FGTPFSProbHelper &helper, set<pair< map<int,int>, map<int,int>  > > &setParts )
{
#if 0
cout << "FindAllParitionsForInfo orig info:";
coalInfoOrig.Dump();
cout << "FindAllParitionsForInfo: boundPart1= \n";
for(map<int,int> :: const_iterator it = boundPart1.begin(); it != boundPart1.end(); ++it)
{
cout << "[" << it->first << "," << it->second << "]  ";
}
cout << endl;
cout << "FindAllParitionsForInfo: boundPart2= \n";
for(map<int,int> :: const_iterator it = boundPart2.begin(); it != boundPart2.end(); ++it)
{
cout << "[" << it->first << "," << it->second << "]  ";
}
cout << endl;
#endif
    //
    map<int,int> &boundPart1NC = const_cast<map<int,int> &> (boundPart1);
    map<int,int> &boundPart2NC = const_cast<map<int,int> &> (boundPart2);
    set<pair< map<int,int>, map<int,int>  > > setPartsEnum;
    
    // start from low to high
    map<int,int> mapEvtList;
    coalInfoOrig.GetEventList( mapEvtList );
    
    // this process may fail (e.g. the partition is infeasible)
    bool fFail = false;
    
    for(map<int,int> :: iterator it = mapEvtList.begin(); it != mapEvtList.end(); ++it)
    {
        //
        int evtCur = it->first;
        int evtNumCur = it->second;
        // determine how to split into two parts
//cout << "evtCur = " << evtCur << ", evtNumCur = " << evtNumCur << endl;

        int evtPart1Det = -1, evtPart2Det = -1;
        //YW_ASSERT_INFO( boundPart1.find(evtCur) != boundPart1.end() && boundPart2.find(evtCur) != boundPart2.end(), "Fail1" );
        if( boundPart1.find(evtCur) == boundPart1.end() )
        {
            // part1 does not allow it
            evtPart1Det = 0;
            evtPart2Det = evtNumCur;
        }
        if( boundPart2.find(evtCur) == boundPart2.end() )
        {
            // part1 does not allow it
            //YW_ASSERT_INFO(evtPart1Det < 0, "Fail222-2");
            
            // if this event is not in both partitions, something is wrong, just fail
            if( evtPart1Det >= 0 && evtNumCur > 0 )
            {
                //
                fFail = true;
                break;
            }
            
            evtPart2Det = 0;
            evtPart1Det = evtNumCur;
        }
//cout << "evtPart1Det = " << evtPart1Det << ", evtPart2Det = " << evtPart2Det << endl;
        set< pair<int,int> > setEvtNumsNew;
        if( evtPart1Det >= 0 && evtPart2Det >= 0 )
        {
            // there is a single way to create entry and that is it
            pair<int,int> pp( evtPart1Det, evtPart2Det );
            setEvtNumsNew.insert(pp);
        }
        else
        {
            // try all partition as long as it does not exceed upper bound of both parts
            int maxCoalPart1 = boundPart1NC[ evtCur ];
            int maxCoalPart2 = boundPart2NC[ evtCur ];
            int lb = evtNumCur - maxCoalPart2;
            if( lb < 0 )
            {
                lb = 0;
            }
//cout << "maxCoalPart1: " << maxCoalPart1 << ", maxCoalPart2: " << maxCoalPart2 << ", lb: " << lb << endl;
            for(int ne=lb; ne<=maxCoalPart1 && ne <= evtNumCur; ++ne)
            {
                pair<int,int> pp(ne, evtNumCur-ne);
                setEvtNumsNew.insert(pp);
            }
            
            // if nothing is found, fail
            if( setEvtNumsNew.size() == 0 )
            {
//cout << "EARLY ABORT*********************************\n";
                fFail = true;
                break;
            }
        }
#if 0
cout << "setEvtNumsNew: ";
for(set< pair<int,int> > :: iterator it3 = setEvtNumsNew.begin(); it3 != setEvtNumsNew.end(); ++it3)
{
cout << "[" << it3->first << "," << it3->second << "]  ";
}
cout << endl;
#endif
        // now expand on each current partition
        set<pair< map<int,int>, map<int,int>  > > setPartsEnumNew;
        if( setPartsEnum.size() == 0 )
        {
//cout << "setPartsEnum: size is 0\n";
            // first time
            for( set< pair<int,int> > :: iterator it3 = setEvtNumsNew.begin(); it3 != setEvtNumsNew.end(); ++it3)
            {
                pair< map<int,int>, map<int,int> > pp2;
                if( boundPart1.find(evtCur) != boundPart1.end() )
                {
                    pp2.first.insert( map<int,int> :: value_type( evtCur, it3->first ) );
                }
                if( boundPart2.find(evtCur) != boundPart2.end() )
                {
                    pp2.second.insert(  map<int,int> :: value_type( evtCur, it3->second ) );
                }
                setPartsEnumNew.insert(pp2);
            }
        }
        else
        {
            for( set<pair< map<int,int>, map<int,int>  > > :: iterator it2 = setPartsEnum.begin(); it2 != setPartsEnum.end(); ++it2 )
            {
                // get the number of coalescents under the current evt; this should not exceed the bound
                int ncSoFar1 = FGTPFSAncesCfgCoalInfo :: GetNumCoalsUnderSTNode( evtCur, it2->first, helper );
                int ncSoFar2 = FGTPFSAncesCfgCoalInfo :: GetNumCoalsUnderSTNode( evtCur, it2->second, helper );;
//cout << "Expanding: ncSoFar1: " << ncSoFar1 << ", ncSoFar2: " << ncSoFar2 << endl;
                for( set< pair<int,int> > :: iterator it3 = setEvtNumsNew.begin(); it3 != setEvtNumsNew.end(); ++it3)
                {
                    // ignore any new entry if it is already over the bound
                    if( boundPart1.find(evtCur) != boundPart1.end()  && ncSoFar1+it3->first > boundPart1NC[evtCur] )
                    {
                        continue;
                    }
                    if( boundPart2.find(evtCur) != boundPart2.end()  && ncSoFar2+it3->second > boundPart2NC[evtCur] )
                    {
                        continue;
                    }
                    
                    pair< map<int,int>, map<int,int> > pp2 = *it2;
                    if( boundPart1.find(evtCur) != boundPart1.end() )
                    {
                        pp2.first.insert( map<int,int> :: value_type( evtCur, it3->first ) );
                    }
                    if( boundPart2.find(evtCur) != boundPart2.end() )
                    {
                        pp2.second.insert(  map<int,int> :: value_type( evtCur, it3->second ) );
                    }
                    setPartsEnumNew.insert(pp2);
#if 0
cout << "Adding pp2 event: first: ";
for(map<int,int> :: const_iterator it4 = pp2.first.begin(); it4 != pp2.first.end(); ++it4)
{
cout << "[" << it4->first << "," << it4->second << "]  ";
}
cout << "  second: ";
for(map<int,int> :: const_iterator it4 = pp2.second.begin(); it4 != pp2.second.end(); ++it4)
{
cout << "[" << it4->first << "," << it4->second << "]  ";
}
#endif
                }
            }
            
            // if failing to continue, then this must be a dead end
            if( setPartsEnumNew.size() == 0 )
            {
                setParts.clear();
                return false;
            }
        }
        setPartsEnum = setPartsEnumNew;
    }
    
    if( fFail == true )
    {
        setParts.clear();
        return false;
    }
    
    setParts = setPartsEnum;

#if 0
cout << "FindAllParitionsForInfo: ";
for( set<pair< map<int,int>, map<int,int>  > >  :: iterator it =  setParts.begin(); it != setParts.end(); ++it)
{
cout << "part 1: (";
for( map<int,int> :: const_iterator it2 = it->first.begin(); it2 != it->first.end(); ++it2)
{
cout << it2->first << ", " << it2->second << "    ";
}
cout << "   Part2: ";
for( map<int,int> :: const_iterator it2 = it->second.begin(); it2 != it->second.end(); ++it2)
{
cout << it2->first << ", " << it2->second << "    ";
}
cout  << ")\n";
}
#endif
    return true;
}


//////////////////////////////////////////////////////////////////////////////////
// Helper class for prob calculation


FGTPFSProbHelper :: FGTPFSProbHelper( MarginalTree &treeSpeciesIn, PhylogenyTreeBasic &treeGeneIn ) : treeSpecies(treeSpeciesIn), treeGene(treeGeneIn), helperOfFGTPFSProbHelper( treeSpecies, treeGene )
{
    //
    Init();
}

void FGTPFSProbHelper :: Init()
{
    StartInitProbCall();
    
    // init UB info
    CollectUBAllSibGTLinsSTBrs();
    
    // init coefficients
    ConsNodesCoalCoeffs();
    
    DoneInitProbCall();
}

void FGTPFSProbHelper :: Dump() const
{
    //
    cout << "****** List of coefficient entries (" << mapCoalCoeffsAll.size() << " entries) ******* \n";
    for( set<FGTPFSCoeffCompEntry> :: iterator it = mapCoalCoeffsAll.begin(); it != mapCoalCoeffsAll.end(); ++it )
    {
        //
        (*it).Dump();
    }
}

// get all ST branches that coalescent may occur on them from subtrees rooted at these nodes (self included)
void FGTPFSProbHelper :: GetAllCoalBoundsOnSTBrsForGTSTs( const set<TreeNode *> &setGTSubtrees, map<int,int> &mapSTNidBoundss )
{
    // if not founnd, just set to zero
    if( mapMaxCoalNumsAtSTBrSibGTBrs.find( setGTSubtrees) == mapMaxCoalNumsAtSTBrSibGTBrs.end() )
    {
        for(int br=0; br<treeSpecies.GetTotNodesNum(); ++br )
        {
            mapSTNidBoundss.insert( map<int,int> :: value_type(br, 0) );
        }
        return;
    }
    
    
    // simply use the method implemented in Entry class
    //FGTPFSCoeffCompEntry :: FindCoalsUBForSiblingsAllPartitions(setGTSubtrees, *this, mapSTNidBoundss);
    YW_ASSERT_INFO( mapMaxCoalNumsAtSTBrSibGTBrs.find(setGTSubtrees) != mapMaxCoalNumsAtSTBrSibGTBrs.end(), "Fail222-1" );
    mapSTNidBoundss = mapMaxCoalNumsAtSTBrSibGTBrs[ setGTSubtrees ];
    
#if 0
cout << "GetAllCoalBoundsOnSTBrsForGTSTs: mapSTNidBoundss: ";
for(map<int,int> :: iterator it = mapSTNidBoundss.begin(); it != mapSTNidBoundss.end(); ++it)
{
cout << "(" << it->first << " " << it->second << ")\n";
}
#endif
}

// build up a table holding coefficients for all possible node/subsets
void FGTPFSProbHelper :: ConsNodesCoalCoeffs()
{
    // collect nodes info for each GT node
    PhylogenyTreeIterator itor( treeGene );
    itor.Init();
    while(itor.IsDone() == false )
    {
        TreeNode *pn = itor.GetCurrNode();
        
        if( pn->IsLeaf() == false )
        {
            CollectCoalInfoAt( pn );
        }
        
        itor.Next();
    }
}

// calc over the coeff of the consructed coeff-entry using what we know before
void FGTPFSProbHelper :: CalcCoeffFor(FGTPFSCoeffCompEntry &entryCoeff)
{
#if 0
cout << "-----------Entering CalcCoeffFor:";
entryCoeff.Dump();
#endif
    // if this is a leaf entry, easy
    if( entryCoeff.IsAtomic() == true )
    {
        entryCoeff.SetValue(1.0);
        return ;
    }
    
    // multiply the first factor by the topmost coalescent
    int numInLatestEntry = entryCoeff.GetNumEvtLatest();
    YW_ASSERT_INFO(numInLatestEntry > 0, "Cannot be zero");
    double factorTop = 1.0/numInLatestEntry;
    
    // consider all paritions of children lineages
    set<TreeNode *> setLins;
    entryCoeff.GetDescCoals(setLins);
    vector<TreeNode *> vecSetLins;
    PopulateVecBySetGen(vecSetLins, setLins);
    
    double resRec = 0.0;
    for(int sz=1; sz<=(int)vecSetLins.size()/2; ++sz )
    {
        //
        vector<int> posvec;
        GetFirstCombo(sz, vecSetLins.size(), posvec);
        
        while(true)
        {
#if 0
cout << "CalcCoeffFor: posvec: ";
DumpIntVec( posvec);
#endif
            // ensure no double counting
            if( 2*sz<(int)vecSetLins.size() || posvec[0] == 0 )
            {
                set<TreeNode *> setLinsOnePart;
                for( int i=0; i<(int)posvec.size(); ++i )
                {
                    //
                    setLinsOnePart.insert( vecSetLins[ posvec[i] ] );
                }
                
                // find all entries for this subset
                set<TreeNode *> setLinsOtherPart = setLins;
                SubtractSetsGen( setLinsOtherPart, setLinsOnePart );
#if 0
cout << "CalcCoeffFor: setLinsOnePart: ";
for( set<TreeNode *> :: iterator it2 = setLinsOnePart.begin(); it2 != setLinsOnePart.end(); ++it2)
{
(*it2)->Dump();
}
cout << "CalcCoeffFor: setLinsOtherPart: ";
for( set<TreeNode *> :: iterator it2 = setLinsOtherPart.begin(); it2 != setLinsOtherPart.end(); ++it2)
{
(*it2)->Dump();
}
#endif
                // now consider all possible partition of events numbers
                FGTPFSCoeffCompEntry entrySmaller = entryCoeff;
                entrySmaller.DecTopEventNum();
                
                set<pair<FGTPFSCoeffCompEntry, FGTPFSCoeffCompEntry> > setPartsNew;
                SplitEntryToTwoPartitions( entrySmaller, setLinsOnePart, setLinsOtherPart, setPartsNew );
                
                // update by each of the paritions pairs
                for( set<pair<FGTPFSCoeffCompEntry, FGTPFSCoeffCompEntry> > :: iterator it2 = setPartsNew.begin(); it2 != setPartsNew.end(); ++it2 )
                {
#if 0
cout << "^^^ two entries: ";
it2->first.Dump();
cout << "    #2: ";
it2->second.Dump();
#endif
                    resRec += it2->first.GetValue() * it2->second.GetValue();
                }
//cout << "   curerntly, resRec = " << resRec << endl;
            }
            
            //
            if( GetNextCombo(sz, vecSetLins.size(), posvec) == false )
            {
                break;
            }
        }
    }
#if 0
cout << "CalcCoeffFor: factorTop=" << factorTop << ", resRec= " << resRec << ", entryCoeff:";
entryCoeff.Dump();
#endif
    double res =factorTop*resRec;
    entryCoeff.SetValue(res);
}

// split a entry into two children
void FGTPFSProbHelper :: SplitEntryToTwoPartitions( const FGTPFSCoeffCompEntry &entrySplit, const set<TreeNode *> &setLinsPart1, const set<TreeNode *> &setLinsPart2, set<pair<FGTPFSCoeffCompEntry, FGTPFSCoeffCompEntry> > &setPartsNew )
{
    // placeholder for an entry w/ value 1
    FGTPFSCoeffCompEntry entryOneInit;
    entryOneInit.SetValue(1.0);
#if 0
cout << "SplitEntryToTwoPartitions:Processing setLinsPart1: ";
for( set<TreeNode *> :: iterator it2 = setLinsPart1.begin(); it2 != setLinsPart1.end(); ++it2)
{
(*it2)->Dump();
}
cout << "SplitEntryToTwoPartitions:Processing setLinsPart2: ";
for( set<TreeNode *> :: iterator it2 = setLinsPart2.begin(); it2 != setLinsPart2.end(); ++it2)
{
(*it2)->Dump();
}
cout << "entrySplit: ";
entrySplit.Dump();
#endif
    //
    set<TreeNode *> setPart1Sub;
    if( setLinsPart1.size() > 1 )
    {
        //
        setPart1Sub = setLinsPart1;
    }
    else if( (*(setLinsPart1.begin() ))->IsLeaf() == false )
    {
        (*(setLinsPart1.begin() ))->GetAllChildren( setPart1Sub );
    }
    set<TreeNode *> setPart2Sub;
    if( setLinsPart2.size() > 1 )
    {
        //
        setPart2Sub = setLinsPart2;
    }
    else if( (*(setLinsPart2.begin() ))->IsLeaf() == false )
    {
        (*(setLinsPart2.begin() ))->GetAllChildren( setPart2Sub );
    }
    // cannot be both empty
    YW_ASSERT_INFO( setPart1Sub.size() > 0 || setPart2Sub.size() > 0, "Cannot be both empty" );
    if( setPart1Sub.size() == 0 )
    {
        FGTPFSAncesCfgCoalInfo info1( entrySplit.GetInfo() );
        map<int,int> mapUBEvtsSub;
        GetAllCoalBoundsOnSTBrsForGTSTs( setPart2Sub, mapUBEvtsSub );
        bool f1 = info1.TouchupTotCoalEvtsNum( mapUBEvtsSub, *this );
        if( f1 == true )
        {
            FGTPFSCoeffCompEntry entryNew(setPart2Sub, info1 );
            if( CleanUnusedSTBrs(entryNew) == true )
            {
                RetriveCoeff( entryNew );
                pair<FGTPFSCoeffCompEntry,FGTPFSCoeffCompEntry> pp( entryOneInit, entryNew );
                setPartsNew.insert(pp);
            }
            else
            {
//cout << "1: USELESS ENTRY: ";
//entryNew.Dump();
                IncUselessEntry();
            }
        }
        else
        {
// this is a useless partition; can we avoid it???
//cout << "1. USELESS INFO: ";
//info1.Dump();
            IncUselessInfo();
        }
        return;
    }
    if( setPart2Sub.size() == 0 )
    {
        FGTPFSAncesCfgCoalInfo info1( entrySplit.GetInfo() );
        map<int,int> mapUBEvtsSub;
        GetAllCoalBoundsOnSTBrsForGTSTs( setPart1Sub, mapUBEvtsSub );
        bool f1 = info1.TouchupTotCoalEvtsNum( mapUBEvtsSub, *this );
        if( f1 == true)
        {
            FGTPFSCoeffCompEntry entryNew(setPart1Sub, info1 );
            if( CleanUnusedSTBrs(entryNew) == true )
            {
                RetriveCoeff( entryNew );
                pair<FGTPFSCoeffCompEntry,FGTPFSCoeffCompEntry> pp( entryOneInit, entryNew );
                setPartsNew.insert(pp);
            }
            else
            {
//cout << "2: USELESS ENTRY: ";
//entryNew.Dump();
                IncUselessEntry();
            }
        }
        else
        {
// this is a useless partition; can we avoid it???
//cout << "2. USELESS INFO: ";
//info1.Dump();
            IncUselessInfo();
        }
        return;
    }
    
    // now need to consider more complex enumeration here...
    map<int,int> mapUBEvtsPart1, mapUBEvtsPart2;
    GetAllCoalBoundsOnSTBrsForGTSTs( setPart1Sub, mapUBEvtsPart1 );
    GetAllCoalBoundsOnSTBrsForGTSTs( setPart2Sub, mapUBEvtsPart2 );
#if 0
cout << "SplitEntryToTwoPartitions: mapUBEvtsPart1= \n";
for(map<int,int> :: const_iterator it = mapUBEvtsPart1.begin(); it != mapUBEvtsPart1.end(); ++it)
{
cout << "[" << it->first << "," << it->second << "]  ";
}
cout << "SplitEntryToTwoPartitions: mapUBEvtsPart2= \n";
for(map<int,int> :: const_iterator it = mapUBEvtsPart2.begin(); it != mapUBEvtsPart2.end(); ++it)
{
cout << "[" << it->first << "," << it->second << "]  ";
}
#endif
    
    // root is important
    int rootST = GetSTRoot();
    YW_ASSERT_INFO( mapUBEvtsPart1.find(rootST) != mapUBEvtsPart1.end(), "Fail to find1" );
    YW_ASSERT_INFO( mapUBEvtsPart2.find(rootST) != mapUBEvtsPart2.end(), "Fail to find2" );
    
    // try all possible partitions
    set<pair< map<int,int>, map<int,int>  > > setPartsEnum;
    bool fOK = FGTPFSCoeffCompEntry :: FindAllParitionsForInfo( entrySplit.GetInfo(), mapUBEvtsPart1, mapUBEvtsPart2, GetSTRoot(), *this, setPartsEnum );
    if( fOK == true )
    {
        for( set<pair< map<int,int>, map<int,int>  > > :: iterator it = setPartsEnum.begin(); it != setPartsEnum.end(); ++it )
        {
            //
            FGTPFSAncesCfgCoalInfo info1( it->first );
            //bool f1 = info1.TouchupTotCoalEvtsNum(mapUBEvtsPart1[rootST], rootST);
            bool f1 = info1.TouchupTotCoalEvtsNum( mapUBEvtsPart1, *this );            
            FGTPFSAncesCfgCoalInfo info2( it->second );
            //bool f2 = info2.TouchupTotCoalEvtsNum(mapUBEvtsPart2[rootST], rootST);
            bool f2 = info2.TouchupTotCoalEvtsNum( mapUBEvtsPart2, *this );
            
if( f1 == false )
{
// this is a useless partition; can we avoid it???
//cout << "3. USELESS INFO: ";
//info1.Dump();
//cout << "   #2: ";
//info2.Dump();
    IncUselessInfo();
}
if( f2 == false )
{
// this is a useless partition; can we avoid it???
//cout << "4. USELESS INFO: ";
//info1.Dump();
//cout << "   #2: ";
//info2.Dump();
    IncUselessInfo();
}
            
            if( f1 == true && f2 == true )
            {
                FGTPFSCoeffCompEntry entry1New( setPart1Sub, info1 );
                double v1 = -1.0;
                if( CleanUnusedSTBrs(entry1New) == true )
                {
                    v1 = RetriveCoeff( entry1New );
                }
                else
                {
//cout << "3: USELESS ENTRY: ";
//entry1New.Dump();
                    IncUselessEntry();
                }
                //double v1 = RetriveCoeff( entry1New );
                FGTPFSCoeffCompEntry entry2New( setPart2Sub, info2 );
                double v2 = -1.0;
                if( CleanUnusedSTBrs(entry2New) == true )
                {
                    v2 = RetriveCoeff( entry2New );
                }
                else
                {
//cout << "4: USELESS ENTRY: ";
//entry2New.Dump();
                    IncUselessEntry();
                }
                if( v1 >= 0.0 && v2 >= 0.0)
                {
                    pair<FGTPFSCoeffCompEntry,FGTPFSCoeffCompEntry> pp( entry1New, entry2New );
                    setPartsNew.insert(pp);
#if 0
cout << "SplitEntryToTwoPartitions: adding a pair of entries: ";
entry1New.Dump();
cout << "  #2: ";
entry2New.Dump();
#endif
                }
            }
        }
    }
}

// collect all possible coal infos at node
void FGTPFSProbHelper :: CollectAllCoalInfoAt(TreeNode *pnCurr)
{
//cout << "--CollectAllCoalInfoAt: pnCurr: ";
//pnCurr->Dump();
    
    
    //
    YW_ASSERT_INFO( pnCurr->GetChildrenNum() >= 2, "Must have children" );
    
    // try all possible subsets of children
    vector<TreeNode *> vecGtSiblings;
    for(int i=0; i<pnCurr->GetChildrenNum(); ++i)
    {
        vecGtSiblings.push_back( pnCurr->GetChild(i) );
    }
    
    // consider all subsets of these branches to find the top
    for(int sz=2; sz<=(int)vecGtSiblings.size(); ++sz )
    {
        //
        vector<int> posvec;
        GetFirstCombo(sz, vecGtSiblings.size(), posvec);
        
        while(true)
        {
            set<TreeNode *> setLins;
            for( int i=0; i<(int)posvec.size(); ++i )
            {
                //
                setLins.insert( vecGtSiblings[ posvec[i] ] );
            }
#if 0
cout << "Processing setLins: ";
for( set<TreeNode *> :: iterator it2 = setLins.begin(); it2 != setLins.end(); ++it2)
{
(*it2)->Dump();
}
#endif
            
            // find all entries for this subset
            set<FGTPFSCoeffCompEntry> setCoalNumsStep;
            FGTPFSCoeffCompEntry :: CollectAllCoeffEntries( setLins, *this, setCoalNumsStep );
            
            // update the coefficient values
            for( set<FGTPFSCoeffCompEntry>::iterator it2= setCoalNumsStep.begin(); it2!=setCoalNumsStep.end(); ++it2 )
            {
                //
                FGTPFSCoeffCompEntry &pentry = const_cast<FGTPFSCoeffCompEntry &>( (*it2) );
                CalcCoeffFor(pentry);
            }
            
            UnionSetsGen( this->mapCoalCoeffsAll, setCoalNumsStep );
            
            
            //
            if( GetNextCombo(sz, vecGtSiblings.size(), posvec) == false )
            {
                break;
            }
        }
    }
}

// for node, collect coalescent info at GT node
void FGTPFSProbHelper :: CollectCoalInfoAt(TreeNode *pnCurr)
{
    //
    //set<FGTPFSCoeffCompEntry> setCoalNums;
    CollectAllCoalInfoAt(pnCurr);
    
    //UnionSetsGen(this->mapCoalCoeffsAll, setCoalNums);
}

// is a ST branch under another branch (inclusive: i.e. branch a is considered to be under itself)
bool FGTPFSProbHelper :: IsSTBranchUnder(int snChild, int snAnc)
{
    //
    return treeSpecies.IsNodeUnder( snChild, snAnc );
}

// get taxa of all leaves under a subtree
void FGTPFSProbHelper :: GetTaxaUnderGTSubtree( TreeNode *gtSTNode, set<int> &setTaxa )
{
    set<TreeNode *> setLeavesUnder;
    gtSTNode->GetAllLeavesUnder( setLeavesUnder );
    set<int> setLeafIds;
    for(set<TreeNode *> :: iterator it = setLeavesUnder.begin(); it != setLeavesUnder.end(); ++it)
    {
        setLeafIds.insert( (*it)->GetID() );
    }
    setTaxa.clear();
    for( set<int> :: iterator it = setLeafIds.begin(); it != setLeafIds.end(); ++it)
    {
        int taxon = helperOfFGTPFSProbHelper.GetSpeciesForGTLeaf( *it );
//cout << "For gene tree leaf: " << *it << ", taxon: " << taxon << endl;
        setTaxa.insert( taxon );
    }
}

// find the MRCA of a set of ST nodes
int FGTPFSProbHelper :: GetMRCASTNodes( const set<int> &setSTNodes )
{
    //
    return treeSpecies.GetMRCAForNodes(setSTNodes);
}

// get all ancestral ST branches (inclusive again)
void FGTPFSProbHelper :: GetAncesSTBranches(int stBr, set<int> &ancesBrs)
{
    //
    int mrcaTop = treeSpecies.GetPath( stBr, treeSpecies.GetRoot(), ancesBrs );
    YW_ASSERT_INFO(mrcaTop == treeSpecies.GetRoot(), "MCRA must be the root");
    ancesBrs.insert(mrcaTop);
}

// test ancestral relation
bool FGTPFSProbHelper :: IsSTBrAncestralTo( int brSTAnc, int brSTDest )
{
    //
    return treeSpecies.IsNodeUnder( brSTDest, brSTAnc );
}
// obtain pre-computed coefficient value
double FGTPFSProbHelper :: RetriveCoeff( FGTPFSCoeffCompEntry &entry )
{
    //
//cout << "RetriveCoeff: entry = ";
//entry.Dump();
//cout << "Current set of known entries: ";
//Dump();
    
    //if( mapCoalCoeffsAll.find(entry) == mapCoalCoeffsAll.end() )
    //{
    //    cout << "WARNING: fail to find the entry.\n";
    //    return -1.0;
    //}
    
    YW_ASSERT_INFO( mapCoalCoeffsAll.find(entry) != mapCoalCoeffsAll.end(), "The entry is not pre-computed" );
    entry.SetValue( (*( mapCoalCoeffsAll.find(entry) )).GetValue() );
    return entry.GetValue();
}

// construct UB for all sibling GT lins and each ST branches
void FGTPFSProbHelper :: CollectUBAllSibGTLinsSTBrs()
{
    // bottom up approach
    PhylogenyTreeIterator itor( treeGene );
    itor.Init();
    while(itor.IsDone() == false )
    {
        TreeNode *pnCurr = itor.GetCurrNode();
        
        if( pnCurr->IsLeaf() == false )
        {
            // consider all subsets of its descendents
            vector<TreeNode *> vecGtSiblings;
            for(int i=0; i<pnCurr->GetChildrenNum(); ++i)
            {
                vecGtSiblings.push_back( pnCurr->GetChild(i) );
            }
            
            // consider all subsets of these branches to find the top
            for(int sz=2; sz<=(int)vecGtSiblings.size(); ++sz )
            {
                //
                vector<int> posvec;
                GetFirstCombo(sz, vecGtSiblings.size(), posvec);
                
                while(true)
                {
                    set<TreeNode *> setLins;
                    for( int i=0; i<(int)posvec.size(); ++i )
                    {
                        //
                        setLins.insert( vecGtSiblings[ posvec[i] ] );
                    }
#if 0
cout << "CollectUBAllSibGTLinsSTBrs :: Processing setLins: ";
for( set<TreeNode *> :: iterator it2 = setLins.begin(); it2 != setLins.end(); ++it2)
{
(*it2)->Dump();
}
#endif
                    
                    // find all entries for this subset
                    CollectUBForSibGTLins( setLins );
                  
                    //
                    if( GetNextCombo(sz, vecGtSiblings.size(), posvec) == false )
                    {
                        break;
                    }
                }
            }
            
            
        }
        
        itor.Next();
    }
#if 0
    // dump all UB info
    cout << "*************** List of UB on # of coalescents for gene tree siblings *******************\n";
    for( map<set<TreeNode *>, map<int,int> > :: iterator it = mapMaxCoalNumsAtSTBrSibGTBrs.begin(); it != mapMaxCoalNumsAtSTBrSibGTBrs.end(); ++it)
    {
        //
        cout << "Gene tree sibllings: ";
        for( set<TreeNode *> :: iterator it2 = it->first.begin(); it2 != it->first.end(); ++it2)
        {
            (*it2)->Dump();
        }
        cout << "     map of ST branches and their UB: ";
        for( map<int,int> :: iterator it3 = it->second.begin(); it3 != it->second.end(); ++it3)
        {
            cout << "s" << it3->first << ": " << it3->second << " ";
        }
        cout << endl;
    }
    cout << endl;
#endif
}

// update UB info for a sibling GT lins
void FGTPFSProbHelper :: CollectUBForSibGTLins( const set<TreeNode *> &setGtSiblings )
{
    YW_ASSERT_INFO(setGtSiblings.size() >=2, "Must have at least two siblings");
    
    // consider the topmost coalescent first
    map<int,int> mapSTCoalUBs;
    FGTPFSCoeffCompEntry :: FindCoalsUBForSiblings( setGtSiblings, *this, mapSTCoalUBs );
    
#if 0
cout << "CollectUBForSibGTLins: Gene tree sibllings: ";
for( set<TreeNode *> :: iterator it2 = setGtSiblings.begin(); it2 != setGtSiblings.end(); ++it2)
{
(*it2)->Dump();
}
cout << "mapSTCoalUBs and their UB: ";
for( map<int,int> :: iterator it3 = mapSTCoalUBs.begin(); it3 != mapSTCoalUBs.end(); ++it3)
{
cout << "s" << it3->first << ": " << it3->second << " ";
}
cout << endl;
#endif
    
    // now adds on descendents
    // if only two siblings, then consider the subtrees; otherwise, max over the subsets of siblings
    map<int,int> mapSTCoalUBsDesc;
    //if( setGtSiblings.size() == 2 )
    //{
    //    //
    //}
    //else
    //{
    //
    // now process all subset of descendents
    vector<TreeNode *> vecGtSiblings;
    PopulateVecBySetGen( vecGtSiblings, setGtSiblings );
    
    // consider all subsets of these branches to find the top
    for(int sz=1; sz<=(int)vecGtSiblings.size()/2; ++sz )
    {
        //
        vector<int> posvec;
        GetFirstCombo(sz, vecGtSiblings.size(), posvec);
        
        while(true)
        {
            if( 2*sz <(int)vecGtSiblings.size() || posvec[0]== 0 )
            {
                //
                set<TreeNode *> setLinsParts[2];
                for( int i=0; i<(int)posvec.size(); ++i )
                {
                    //
                    setLinsParts[0].insert( vecGtSiblings[ posvec[i] ] );
                }
                setLinsParts[1] = setGtSiblings;
                SubtractSetsGen( setLinsParts[1], setLinsParts[0] );
                
                for( int ii=0; ii<=1; ++ii )
                {
                    //
                    if( setLinsParts[ii].size() == 1)
                    {
                        if( (*setLinsParts[ii].begin())->IsLeaf() == false )
                        {
                            set<TreeNode *> setChildren;
                            (*setLinsParts[ii].begin())->GetAllChildren( setChildren );
                            setLinsParts[ii] =  setChildren;
                        }
                        else
                        {
                            // make it empty
                            setLinsParts[ii].clear();
                        }
                    }
                }
                
#if 0
cout << "CollectUBForSibGTLins setLins: ";
for( set<TreeNode *> :: iterator it2 = setLinsParts[0].begin(); it2 != setLinsParts[0].end(); ++it2)
{
(*it2)->Dump();
}
cout << "CollectUBForSibGTLins setLins2: ";
for( set<TreeNode *> :: iterator it2 = setLinsParts[1].begin(); it2 != setLinsParts[1].end(); ++it2)
{
(*it2)->Dump();
}
#endif
                
                map<int,int> mapSTCoalUBsDescStep;
                for(int ii=0; ii<=1; ++ii)
                {
                    if( setLinsParts[ii].size() == 0 )
                    {
                        int iiOther = 1-ii;
                        if( setLinsParts[iiOther].size() > 0 )
                        {
                            YW_ASSERT_INFO( mapMaxCoalNumsAtSTBrSibGTBrs.find(setLinsParts[iiOther]) != mapMaxCoalNumsAtSTBrSibGTBrs.end(), "Fail to find223" );
                            mapSTCoalUBsDescStep = mapMaxCoalNumsAtSTBrSibGTBrs[ setLinsParts[iiOther] ];
                        }
                    }
                }
                if( mapSTCoalUBsDescStep.size() == 0 && ( setLinsParts[0].size() > 0 && setLinsParts[1].size() > 0  ) )
                {
                    //
                    YW_ASSERT_INFO( mapMaxCoalNumsAtSTBrSibGTBrs.find(setLinsParts[0]) != mapMaxCoalNumsAtSTBrSibGTBrs.end(), "Fail to find223-1" );
                    YW_ASSERT_INFO( mapMaxCoalNumsAtSTBrSibGTBrs.find(setLinsParts[1]) != mapMaxCoalNumsAtSTBrSibGTBrs.end(), "Fail to find223-2" );
                    mapSTCoalUBsDescStep = mapMaxCoalNumsAtSTBrSibGTBrs[ setLinsParts[0] ];
                    map<int,int> mapSTCoalUBsDescStep2 = mapMaxCoalNumsAtSTBrSibGTBrs[ setLinsParts[1] ];
                    AddingMaps( mapSTCoalUBsDescStep, mapSTCoalUBsDescStep2 );
                }
                // combine two maps by taking the maximum
                MaxMaps( mapSTCoalUBsDesc, mapSTCoalUBsDescStep, true );
            }
            //
            if( GetNextCombo(sz, vecGtSiblings.size(), posvec) == false )
            {
                break;
            }
        }
    }
    //}
    
    // finally add up the two parts: the topmost and the descnendets
#if 0
cout << "mapSTCoalUBsDesc: ";
for( map<int,int> :: iterator it3 = mapSTCoalUBsDesc.begin(); it3 != mapSTCoalUBsDesc.end(); ++it3)
{
cout << "s" << it3->first << ": " << it3->second << " ";
}
cout << endl;
#endif
    AddingMaps(mapSTCoalUBs, mapSTCoalUBsDesc);
    mapMaxCoalNumsAtSTBrSibGTBrs.insert( map<set<TreeNode *>, map<int,int> > :: value_type( setGtSiblings, mapSTCoalUBs ) );
}

// cleanup a entryinfo by removing not-used ST events
bool FGTPFSProbHelper :: CleanUnusedSTBrs( FGTPFSCoeffCompEntry &entryToClean )
{
//cout << "Before cleanup: entry: ";
//entryToClean.Dump();
    //
    set<TreeNode *> setNodes;
    entryToClean.GetDescCoals(setNodes);
    YW_ASSERT_INFO( mapMaxCoalNumsAtSTBrSibGTBrs.find(setNodes) != mapMaxCoalNumsAtSTBrSibGTBrs.end(), "Fail to find" );
    bool res = entryToClean.GetInfoNC().CleanUnusedSTBrs( mapMaxCoalNumsAtSTBrSibGTBrs[setNodes] );
    
//cout << "AFTER cleanup: entry: ";
//entryToClean.Dump();
    return res;
}

// get num of gene alleles under a ST node
int FGTPFSProbHelper :: GetNumGeneAllelesUnderSTBr(int stBr)
{
    //
    set<int> setAlleles;
    helperOfFGTPFSProbHelper.GetGeneAllelesForSTNode(stBr, setAlleles);
    return setAlleles.size();
}

void FGTPFSProbHelper :: GetRootChildren(set<TreeNode *> &setRootChildren) const
{
    //
    setRootChildren.clear();
    TreeNode *pGTRoot = GetGTRoot();
    pGTRoot->GetAllChildren( setRootChildren );
}

double FGTPFSProbHelper :: GetSTBranchLen(int sn) const
{
    if( sn != GetSTRoot() )
    {
        return treeSpecies.GetEdgeLen(sn);
    }
    else
    {
        // for root branch, infinite
        return -1.0*HAP_MAX_INT;
    }
}

//////////////////////////////////////////////////////////////////////////////////
// Fixed species tree prob configuration. Spcify the number of
// gene lineages on top of each species tree branch (the topmost is always 1)


FGTPFSAncesCfg :: FGTPFSAncesCfg()
{
    //
}

FGTPFSAncesCfg :: FGTPFSAncesCfg(const FGTPFSAncesCfg &rhs) : mapNumCoalsOnSTBranch(rhs.mapNumCoalsOnSTBranch)
{
    //
}

bool FGTPFSAncesCfg :: operator<(const FGTPFSAncesCfg &rhs) const
{
    return this->mapNumCoalsOnSTBranch < rhs.mapNumCoalsOnSTBranch;
}

// add an entry
void FGTPFSAncesCfg :: AddLinEntry(int stBr, int numGTLinsTop)
{
    //
    mapNumCoalsOnSTBranch.insert( map<int,int> :: value_type(stBr, numGTLinsTop) );
}

// calculate the probability of this AC
double FGTPFSAncesCfg :: CalcProb( FGTPFSProbHelper &helper ) const
{
//cout << "CalcProb: ";
//Dump();
    double coeff = CalcCoalCoeff(helper);
//cout << "Coefficient: " << coeff << endl;
    double probBr = CalcBranchProb(helper);
//cout << "Branch prob: " << probBr << endl;
    double dbVal = CalcdbVal(helper);
//cout << "dbval: " << dbVal << endl;

    return probBr*dbVal*coeff;
}

// calculate the probability of this AC
double FGTPFSAncesCfg :: CalcLogProb( FGTPFSProbHelper &helper ) const
{
    //cout << "CalcProb: ";
    //Dump();
    double coeff = CalcCoalCoeff(helper);
//cout << "Coefficient: " << coeff << endl;
    double probBr = CalcBranchProb(helper);
//cout << "Branch prob: " << probBr << endl;
    double logdbVal = CalcLogdbVal(helper);
//cout << "logdbval: " << logdbVal << endl;
    
    return log(probBr)+logdbVal+log(coeff);
}

// calculate the coalescent coefficient
double FGTPFSAncesCfg :: CalcCoalCoeff( FGTPFSProbHelper &helper ) const
{
    set<TreeNode *> setRootChildren;
    helper.GetRootChildren(setRootChildren);
    FGTPFSAncesCfgCoalInfo coalInfo;
    ConsCoalInfo( helper, coalInfo );
    
    FGTPFSCoeffCompEntry entryIn( setRootChildren, coalInfo );
    helper.CleanUnusedSTBrs(entryIn);
    
    double res = helper.RetriveCoeff( entryIn );
//cout << "Coefficient for coalescnet: " << res << ", For coal entry: ";
//entryIn.Dump();
    return res;
}

double FGTPFSAncesCfg :: CalcBranchProb( FGTPFSProbHelper &helper) const
{
    // calc prob of coalescent prob given the branch lineage configuration
    // consider all ST branch
    double res = 1.0;
    for( map<int,int> :: const_iterator it = mapNumCoalsOnSTBranch.begin(); it != mapNumCoalsOnSTBranch.end(); ++it )
    {
        int snId = it->first;
        int ngl = it->second;
        int numBottomLins = GetNumBottomGTLins( snId, helper );
        YW_ASSERT_INFO( numBottomLins >= ngl, "Cannot be smaller" );
        double brLen = helper.GetSTBranchLen( snId );
        double probStep = 1.0;
        if( snId != helper.GetSTRoot() )
        {
            probStep = helper.GetGTSTOrigHelper().CalcCoalProbBranch( numBottomLins, ngl, brLen );
        }
        res *= probStep;
    }
    return res;
}

double FGTPFSAncesCfg :: CalcdbVal(FGTPFSProbHelper &helper) const
{
    
    // YW: 08/07/2015
    // to avoid numerical overflow, do the factorial
    //
    double res = 1.0;
    for( map<int,int> :: const_iterator it = mapNumCoalsOnSTBranch.begin(); it != mapNumCoalsOnSTBranch.end(); ++it )
    {
        int snId = it->first;
        int ngl = it->second;
        int numBottomLins = GetNumBottomGTLins( snId, helper );
        YW_ASSERT_INFO( numBottomLins >= ngl, "Cannot be smaller" );
        int numCoals = numBottomLins-ngl;
        
//cout << "CalcdbVal: snId: " << snId << ", numBottomLins: " << numBottomLins << ", numCoals: " << numCoals << endl;
        // db term
        double resStepdb = 1.0;
        //resStepdb = helper.GetGTSTOrigHelper().CalcdbVal( numBottomLins, numCoals );
        //// factorial term
        //double resFac = CalcProductBetween( 1, numCoals );
//cout << "resStepDb = " << resStepdb << ", resFac: " << resFac << endl;
        //res *= resFac/resStepdb;
        resStepdb = helper.GetGTSTOrigHelper().CalcProddbValAndCoalFac( numBottomLins, numCoals );
        res*= resStepdb;
    }
    
    return res;
}


double FGTPFSAncesCfg :: CalcLogdbVal(FGTPFSProbHelper &helper) const
{
    
    // YW: 08/07/2015
    // to avoid numerical overflow, do the factorial; return the log-value of the term
    //
    double res = 0.0;
    for( map<int,int> :: const_iterator it = mapNumCoalsOnSTBranch.begin(); it != mapNumCoalsOnSTBranch.end(); ++it )
    {
        int snId = it->first;
        int ngl = it->second;
        int numBottomLins = GetNumBottomGTLins( snId, helper );
        YW_ASSERT_INFO( numBottomLins >= ngl, "Cannot be smaller" );
        int numCoals = numBottomLins-ngl;
        
        //cout << "CalcdbVal: snId: " << snId << ", numBottomLins: " << numBottomLins << ", numCoals: " << numCoals << endl;
        // db term
        double resStepdb = 1.0;
        //resStepdb = helper.GetGTSTOrigHelper().CalcdbVal( numBottomLins, numCoals );
        //// factorial term
        //double resFac = CalcProductBetween( 1, numCoals );
        //cout << "resStepDb = " << resStepdb << ", resFac: " << resFac << endl;
        //res *= resFac/resStepdb;
        resStepdb = helper.GetGTSTOrigHelper().CalcLogProddbValAndCoalFac( numBottomLins, numCoals );
        res += resStepdb;
    }
    
    return res;
}


int FGTPFSAncesCfg :: GetNumBottomGTLins( int snId, FGTPFSProbHelper &helper) const
{
    int numBottomLins = -1;
    if( helper.IsSTNodeLeaf(snId) == false )
    {
        //
        numBottomLins = GetNumGTLinsDesc(snId, helper);
    }
    else
    {
        // if it is leaf, then
        numBottomLins = helper.GetNumGeneAllelesUnderSTBr(snId);
    }
    return numBottomLins;
}

// convert to coal event style
void FGTPFSAncesCfg :: ConsCoalInfo( FGTPFSProbHelper &helper, FGTPFSAncesCfgCoalInfo &coalInfo) const
{
//cout << "ConsCoalInfo: ";
//Dump();
    //
    for( map<int,int> :: const_iterator it = mapNumCoalsOnSTBranch.begin(); it != mapNumCoalsOnSTBranch.end(); ++it )
    {
        int snId = it->first;
        int ngl = it->second;
        int numBottomLins = -1;
        if( helper.IsSTNodeLeaf(snId) == false )
        {
            //
            numBottomLins = GetNumGTLinsDesc(snId, helper);
        }
        else
        {
            // if it is leaf, then
            numBottomLins = helper.GetNumGeneAllelesUnderSTBr(snId);
        }
        YW_ASSERT_INFO( numBottomLins >= ngl, "Cannot be smaller" );
        int numCoals = numBottomLins - ngl;
        coalInfo.SetCoalNumAt( snId, numCoals );
    }
    
#if 0
cout << "Constructed coalInfo: ";
coalInfo.Dump();
cout << "This is for the AC: ";
Dump();
#endif
}

// get num of GT lineages under a ST branch that belong to two descendents
// this gives a upper bound on the number of allowed lineages
int FGTPFSAncesCfg :: GetNumGTLinsDesc( int stBr, FGTPFSProbHelper &helper ) const
{
    FGTPFSAncesCfg &pthis = const_cast<FGTPFSAncesCfg &>(*this);
    int res = 0;
    int snLD = helper.GetSTLeftDesc( stBr );
    int snRD = helper.GetSTRightDesc( stBr );
    if( snLD >= 0 )
    {
        YW_ASSERT_INFO(mapNumCoalsOnSTBranch.find(snLD) != mapNumCoalsOnSTBranch.end(), "Fail to find11");
        res += pthis.mapNumCoalsOnSTBranch[ snLD ];
    }
    if( snRD >= 0 )
    {
        YW_ASSERT_INFO(mapNumCoalsOnSTBranch.find(snRD) != mapNumCoalsOnSTBranch.end(), "Fail to find12");
        res += pthis.mapNumCoalsOnSTBranch[ snRD ];
    }
    return res;
}

void FGTPFSAncesCfg :: Dump() const
{
    //
    cout << "AC: ";
    for( map<int,int> :: const_iterator it = mapNumCoalsOnSTBranch.begin(); it != mapNumCoalsOnSTBranch.end(); ++it )
    {
        cout << "[" << it->first << "," << it->second << "] ";
    }
    cout << endl;
}

//////////////////////////////////////////////////////////////////////////////////
// Fixed species tree prob


FastGeneTreeProbFixedSpecies :: FastGeneTreeProbFixedSpecies( MarginalTree &treeSpeciesIn, PhylogenyTreeBasic &treeGeneIn ) : treeSpecies(treeSpeciesIn), treeGene(treeGeneIn), helperGTST( treeSpeciesIn, treeGeneIn )
{
    if( IsVerbose() == true )
    {
        cout << "************** Pre-constructed helper: \n";
        helperGTST.Dump();
    }
}

double FastGeneTreeProbFixedSpecies :: CalcProb()
{
    StartCalcProbCall();
    
//cout << "FastGeneTreeProbFixedSpecies: calcprob.\n";
    set< FGTPFSAncesCfg > setAllACs;
    CollectAllACs( setAllACs );
    
    // for each AC, calc prob; then sum it up which gives the overall prob
    double res = 0.0;
    for( set<FGTPFSAncesCfg> :: iterator it = setAllACs.begin(); it != setAllACs.end(); ++it )
    {
        double probStep = it->CalcProb(helperGTST);
cout << "probStep: " << probStep << " for AC: ";
it->Dump();
        res += probStep;
    }
    
    DoneCalcProbCall();
    
    return res;
}

double FastGeneTreeProbFixedSpecies :: CalcLogProb()
{
    StartCalcProbCall();
    
//cout << "FastGeneTreeProbFixedSpecies: calcLogprob.\n";
//cout << "Species tree: ";
//treeSpecies.Dump();
    set< FGTPFSAncesCfg > setAllACs;
    CollectAllACs( setAllACs );
    
    if( IsVerbose() == true )
    {
        cout << "Total number of compact ACs: " << setAllACs.size() << endl;
    }
    
    // for each AC, calc prob; then sum it up which gives the overall prob
    double res = -1.0*HAP_MAX_INT;      // negative max
    for( set<FGTPFSAncesCfg> :: iterator it = setAllACs.begin(); it != setAllACs.end(); ++it )
    {
        double probStep = it->CalcLogProb(helperGTST);
//cout << "log-probStep: " << probStep << " for AC: ";
//it->Dump();
        //res += probStep;
        res = GetLogSumOfTwo(res, probStep);
    }
    
// output profile info
//cout << "**************** Total number of useless info: " << numUselessInfo << endl;
//cout << "**************** Total number of useless entries: " << numUselessEntry << endl;
//cout << "Prob of this tree: " << res << endl;
    
    DoneCalcProbCall();
    
    return res;
}

// attempt to change a branch to a new length, and update the prob. Since we may need to recover the original
// unchanged probs, we just save those changed one (i.e. keep a copy of what was there before)
double FastGeneTreeProbFixedSpecies :: TestNewBranchLenAt(int branch, double lenNew, map<int,set< LineageConfig,LTLinCfg > > &origLinCfgs, bool fSetBrlen )
{
    StartReCalcProbCall();
    
//cout << "Testing: branch: " << branch << " to new length: " << lenNew << endl;
    // simply set the ebranch length
    double brOld = GetSTBranchLen( branch );
    if( fSetBrlen == true )
    {
        SetSTBranchLen(branch, lenNew);
    }
    double res = CalcLogProb();
    
    // set the old branch length back
    if( fSetBrlen == true )
    {
        SetSTBranchLen( branch, brOld );
    }
    DoneReCalcProbCall();
    
//cout << "Species tree after testing: ";
//treeSpecies.Dump();
    
    return res;
}

void FastGeneTreeProbFixedSpecies :: SetLinCfgs(map<int,set< LineageConfig,LTLinCfg > > &linCfgsToSet)
{
    // do nothing
}


// collect all ACs
void FastGeneTreeProbFixedSpecies ::  CollectAllACs( set< FGTPFSAncesCfg > &setAllACs )
{
    //
    map<int, pair<int,int> > mapGTBoundsOnSTBr;
    CollectBoundsGTLinsForSTBrs( mapGTBoundsOnSTBr );
    
    setAllACs.clear();
    for( map<int, pair<int,int> > :: iterator it = mapGTBoundsOnSTBr.begin(); it != mapGTBoundsOnSTBr.end(); ++it  )
    {
        //
        int stBrCur = it->first;
        int lbGLN = it->second.first;
        int ubGLN = it->second.second;
        
//cout << "Processing stBrCur: " << stBrCur << ", lbGLN: " << lbGLN << ", ubGLN: " << ubGLN << endl;
        set<FGTPFSAncesCfg> setAllACsStep = setAllACs;
        if( setAllACs.size() == 0 )
        {
            // no previous, then add a dummy one
            FGTPFSAncesCfg cfgInit;
            setAllACsStep.insert( cfgInit );
        }
        setAllACs.clear();
        // check each active cfg to process
        for( set<FGTPFSAncesCfg> :: iterator it2 = setAllACsStep.begin(); it2 != setAllACsStep.end(); ++it2 )
        {
            // get all GT lins in this particular cfg that are under the current lin
            int numGTDesc = it2->GetNumGTLinsDesc( stBrCur, helperGTST );
            if( numGTDesc == 0 )
            {
                // this part has not been properly init yet
                numGTDesc = ubGLN;
            }
            // if it is the root, then use 1
            if( stBrCur == helperGTST.GetSTRoot() )
            {
                numGTDesc = 1;
            }
//cout << "numGTDesc: " << numGTDesc  << " when treating cfg: ";
//it2->Dump();
            YW_ASSERT_INFO( (numGTDesc <= ubGLN && numGTDesc >= lbGLN) || stBrCur == helperGTST.GetSTRoot(), "Range error" );
            
            // is this num of lins allowed???
            for( int ii=lbGLN; ii<=numGTDesc; ++ii )
            {
                FGTPFSAncesCfg cfgNew( *it2 );
                cfgNew.AddLinEntry( stBrCur, ii );
                setAllACs.insert(cfgNew);
            }
        }

    }
//#if 0
    if( IsVerbose() == true )
    {
        cout << "******** List of all possible ACs: \n";
        for( set<FGTPFSAncesCfg> :: iterator it2 = setAllACs.begin(); it2 != setAllACs.end(); ++it2 )
        {
            it2->Dump();
        }
    }
//#endif
}

// collect UBs/LBs on gene lineages for each ST branch (top)
void FastGeneTreeProbFixedSpecies :: CollectBoundsGTLinsForSTBrs( map<int, pair<int,int> > &mapGTBoundsOnSTBr )
{
    // first retrieve the overall possible coalescent events (assuming entire gene tree can coalesce)
    map<int,int> mapMaxCoalNumsAtSTBrAtGTRoot;
    set<TreeNode *> gtSibsAtRoot;
    TreeNode *pGTRoot = helperGTST.GetGTRoot();
    pGTRoot->GetAllChildren( gtSibsAtRoot );
    helperGTST.GetAllCoalBoundsOnSTBrsForGTSTs( gtSibsAtRoot, mapMaxCoalNumsAtSTBrAtGTRoot );
    
    // consider each species tree branches
    for(int sb=0; sb<=helperGTST.GetSTRoot(); ++sb )
    {
        //
        int numGTAlleles = helperGTST.GetNumGeneAllelesUnderSTBr( sb );
        //YW_ASSERT_INFO( mapMaxCoalNumsAtSTBrAtGTRoot.find( sb ) != mapMaxCoalNumsAtSTBrAtGTRoot.end(), "Fail to find the ST branch" );
        int numMaxCoal = 0;
        if( mapMaxCoalNumsAtSTBrAtGTRoot.find( sb ) != mapMaxCoalNumsAtSTBrAtGTRoot.end() )
        {
            // if no record, then cannot coalesce
            numMaxCoal = mapMaxCoalNumsAtSTBrAtGTRoot[ sb ];
        }
        YW_ASSERT_INFO( numMaxCoal < numGTAlleles, "Make no sense" );
        pair<int,int> bounds( numGTAlleles-numMaxCoal, numGTAlleles );
        
        // if it is the root, then must be (1,1)
        if( sb == helperGTST.GetSTRoot() )
        {
            //
            bounds.first = 1;
            bounds.second = 1;
        }
        
        mapGTBoundsOnSTBr.insert( map<int, pair<int,int> > :: value_type( sb, bounds ) );
//cout << "--For ST branch " << sb << ", bounds = [" << bounds.first << "," << bounds.second << "]\n";
    }
}


