//
//  ProbSeqOnTrees.cpp
//  
//
//  Created by Yufeng Wu on 5/7/15.
//
//

#include "ProbSeqOnTrees.h"
#include "Utils3.h"
#include <cmath>
#include "Utils4.h"

//*****************************************************************************
// Global: list of alignment input

vector<MSAMatrix> listInputSeqAlignments;        // a list of sequence alignments
const double DEF_MUT_PARAM = 0.0001;

//*****************************************************************************
// Prob of sequences on gene tree

ProbSeqOnTrees :: ProbSeqOnTrees( PhylogenyTreeBasic &geneTreeIn, MSAMatrix &msaIn ) : geneTree(geneTreeIn), msa(msaIn), mutParam(DEF_MUT_PARAM)
{
    Init();
}

double ProbSeqOnTrees :: CalcMutProbOfBranch( double brLen, TreeNode *nodeUnderBranch ) const
{
//cout << "CalcMutProbOfBranch: length=" << brLen << ", node: ";
//nodeUnderBranch->Dump();
    //
    YW_ASSERT_INFO( mapTreeBranchStateChanges.find(nodeUnderBranch) != mapTreeBranchStateChanges.end(), "Fail to find the branch" );
    ProbSeqOnTrees *pthis = const_cast<ProbSeqOnTrees *>(this);
    int numChanges = pthis->mapTreeBranchStateChanges[nodeUnderBranch];
//cout << ", numchanges: " << numChanges;
    // use Poisson to calculate mutation prob
    double mutProb = brLen*GetMutParam();
//cout <<", GetMutParam()=" << GetMutParam()  << ",mutProb: " << mutProb << endl;
    double res = exp(-1.0*mutProb);
//cout << "exp part: " << res << endl;
    for(int i=1; i<=numChanges; ++i)
    {
        res = res/i;
        res *= mutProb;
    }
//cout << ", mut prob=" << res << endl;
    return res;
}

void ProbSeqOnTrees :: Init()
{
//cout << "ProbSeqOnTrees :: Init()\n";
    // first collect all leave' label
    PhylogenyTreeIterator itorGT(geneTree);
    itorGT.Init();
    while(itorGT.IsDone() == false )
    {
        TreeNode *pn = itorGT.GetCurrNode();
        // store label for leaf
        if( pn->IsLeaf() == true )
        {
            string strUserLbl = pn->GetUserLabel();
            mapLeafLabelGT.insert( map<TreeNode *, string> :: value_type(pn, strUserLbl) );
//cout << "Find one leaf: label: " << strUserLbl << " ";
//pn->Dump();
        }
        itorGT.Next();
    }
    
    //
    for(int s=0; s<msa.GetNumChars(); ++s)
    {
        InitProcMSASite(s);
    }
}

string ProbSeqOnTrees :: GetUserLabel( TreeNode *pn ) const
{
    //
    YW_ASSERT_INFO( mapLeafLabelGT.find(pn) != mapLeafLabelGT.end(), "Fail to find" );
    ProbSeqOnTrees *pthis = const_cast<ProbSeqOnTrees *>(this);
    return pthis->mapLeafLabelGT[pn];
}

void ProbSeqOnTrees :: InitProcMSASite(int site)
{
//cout << "InitProcMSASite: site: " << site << endl;
    // use this simple strategy: for each node, take majoroty
    // char of all its leaves
    map<TreeNode *, char> mapNodeChar;
    
    // init leaves
    vector< TreeNode *> listLeafNodes;
    geneTree.GetAllLeafNodes( listLeafNodes );
    for(int i=0; i<(int)listLeafNodes.size(); ++i)
    {
        string strLbl = GetUserLabel( listLeafNodes[i] );
        int seqIndex = msa.GetSeqIndex( strLbl );
        char base = msa.GetCharAt( seqIndex, site );
//cout << "Leaf: label " << strLbl << ", seqIndex: " << seqIndex << ", base: " << base << endl;
        mapNodeChar.insert( map<TreeNode*,char> :: value_type(listLeafNodes[i], base) );
    }
    
    // proce all internal nodes of tree, get majority char
    PhylogenyTreeIterator itorGT(geneTree);
    itorGT.Init();
    while(itorGT.IsDone() == false )
    {
        TreeNode *pn = itorGT.GetCurrNode();
        // process all internal nodes
        if( pn->IsLeaf() == false )
        {
            multiset<char> setBases;
            for(int i=0; i<pn->GetChildrenNum(); ++i)
            {
                TreeNode *pc = pn->GetChild(i);
                YW_ASSERT_INFO( mapNodeChar.find(pc) != mapNodeChar.end(), "Fail to find" );
                char cc = mapNodeChar[pc];
                setBases.insert(cc);
            }
            char cm = FindExtremeFreqElem(setBases, false);
            mapNodeChar.insert( map<TreeNode*,char>::value_type(pn, cm) );
//cout <<"processing internal node: ";
//pn->Dump();
//cout << "most frequent base: " << cm << endl;

            
            // now check how many we should inc the mutation count here
            for(int i=0; i<pn->GetChildrenNum(); ++i)
            {
                TreeNode *pc = pn->GetChild(i);
                char cc = mapNodeChar[pc];
                if(mapTreeBranchStateChanges.find(pc) == mapTreeBranchStateChanges.end() )
                {
                    //
                    mapTreeBranchStateChanges.insert( map<TreeNode*,int> :: value_type(pc,0) );
                }
                if( cc != cm)
                {
//cout << "--Adding mutation count for brnahc ending: ";
//pc->Dump();
//cout << endl;
                    ++mapTreeBranchStateChanges[pc];
                }
            }
        }
        itorGT.Next();
    }
}