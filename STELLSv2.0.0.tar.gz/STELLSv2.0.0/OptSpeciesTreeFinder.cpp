#include "OptSpeciesTreeFinder.h"
#include "HeuSpeciesTreeFinder.h"
#include "DeepCoalescence.h"

// test new code for storing less cfgs (hopefully) by only considering cfgs at extended level)
//#define CODE_NEW_STORE_ANC_CFG  1

const int DEFAULT_NUM_GRID_SIZE = 10;
const double DEFAULT_SZ_GRID_STEP = 0.1;

///////////////////////////////////////////////////////////////////////////////////
// this controls how many cfgs one needs to keep at each grid point of each subset
// by doing this, we limit our search to a small subset of the search space (but hopefully still not too bad)

static int numMaxKeptCfgs = HAP_MAX_INT;

void SetMaxKeptCfgsLimit(int limit)
{
	numMaxKeptCfgs = limit;
}

static int GetMaxKeptCfgsLimit()
{
	return numMaxKeptCfgs;
}


///////////////////////////////////////////////////////////////////////////////////
// utility
bool AreDoubleIdentical(double v1, double v2)
{
	const double SMALL_RATIO = 1.0e-10;
	double v1p = v1 + SMALL_RATIO*v1;
	double v1m = v1 - SMALL_RATIO*v1;
	if( v1p >= v2 && v1m <= v2 )
	{
		return true;
	}
	else
	{
		return false;
	}
}


///////////////////////////////////////////////////////////////////////////////////
// this may be a good method to add to Util

//void SplitToSets( const vector<int> & vecItemsWhole, const vector<int> &vecItemsSelected, set<int> &ssInList, set<int> &ssNotInList )
//{
//	// we assume no duplicate in the items
//	// not a very efficient implementation
//	PopulateSetByVec( ssInList, vecItemsSelected );
//	PopulateSetByVec( ssNotInList, vecItemsWhole );
//	SubtractSets( ssNotInList, ssInList );
//	YW_ASSERT_INFO( ssInList.size() == vecItemsSelected.size(), "Size mismatch in SplitToSets1" );
//	YW_ASSERT_INFO( ssInList.size() + ssNotInList.size() == vecItemsWhole.size(), "Size mismatch in SplitToSets2" );
//}


///////////////////////////////////////////////////////////////////////////////////
STFinderConfigStore :: STFinderConfigStore() : gstHelperPtr(NULL), numSkippedCfgs(0), numBeteanCfgs(0), szGridStep(0.1)
{
}

STFinderConfigStore :: ~STFinderConfigStore()
{
}


// add a record of LinCfg: for the purpose of computing the probablity, need to know which
// LinCfg it derives from. For leaves, we also support a plain version: with no probility
void STFinderConfigStore :: AddLinCfg( const set<int>& staxa, int grid, vector<set<LineageConfig,LTLinCfg> > &lcsNew )
{
	// before adding, setup a id for the configs
//	int sid = CalcSNodeId(staxa);
//cout << "sid = " << sid << endl;
	//for(int i=0; i<(int)lcsNew.size(); ++i)
	//{
	//	for( set<LineageConfig> :: iterator it = lcsNew[i].begin(); it != lcsNew[i].end(); ++it )
	//	{
	//		it->SetNodeId(sid);
	//	}
	//}

	// first check if staxa is new or not
	if( mapConfigForNodes.find( staxa) == mapConfigForNodes.end() )
	{
		LINCfgsAtGrid emptyLinCfgs;
		mapConfigForNodes.insert( map< set<int>, LINCfgsAtGrid > ::value_type( staxa,  emptyLinCfgs) );
	}
	YW_ASSERT_INFO( mapConfigForNodes.find( staxa) != mapConfigForNodes.end(), "Can not be like this" );

	// now is the grid unique
	if( mapConfigForNodes[staxa].find( grid ) ==  mapConfigForNodes[staxa].end()  )
	{
		// add it again
		vector<vector<  set<LineageConfig,LTLinCfg>  >  > emptyLCs2;
		mapConfigForNodes[staxa].insert(LINCfgsAtGrid :: value_type(grid, emptyLCs2)  );
	}
	YW_ASSERT_INFO( mapConfigForNodes[staxa].find( grid ) !=  mapConfigForNodes[staxa].end(), "Can not be here" );

	// finally add it if it is not already in
	//if( mapConfigForNodes[staxa][grid].find( lcsNew ) == mapConfigForNodes[staxa][grid].end() )
	//{
	//	// add it
	//	mapConfigForNodes[staxa][grid].push_back(lcsNew);
	//}
	//else
	//{
	AppendLinCfgsTo(mapConfigForNodes[staxa][grid], lcsNew );
		// only keep the one with higher prob. To do this, first erase the old one, and add the one with the higher prob
		//LINCfgsAtGrid :: iterator itt = mapConfigForNodes[staxa][grid].find( lcsNew );
		//if( it->GetProb() < lcNew.GetProb() )
		//{
		//	// erase the old one
		//	mapConfigForNodes[staxa][grid].erase( it );
		//	mapConfigForNodes[staxa][grid].insert( lcsNew );
		//}
	//}
}

void STFinderConfigStore :: AppendLinCfgsTo(  vector<vector<  set<LineageConfig,LTLinCfg> > > &listSLinCfgs, const vector<set<LineageConfig,LTLinCfg> > &sLinNew ) const
{
#if 0		// can not do this, grow too quickly
	// skip checking for now
	listSLinCfgs.push_back( sLinNew );
#endif

	const_cast<STFinderConfigStore *>(this)->IncNumExamedCfgs();

//#if 0
	//skip if any
	vector< vector<  set<LineageConfig,LTLinCfg> > >  vecLCUnbeaten;
	bool fPoor = false;
	for( int i=0; i<(int)listSLinCfgs.size(); ++i )
	{
		if( IsLinCfgsBetter(sLinNew, listSLinCfgs[i] ) == false )
		{
			vecLCUnbeaten.push_back( listSLinCfgs[i] );
		}
		else
		{
			const_cast<STFinderConfigStore *>(this)->IncNumBeaten();
//cout << "***this cfg is beaten by the new cfg\n";
		}
		if( IsLinCfgsBetter( listSLinCfgs[i], sLinNew ) ==  true )
		{
			fPoor = true;
			break;
		}
	}
	// do nothing if this is a poor choice
	if( fPoor == true )
	{
		const_cast<STFinderConfigStore *>(this)->IncNumSkipped();
//cout << "---this cfg is skipped\n";
		return;
	}
	// need to add it
	vecLCUnbeaten.push_back( sLinNew );

	// do we need to shrink the size of the list
	PruneLessLikeliCfgs(vecLCUnbeaten);


	// update list
	listSLinCfgs = vecLCUnbeaten;
//#endif
}

void STFinderConfigStore :: PruneLessLikeliCfgs(vector< vector<  set<LineageConfig,LTLinCfg> > >  &listCfgsTest) const
{
	// we only start pruning when the size is really out of control (i.e. twice as much as our threshold
	if( (int)listCfgsTest.size() <= 2*GetMaxKeptCfgsLimit() )
	{
		// 
		return;
	}
//cout << "listCfgsTest = \n";
	// collect root cfgs for each tree 
	vector<LineageConfig> listRootCfgs;
	for( int tr=0; tr< gstHelperPtr->GetNumGTrees(); ++tr )
	{
		// 
		LineageConfig rcfg;
		gstHelperPtr->FormRootCfgAt(tr, rcfg);
		listRootCfgs.push_back( rcfg );
	}
	// calculate the prob in a list
	vector<double> probList(listCfgsTest.size() );
	for( int i=0; i<(int)listCfgsTest.size(); ++i )
	{
//cout << "Cfg " << i << endl;
		YW_ASSERT_INFO( listCfgsTest[i].size() == listRootCfgs.size(), "Tree size wrong"  );
		// for each tree, get loglikeli
		double logprob = 0.0;
		for(int tr=0; tr<(int)listCfgsTest[i].size(); ++tr)
		{
//cout << "**Tree " << tr << endl;
			// add up the prob by having the
			double probStep = 0.0;
			for(  set<LineageConfig,LTLinCfg>  :: iterator itt = listCfgsTest[i][tr].begin(); itt != listCfgsTest[i][tr].end(); ++itt )
			{
//itt->Dump();
				probStep += itt->GetProb() * gstHelperPtr->CalcCoalCoeffForTwoCfg(tr, *itt, listRootCfgs[tr] );
			}
			logprob += log(probStep);
		}
		probList[i] = logprob;
	}
	YW_ASSERT_INFO( listCfgsTest.size() == probList.size(), "Fatal error" );
	// find the median and prune it based on the value
	double probMed = FindMedian( probList );
	vector< vector<  set<LineageConfig,LTLinCfg> > >  listNew;
	for( int i=0; i<(int)listCfgsTest.size(); ++i )
	{
		// add only when the prob is high and there is still room
		if( probList[i] >= probMed && (int)listNew.size() < GetMaxKeptCfgsLimit()  )
		{
			listNew.push_back( listCfgsTest[i] );
		}
	}
//cout << "Median prob = " << probMed << ": ";
//DumpDoubleVec( probList );
	// update return value
	listCfgsTest = listNew;
	YW_ASSERT_INFO( (int)listCfgsTest.size() <= GetMaxKeptCfgsLimit(), "Prune fail to reduce the size"  );
}


#if 0 
void STFinderConfigStore :: AddLinCfgSrc( const set<int> &srows, int grid, const set<int> &srowsLeft, 
										  int gridLeft, int gridRight, vector<set<LineageConfig,LTLinCfg> > &lcsStep )
{
	// first add it to list
	AddLinCfg(srows, grid, lcsStep);

	// then remember the 
	YW_ASSERT_INFO( mapConfigForNodes.find(srows) != mapConfigForNodes.end()
		&& mapConfigForNodes[srows].find( grid] != mapConfigForNodes[srows].end(), "Fail");
	// find the cfgs in the map
	vector<  set<LineageConfig,LTLinCfg> > *ptrCfgs = NULL;
	for(  vector<vector<  set<LineageConfig,LTLinCfg> > >  :: iterator it = mapConfigForNodes[srows][grid].begin(); 
		it != mapConfigForNodes[srows][grid].end(); ++it )
	{
		// 
		if( *it == lcsStep )
		{
			YW_ASSERT_INFO( &(*it) == &lcsStep, "Pointer mismatch" );
			ptrCfgs = &(*it);
			break;
		}
	}
	YW_ASSERT_INFO( ptrCfgs != NULL, "Fail" );
	// ???
}
#endif

bool STFinderConfigStore :: IsLinCfgsBetter(const vector<set<LineageConfig,LTLinCfg> > &sLinNew1, const vector<set<LineageConfig,LTLinCfg> > &sLinNew2) const
{
	// only LinCfgs with identical set of configs can be compared
	YW_ASSERT_INFO( sLinNew1.size() == sLinNew2.size(), "can not be compared1" );
	// linnew1 is better if its prob if larger than corresponding item in lin2
	for(int i=0; i<(int)sLinNew1.size(); ++i)
	{
		if( IsLinCfgsBetter( sLinNew1[i], sLinNew2[i] ) == false )
		{
			return false;
		}
	}
	return true;
}

bool STFinderConfigStore :: IsLinCfgsBetter(const set<LineageConfig,LTLinCfg> &cfgBetter, const set<LineageConfig,LTLinCfg> &cfgWorse) const
{
	// only LinCfgs with identical set of configs can be compared
	//YW_ASSERT_INFO( sLinNew1 == sLinNew2, "can not be compared" );
#if 0
	if( sLinNew1 == sLinNew2 )
	{
		// linnew1 is better if its prob if larger than corresponding item in lin2
		for(  set< LineageConfig,LTLinCfg > :: iterator itt1  = sLinNew1.begin(), itt2 = sLinNew2.begin(); 
			itt1 !=sLinNew1.end() && itt2 != sLinNew2.end(); ++itt1, ++itt2 )
		{
			if( itt1->GetProb() < itt2->GetProb()  )
			{
				return false;
			}
		}
		return true;
	}
	else
	{
		// can not compare, return false
		return false;
	}
#endif

	// decide whether the first cfg is better than the second one
	//YW_ASSERT_INFO( cfgBetter.size() == cfgWorse.size(), "Size mismatch" );
	// we check each state (set of lineages), if the better contains all the states in each of the trees
	//for(int tr=0; tr<(int)cfgBetter.size(); ++tr)
	//{
		// 
	for( set<LineageConfig,LTLinCfg> :: iterator it = cfgWorse.begin(); it != cfgWorse.end(); ++it  )
	{
		// if cfgbetter can not offer the same as the worse one, then can not say it is better
		if(cfgBetter.find(*it) == cfgBetter.end()  )
		{
			return false;
		}
		// if cfgworse's prob is higher than cfgbetter's prob, can not say it
		if( it->GetProb() > (cfgBetter.find(*it))->GetProb()  )
		{
			return false;
		}
	}
	//}
	return true;
}


const int MAX_SPECIES_ALLOWED = 30;

// impl functions
int STFinderConfigStore :: CalcSNodeId( const set<int> &staxa )
{
	// return an stree id
	// make sure no iem is greater than MAX_SPECIES_ALLOWD
	for( set<int> :: iterator it = staxa.begin(); it != staxa.end(); ++it)
	{
		YW_ASSERT_INFO( (*it) <= MAX_SPECIES_ALLOWED, "Id out of range"  );
	}
	return ConvIntSetToPosition( staxa );

}

int STFinderConfigStore :: GetNumLinCfgsAt( const set<int> &nodeId) 
{
	int res = 0;
	if( mapConfigForNodes.find( nodeId) == mapConfigForNodes.end() )
	{
		return res;
	}
	for( LINCfgsAtGrid :: iterator it = mapConfigForNodes[nodeId].begin(); it != mapConfigForNodes[nodeId].end(); ++it )
	{
		int resStep = 0;
		//for( int i=0; i<(int)(it->second).size(); ++i )
		//{
			//for(int j=0; j<(int)(it->second)[i].size(); ++j)
			//{
		resStep = (it->second).size();
			//}
		//}
		res += resStep;
//cout << "At grid " << it->first << ", size of configs = " << resStep << endl;;
	}
	return res;
}

int STFinderConfigStore :: GetNumLinCfgsAtGrid( const set<int> &nodeId, int grid) 
{
	int res = 0;
	if( mapConfigForNodes.find( nodeId) == mapConfigForNodes.end() )
	{
		return res;
	}
	if( mapConfigForNodes[nodeId].find( grid ) == mapConfigForNodes[nodeId].end() )
	{
		return res;
	}
	//for( LINCfgsAtGrid :: iterator it = mapConfigForNodes[nodeId].begin(); it != mapConfigForNodes[nodeId].end(); ++it )
	for( int ii = 0; ii<(int) mapConfigForNodes[nodeId][grid].size(); ++ii )
	{
		int resStep = 0;
		//for( int i=0; i<(int)(it->second).size(); ++i )
		//{
			//for(int j=0; j<(int)(it->second)[i].size(); ++j)
			//{
		for( int jj = 0; jj<(int) mapConfigForNodes[nodeId][grid][ii].size(); ++jj )
		{
			resStep = mapConfigForNodes[nodeId][grid][ii][jj].size();
		}
			//}
		//}
		res += resStep;
//cout << "At grid " << it->first << ", size of configs = " << resStep << endl;;
	}
	return res;
}

void STFinderConfigStore :: DumpCfgsAt( const set<int> &nodeId) 
{
	if( mapConfigForNodes.find( nodeId) == mapConfigForNodes.end() )
	{
		return;
	}
	for( LINCfgsAtGrid :: iterator it = mapConfigForNodes[nodeId].begin(); it != mapConfigForNodes[nodeId].end(); ++it )
	{
		cout << "**Grid: " << it->first << "**" << endl;
		for( int i=0; i<(int)(it->second).size(); ++i )
		{
			cout << "Config index " << i << endl;
			for(int j=0; j<(int)(it->second)[i].size(); ++j)
			{
				cout << "Tree " << j << endl;
				for( set< LineageConfig,LTLinCfg> :: iterator itg = (it->second)[i][j].begin(); itg != (it->second)[i][j].end(); ++itg)
				{
					itg->Dump();
				}
			}
		}
//cout << "At grid " << it->first << ", size of configs = " << resStep << endl;;
	}
}
void STFinderConfigStore :: DumpCfgsStatisticsAt( const set<int> &nodeId) 
{
	if( mapConfigForNodes.find( nodeId) == mapConfigForNodes.end() )
	{
		return;
	}
	double minProb = 1.0, maxProb = 0.0;
	for( LINCfgsAtGrid :: iterator it = mapConfigForNodes[nodeId].begin(); it != mapConfigForNodes[nodeId].end(); ++it )
	{
		//cout << "**Grid: " << it->first << "**" << endl;
		for( int i=0; i<(int)(it->second).size(); ++i )
		{
			//cout << "Config index " << i << endl;
			for(int j=0; j<(int)(it->second)[i].size(); ++j)
			{
				//cout << "Tree " << j << endl;
				for( set< LineageConfig,LTLinCfg> :: iterator itg = (it->second)[i][j].begin(); itg != (it->second)[i][j].end(); ++itg)
				{
					//itg->Dump();
					double pr = itg->GetProb();
					if( pr < minProb )
					{
						minProb = pr;
					}
					if( pr > maxProb )
					{
						maxProb = pr;
					}
				}
			}
		}
//cout << "At grid " << it->first << ", size of configs = " << resStep << endl;;
	}
//	cout << "Range of probility at this subset: [ " << minProb << ", " << maxProb << "]\n";
}


double STFinderConfigStore :: CalcTotProbAt(const set<int> &nodesRoot)
{
	YW_ASSERT_INFO(gstHelperPtr != NULL, "Can not be null");

	// from all the configuration candidates, pick the largest one
	// here each config is going to coalesce into the final (infinite) branch out of species tree root
	YW_ASSERT_INFO( mapConfigForNodes.find( nodesRoot ) != mapConfigForNodes.end(), "Bad root node3"  );
	double res = 0.0;
	for( LINCfgsAtGrid :: iterator it = mapConfigForNodes[nodesRoot].begin(); it != mapConfigForNodes[nodesRoot].end(); ++it )
	{
		//cout << "**Grid: " << it->first << "**" << endl;
		for( int i=0; i<(int)(it->second).size(); ++i )
		{
			// pick the larger one
			double probCurStep = 1.0;
			//cout << "Config index " << i << endl;
			for(int j=0; j<(int)(it->second)[i].size(); ++j)
			{
				double probCurStepTree = 0.0;
				//cout << "Tree " << j << endl;
				for( set< LineageConfig,LTLinCfg> :: iterator itg = (it->second)[i][j].begin(); itg != (it->second)[i][j].end(); ++itg)
				{
					//itg->Dump();
					if( itg->GetTotNumLins() == 1 )
					{
						probCurStepTree += itg->GetProb();
					}
					else
					{
						// need to compute the final combinatorial factor
						LineageConfig finalLC;
						LineageCluster flc;
						int rtGT = gstHelperPtr->GetRootIdGT(j);
						flc.Init(rtGT, 1, -1);
						finalLC.AddLC( flc );
						double coeff = gstHelperPtr->CalcCoalCoeffForTwoCfg(j, *itg, finalLC);
			//cout << "CalcTotProbAt: coeff = " << coeff << endl;
						probCurStepTree += itg->GetProb()*coeff;
					}
				}
				// 
				probCurStep *= probCurStepTree;
			}
			// 
			if( probCurStep > res )
			{
				res = probCurStep;
			}
		}
//cout << "At grid " << it->first << ", size of configs = " << resStep << endl;;
	}


	return res;
}

void STFinderConfigStore :: TraceBackBuildTree( const set<int> &nodesRoot, MarginalTree &treeOpt )
{
	// find opt root cfgs first
	YW_ASSERT_INFO( mapConfigForNodes.find( nodesRoot ) != mapConfigForNodes.end(), "Bad root node3"  );
	double res = 0.0;
	int gridRoot = -1;
	vector<set<LineageConfig,LTLinCfg> > cfgsRootTrace;
	for( LINCfgsAtGrid :: iterator it = mapConfigForNodes[nodesRoot].begin(); it != mapConfigForNodes[nodesRoot].end(); ++it )
	{
//cout << "**Grid: " << it->first << "**" << endl;
		for( int i=0; i<(int)(it->second).size(); ++i )
		{
			// pick the larger one
			double probCurStep = 1.0;
			//cout << "Config index " << i << endl;
			for(int j=0; j<(int)(it->second)[i].size(); ++j)
			{
				double probCurStepTree = 0.0;
				//cout << "Tree " << j << endl;
				for( set< LineageConfig,LTLinCfg> :: iterator itg = (it->second)[i][j].begin(); itg != (it->second)[i][j].end(); ++itg)
				{
					//itg->Dump();
					if( itg->GetTotNumLins() == 1 )
					{
						probCurStepTree += itg->GetProb();
					}
					else
					{
						// need to compute the final combinatorial factor
						LineageConfig finalLC;
						LineageCluster flc;
						int rtGT = gstHelperPtr->GetRootIdGT(j);
						flc.Init(rtGT, 1, -1);
						finalLC.AddLC( flc );
						double coeff = gstHelperPtr->CalcCoalCoeffForTwoCfg(j, *itg, finalLC);
			//cout << "CalcTotProbAt: coeff = " << coeff << endl;
						probCurStepTree += itg->GetProb()*coeff;
					}
				}
				// 
				probCurStep *= probCurStepTree;
			}
			// 
			if( probCurStep > res )
			{
				res = probCurStep;
				cfgsRootTrace = it->second[i];
				gridRoot = it->first;
			}
		}
//cout << "At grid " << it->first << ", size of configs = " << resStep << endl;;
	}

	YW_ASSERT_INFO( gridRoot >= 0, "Fail to find the best" );
//cout << "gridRoot = " << gridRoot << ", opt prob = " << res << endl;

	stack<  vector<set<LineageConfig,LTLinCfg> >  > stackCfgSrcInfo;
	stack< int > stackGrid;
	//stack< double > stackProbs;
	stack< set<int> > stackSetInfo;
	map< set<int>, LINCFG_SRC_INFO > mapBranchingSave;

	stackGrid.push( gridRoot  );
	//stackProbs.push( res );
	stackSetInfo.push( nodesRoot );
	stackCfgSrcInfo.push( cfgsRootTrace );

	while( stackCfgSrcInfo.empty() == false )
	{
		LINCFG_SRC_INFO cfgSrcInfo;
		FindOptSubsets( stackSetInfo.top(), stackGrid.top(), stackCfgSrcInfo.top(), cfgSrcInfo );
		mapBranchingSave.insert( map< set<int>, LINCFG_SRC_INFO > :: value_type(stackSetInfo.top(), cfgSrcInfo ) ) ;

		// check two sides
		stackSetInfo.pop();
		stackGrid.pop();
		stackCfgSrcInfo.pop();
//cout << "*** SPLITTING into \n";
//DumpIntSet(cfgSrcInfo.speciesLeft);
//DumpIntSet(cfgSrcInfo.speciesRight);
		// queue the two descendent if more than two
		if( cfgSrcInfo.speciesLeft.size() > 1 )
		{
			stackSetInfo.push( cfgSrcInfo.speciesLeft );
			stackGrid.push( cfgSrcInfo.gridLeft );
			stackCfgSrcInfo.push( cfgSrcInfo.cfgsLeft );
		}
		if( cfgSrcInfo.speciesRight.size() > 1 )
		{
			stackSetInfo.push( cfgSrcInfo.speciesRight );
			stackGrid.push( cfgSrcInfo.gridRight );
			stackCfgSrcInfo.push( cfgSrcInfo.cfgsRight );
		}
	}

	// build the tree
	BuildTreeByBranching( nodesRoot, gridRoot, treeOpt, mapBranchingSave );

}



void STFinderConfigStore :: FindOptSubsets(const set<int> &setTot, int grid, const vector<set<LineageConfig,LTLinCfg> >& cfgsTot, 
	LINCFG_SRC_INFO &cfgSrcInfo )
{
	// which subset gives this setTot with that particular branches
	if(setTot.size() <= 1)
	{
		return ;
	}
//cout << "setTot: ";
//DumpIntSet( setTot );
	vector<int> vecSetTot;
	PopulateVecBySet( vecSetTot, setTot);
	// try all subset of the items
	// enumerate all its subsets by try all subsets of species
	// to avoid duplicate, we always select first row
	bool fFound = false;
	for( int nr = 0; nr < (int)setTot.size()-1; ++nr)
	{
		// Now, we enumerate all combinations of nr rows
		// We do this by first get the position vector of each such cases
		vector<int> posvec;
		GetFirstCombo( nr, setTot.size()-1, posvec );
		while(true)
		{
//cout << "Now treat cell for: " ;
//DumpIntVec( posvec );
			// find selected rows
			set<int> rowss1, rowss2;
			for( int ii=0; ii<(int)posvec.size(); ++ii )
			{
				YW_ASSERT_INFO( posvec[ii] < (int) vecSetTot.size(), "Array out of bound" );
				rowss1.insert( vecSetTot[ posvec[ii] ] );
			}
			rowss1.insert( vecSetTot[vecSetTot.size()-1] );
			// split rows into ss1 and ss2
			rowss2 = setTot;
			//PopulateSetByVec(rowss2, rows);
			YW_ASSERT_INFO(rowss2.size() == vecSetTot.size(), "size wrong" );
			SubtractSets( rowss2, rowss1 );
			YW_ASSERT_INFO(rowss2.size() + rowss1.size() == vecSetTot.size(), "size wrong2" );
//cout << "rowss1 = ";
//DumpIntSet( rowss1 );
//cout << "rowss2 = ";
//DumpIntSet( rowss2 );

			// search through all grid (shorter than current grid)
			if( mapConfigForNodes.find( rowss1 ) !=mapConfigForNodes.end() && mapConfigForNodes.find(rowss2) != mapConfigForNodes.end() )
			{
				for( LINCfgsAtGrid :: iterator itt1 = mapConfigForNodes[rowss1].begin(); itt1 != mapConfigForNodes[rowss1].end(); ++itt1)
				{
					if( itt1->first >= grid )
					{
						continue;
					}
						double ht1 = (grid - itt1->first)*GetGridSize();
//cout << "itt1->first = " << itt1->first;
//cout << ", ht1 = " << ht1 << endl;
					for( int ii1 = 0; ii1 <(int) itt1->second.size(); ++ii1 )
					{
						// compute the prob
						// construct vecLeftAncLists
						vector<vector<AncLinConfig *> > configsNewLeft;
						for(int ii2=0; ii2<(int)itt1->second[ii1].size(); ++ii2)
						{
					//cout << "ProcessTwoChoices: LEFT cfg num: " << pp1 << ", tree " << ii << ", current LinCfg:\n";
					//for( set<LineageConfig,LTLinCfg>:: iterator ittt=setLCs1[pp1][ii].begin(); ittt!=setLCs1[pp1][ii].end();++ittt )
					//{
					//ittt->Dump();
					//}
							vector<AncLinConfig *>  configsNewLeftStep;
							gstHelperPtr->FastCollectAncConfig(ii2, ht1, itt1->second[ii1][ii2], configsNewLeftStep  );
//cout << "size of configsNewLeftStep: " << configsNewLeftStep.size() << endl;
							configsNewLeft.push_back(configsNewLeftStep);
						}


						// now the other side
						for( LINCfgsAtGrid :: iterator itt2 = mapConfigForNodes[rowss2].begin(); itt2 != mapConfigForNodes[rowss2].end(); ++itt2)
						{
							if( itt2->first >= grid )
							{
								continue;
							}
							double ht2 = (grid - itt2->first)*GetGridSize();
//cout << "ht2 = " << ht2 << endl;
							for( int jj1 = 0; jj1 <(int) itt2->second.size(); ++jj1 )
							{
								// compute the prob

								// construct vecLeftAncLists
								vector<vector<AncLinConfig *> > configsNewRight;
								for(int jj2=0; jj2<(int)itt2->second[jj1].size(); ++jj2)
								{
							//cout << "ProcessTwoChoices: LEFT cfg num: " << pp1 << ", tree " << ii << ", current LinCfg:\n";
							//for( set<LineageConfig,LTLinCfg>:: iterator ittt=setLCs1[pp1][ii].begin(); ittt!=setLCs1[pp1][ii].end();++ittt )
							//{
							//ittt->Dump();
							//}
									vector<AncLinConfig *>  configsNewRightStep;
									gstHelperPtr->FastCollectAncConfig(jj2, ht2, itt2->second[jj1][jj2], configsNewRightStep  );
									configsNewRight.push_back(configsNewRightStep);
								}

								// can this form the desired cfg???
								vector<set<LineageConfig,LTLinCfg> > lcsStep;
								for(int kk=0; kk<(int)configsNewLeft.size(); ++kk)
								{
									set<LineageConfig,LTLinCfg> ssTemp;
									for( int ii=0; ii< (int)configsNewLeft[kk].size();  ++ii )
									{
							//cout << "Here\n";
							//cout << "Left ances: ";
							//configsNewLeft[kk][ii]->Dump();
										for(  int jj = 0; jj<  (int)configsNewRight[kk].size(); ++jj )
										{
							//cout << "Right ances: ";
							//configsNewRight[kk][jj]->Dump();

											// form a new one
											LineageConfig lcNew;
											gstHelperPtr->FormLinConfig(kk, -1, configsNewLeft[kk][ii]->GetLinCfg(),  configsNewRight[kk][jj]->GetLinCfg(), lcNew);
											// setup prob
											lcNew.SetProb(  configsNewLeft[kk][ii]->GetProb()*configsNewRight[kk][jj]->GetProb() );
											//statesDepot[iv].insert( lcNew );
											//storeLinCfgs.AddLinCfg(iv, lcNew );

											// is this cfg new?
											//YW_ASSERT_INFO( lcsStep.find(lcNew) == lcsStep.end(), "Can not happen");
											//{
											// add it
											ssTemp.insert(lcNew);

							//cout << "After FormLinConfig, find a new LC: ";
							//lcNew.Dump();
										}
									}
									lcsStep.push_back(ssTemp);
								}
								
								if( AreTwoCfgsSame(lcsStep, cfgsTot ) == true )
								{
									fFound = true;

									// also need to record solution
									cfgSrcInfo.speciesLeft = rowss1;
									cfgSrcInfo.speciesRight = rowss2;
									cfgSrcInfo.gridLeft = itt1->first;
									cfgSrcInfo.gridRight = itt2->first;

									// remember what cfgs left and right
									cfgSrcInfo.cfgsLeft = itt1->second[ii1];
									cfgSrcInfo.cfgsRight = itt2->second[jj1];

									break;
								}

								
								//if( fFound == true)
								//{
								//	break;
								//}
							}
							if( fFound == true)
							{
								break;
							}

						}
						if( fFound == true)
						{
							break;
						}

					}
					if( fFound == true)
					{
						break;
					}

				}
				if( fFound == true)
				{
					break;
				}

			}

			if( fFound == true)
			{
				break;
			}


			// Get the next position
			if( GetNextCombo( nr, setTot.size()-1, posvec ) == false )
			{
				break;
			}
		}
		if( fFound == true)
		{
			break;
		}

	}
	YW_ASSERT_INFO(fFound == true, "Fail to find trace back");

	// ???
}

bool STFinderConfigStore :: AreTwoCfgsSame( const vector<set<LineageConfig,LTLinCfg> >& listCfg1, const vector<set<LineageConfig,LTLinCfg> >& listCfg2 )
{
	// are thet wo the same
	YW_ASSERT_INFO(listCfg1.size() == listCfg2.size(), "Size mismatch");
	for(int tr=0; tr<(int)listCfg1.size(); ++tr)
	{
		// are the two same
		if( listCfg1[tr].size() != listCfg2[tr].size()  )
		{
			return false;
		}
		for( set<LineageConfig,LTLinCfg> :: iterator it1 = listCfg1[tr].begin(), it2 = listCfg2[tr].begin(); 
			it1 != listCfg1[tr].end() && it2 != listCfg2[tr].end(); it1++, it2++  )
		{
			// make sure the snid is the same
			//const_cast<LineageConfig &>(it1);

			//
			if( it1->AreLCsSame(*it2) == false )
			{
				return false;
			}
			// are they with same prob
			double prob1 = it1->GetProb();
			double prob2 = it2->GetProb();
			if( AreDoubleIdentical( prob1, prob2 ) == false)
			{
				return false;
			}
		}
	}
	return true;
}

void STFinderConfigStore :: BuildTreeByBranching( const set<int> &nodesRoot, int gridRoot, MarginalTree &treeOpt, map< set<int>, LINCFG_SRC_INFO >  &mapBranchingSave )
{
	// get newick string
	string nwStr = GetNewickStrForBranching( nodesRoot,gridRoot, mapBranchingSave);
//cout << "NEWICK FORMAT of tree: " << nwStr << endl;
	ReadinMarginalTreesNewickWLenString( nwStr, nodesRoot.size(), treeOpt );
}

string STFinderConfigStore :: GetNewickStrForBranching( const set<int> &setTaxa,  int gridCur, map< set<int>, LINCFG_SRC_INFO >  &mapBranchingSave )
{
	YW_ASSERT_INFO( setTaxa.size() > 0, "Can not be empty" );
	//
	if( setTaxa.size() == 1 )
	{
		// just return the current node id
		char buf[100];
		sprintf(buf, "%d", *(setTaxa.begin() ) );
		return buf;
	}
	else
	{
		YW_ASSERT_INFO( mapBranchingSave.find( setTaxa) != mapBranchingSave.end(), "Not in map" );
		// get the left and right string
		string strLeft = GetNewickStrForBranching( mapBranchingSave[setTaxa].speciesLeft, mapBranchingSave[setTaxa].gridLeft,  mapBranchingSave );
		double lenLeft = GetDistGrid(gridCur, mapBranchingSave[setTaxa].gridLeft );
		char buf1[100];
		sprintf(buf1, ":%f,", lenLeft);
		string strRight = GetNewickStrForBranching( mapBranchingSave[setTaxa].speciesRight, mapBranchingSave[setTaxa].gridRight, mapBranchingSave );
		double lenRight = GetDistGrid(gridCur, mapBranchingSave[setTaxa].gridRight );
		char buf2[100];
		sprintf(buf2, ":%f)", lenRight);
		string res = "(";
		res += strLeft + buf1;
		res += strRight + buf2;
		return res;
	}
}



void STFinderConfigStore :: PruneCfgs(const set<int>& staxa, int grid, double probCurEst)
{
//return;
	// prune the list of configs which are clearly not optimal
	// Idea: for each LinConfig at one tree, can this lead to optimal solution
	// by assuming all the others can be made the best as it goes?
	if( mapConfigForNodes.find(staxa) == mapConfigForNodes.end() ||
		mapConfigForNodes[staxa].find(grid) == mapConfigForNodes[staxa].end()  )
	{
		// nothing to prune
		return;
	}
	//YW_ASSERT_INFO( mapConfigForNodes[staxa].find(grid) != mapConfigForNodes[staxa].end(), "Fail to find2" );
//cout << "Before prunning for set: ";
//DumpIntSet( staxa );
//cout << "Grid " << grid << ", size of confg kept = " << GetNumLinCfgsAtGrid(staxa, grid) << endl; 
	vector< vector<set<LineageConfig,LTLinCfg> >  > listCfgNew;

	// a simple approach, prune it if the prob of mutating is not going to be over
	for(int icfg = 0; icfg<(int)mapConfigForNodes[staxa][grid].size(); ++icfg)
	{
		// for each cfg here, find the best prob of each tree. can we do better?
		vector<double> listMaxProbEstPerTree;
		for( int tr=0; tr<(int)mapConfigForNodes[staxa][grid][icfg].size(); ++tr )
		{
			// 
			double probMaxStep = 0.0;
			for( set<LineageConfig,LTLinCfg> :: iterator itg = mapConfigForNodes[staxa][grid][icfg][tr].begin(); 
				itg != mapConfigForNodes[staxa][grid][icfg][tr].end(); ++itg )
			{
				LineageConfig finalLC;
				LineageCluster flc;
				int rtGT = gstHelperPtr->GetRootIdGT(tr);
				flc.Init(rtGT, 1, -1);
				finalLC.AddLC( flc );
				double coeff = gstHelperPtr->CalcCoalCoeffForTwoCfg(tr, *itg, finalLC);
	//cout << "CalcTotProbAt: coeff = " << coeff << endl;
				double probitg = itg->GetProb()*coeff;
				if( probitg > probMaxStep)
				{
					probMaxStep = probitg;
				}
			}
			// store it
			listMaxProbEstPerTree.push_back( probMaxStep );
//cout << "cfg: " << icfg << ", tree " << tr << ", max prob = " << probMaxStep << endl;
		}

		// now treat each item one by one
		vector<set<LineageConfig,LTLinCfg> >  listCfgNewStep;
		for( int tr=0; tr<(int)mapConfigForNodes[staxa][grid][icfg].size(); ++tr )
		{
			// 
			set<LineageConfig,LTLinCfg> setCfgNew;
			for( set<LineageConfig,LTLinCfg> :: iterator itg = mapConfigForNodes[staxa][grid][icfg][tr].begin(); 
				itg != mapConfigForNodes[staxa][grid][icfg][tr].end(); ++itg )
			{
				// can this cfg be optimal? we multiply by the maximum over all others
				//double probitg = itg->GetProb();

				LineageConfig finalLC;
				LineageCluster flc;
				int rtGT = gstHelperPtr->GetRootIdGT(tr);
				flc.Init(rtGT, 1, -1);
				finalLC.AddLC( flc );
				double coeff = gstHelperPtr->CalcCoalCoeffForTwoCfg(tr, *itg, finalLC);
	//cout << "CalcTotProbAt: coeff = " << coeff << endl;
				double probitg = itg->GetProb()*coeff;



//cout << "Self prob = " << probitg << endl;
				for(int tr2=0; tr2<(int)mapConfigForNodes[staxa][grid][icfg].size(); ++tr2)
				{
					if( tr2 != tr)
					{
						probitg *= listMaxProbEstPerTree[tr2];
					}
				}
//cout << "after multiplying the other tree's prob, it becomes " << probitg << endl;
				if( probitg >= probCurEst)
				{
//cout << "********************KEEP\n";
					// this one shuold be kept
					setCfgNew.insert(*itg);
				}
			}
			// store it if there is still something
			if( setCfgNew.size() > 0 )
			{
				listCfgNewStep.push_back( setCfgNew );
			}
		}
		// add to curr saved result
		if( listCfgNewStep.size() > 0  )
		{
			listCfgNew.push_back(listCfgNewStep);
		}
	}

#if 0
	for(int icfg = 0; icfg<(int)mapConfigForNodes[staxa][grid].size(); ++icfg)
	{
		// for each cfg here, find the best prob of each tree. can we do better?
		vector<double> listMaxProbEstPerTree;
		for( int tr=0; tr<(int)mapConfigForNodes[staxa][grid][icfg].size(); ++tr )
		{
			// 
			double probMaxStep = 0.0;
			for( set<LineageConfig,LTLinCfg> :: iterator itg = mapConfigForNodes[staxa][grid][icfg][tr].begin(); 
				itg != mapConfigForNodes[staxa][grid][icfg][tr].end(); ++itg )
			{
				LineageConfig finalLC;
				LineageCluster flc;
				int rtGT = gstHelperPtr->GetRootIdGT(tr);
				flc.Init(rtGT, 1, -1);
				finalLC.AddLC( flc );
				double coeff = gstHelperPtr->CalcCoalCoeffForTwoCfg(tr, *itg, finalLC);
	//cout << "CalcTotProbAt: coeff = " << coeff << endl;
				double probitg = itg->GetProb()*coeff;
				if( probitg > probMaxStep)
				{
					probMaxStep = probitg;
				}
			}
			// store it
			listMaxProbEstPerTree.push_back( probMaxStep );
//cout << "cfg: " << icfg << ", tree " << tr << ", max prob = " << probMaxStep << endl;
		}

		// now treat each item one by one
		vector<set<LineageConfig,LTLinCfg> >  listCfgNewStep;
		for( int tr=0; tr<(int)mapConfigForNodes[staxa][grid][icfg].size(); ++tr )
		{
			// 
			set<LineageConfig,LTLinCfg> setCfgNew;
			for( set<LineageConfig,LTLinCfg> :: iterator itg = mapConfigForNodes[staxa][grid][icfg][tr].begin(); 
				itg != mapConfigForNodes[staxa][grid][icfg][tr].end(); ++itg )
			{
				// can this cfg be optimal? we multiply by the maximum over all others
				double probitg = itg->GetProb();
//cout << "Self prob = " << probitg << endl;
				for(int tr2=0; tr2<(int)mapConfigForNodes[staxa][grid][icfg].size(); ++tr2)
				{
					if( tr2 != tr)
					{
						probitg *= listMaxProbEstPerTree[tr2];
					}
				}
//cout << "after multiplying the other tree's prob, it becomes " << probitg << endl;
				if( probitg >= probCurEst)
				{
//cout << "********************KEEP\n";
					// this one shuold be kept
					setCfgNew.insert(*itg);
				}
			}
			// store it if there is still something
			if( setCfgNew.size() > 0 )
			{
				listCfgNewStep.push_back( setCfgNew );
			}
		}
		// add to curr saved result
		if( listCfgNewStep.size() > 0  )
		{
			listCfgNew.push_back(listCfgNewStep);
		}
	}
#endif
	// finally update its
	mapConfigForNodes[staxa][grid] = listCfgNew;
//cout << "After pruning, size of confg kept = " << GetNumLinCfgsAtGrid(staxa, grid) << endl; 
}


void STFinderConfigStore :: PruneCfgsRows(const set<int>& staxa)
{
	if( mapConfigForNodes.find(staxa) == mapConfigForNodes.end()  )
	{
		// nothing to prune
		return;
	}
	//YW_ASSERT_INFO( mapConfigForNodes[staxa].find(grid) != mapConfigForNodes[staxa].end(), "Fail to find2" );
//cout << "Before prunning for set: ";
//DumpIntSet( staxa );
//cout << " size of confg kept = " << GetNumLinCfgsAt(staxa) << endl; 

	// a simple approach, prune a cfg if it is no better than the other cfg at a lower level and mutate by the dist
	for( LINCfgsAtGrid :: iterator itt = mapConfigForNodes[staxa].begin(); itt != mapConfigForNodes[staxa].end(); ++itt )
	{
		int grid1 = itt->first;
		vector< vector<set<LineageConfig,LTLinCfg> >  > listCfgNew;
		for(int icfg = 0; icfg<(int)itt->second.size(); ++icfg)
		{
			bool fBeaten = false;
			for( LINCfgsAtGrid :: iterator itt2 = mapConfigForNodes[staxa].begin(); itt2 != itt; ++itt2 )
			{
				int grid2 = itt2->first;
				// 
				for(int icfg2 = 0; icfg2<(int)itt2->second.size(); ++icfg2)
				{
					// 
					if( IsCfgBetter(  itt2->second[icfg2], grid2, itt->second[icfg], grid1  ) == true )
					{
						fBeaten = true;
						break;
					}
				}
				if( fBeaten == true )
				{
					break;
				}
			}
			// if not beaten, keep it
			if( fBeaten == false )
			{
				listCfgNew.push_back( itt->second[icfg] );
			}
		}
		// save it
		// finally update its
		mapConfigForNodes[staxa][grid1] = listCfgNew;

	}
//cout << "After pruning, size of confg kept = " << GetNumLinCfgsAt(staxa) << endl; 

}

bool STFinderConfigStore :: IsCfgBetter(  vector<set<LineageConfig,LTLinCfg> > &cfgBetter, int grid1, 
										vector<set<LineageConfig,LTLinCfg> >  &cfgWorse, int grid2)
{
	// ensure grid1 is lower
	YW_ASSERT_INFO( grid1 <= grid2, "Grid1 must be no bigger than grid2" );
	YW_ASSERT_INFO(cfgBetter.size() == cfgWorse.size(), "Wrong");
	// 
	double dist = (grid2-grid1)*GetGridSize();


	// 
	for(int tr=0; tr<(int)cfgWorse.size(); ++tr)
	{
		// 
		for( set<LineageConfig,LTLinCfg> :: iterator itt = cfgWorse[tr].begin(); itt != cfgWorse[tr].end(); ++itt )
		{
			// 
			int numLins = itt->GetTotNumLins();
			double probTrans = gstHelperPtr->CalcCoalProbBranch( tr, numLins, numLins, dist  );
			double coeff = gstHelperPtr->CalcCoalCoeffForTwoCfg(tr, *itt, *itt);
			// 
			if( cfgBetter[tr].find(*itt) == cfgBetter[tr].end() )
			{
//cout << "Fail to find it in ancestral cfg\n";
				return false;
			}
			else
			{
				// is the corresponding node contained in 
				double probBetter = (cfgBetter[tr].find(*itt))->GetProb();
				if(  probBetter * probTrans * coeff < itt->GetProb() )
				{
					// can not beat this
//cout << "ProbBetter = " << probBetter << ", probWorse = " << itt->GetProb() << endl;
					return false;
				}
			}
//cout << "probTrans = " << probTrans << ", coeff: " << coeff << endl;
		}
	}
//cout << "Beaten\n";
	return true;
}


//bool STFinderConfigStore :: IsCfgBetter(  vector<set<LineageConfig,LTLinCfg> > &cfgBetter, vector<set<LineageConfig,LTLinCfg> >  &cfgWorse)
//{
//	// decide whether the first cfg is better than the second one
//	YW_ASSERT_INFO( cfgBetter.size() == cfgWorse.size(), "Size mismatch" );
//	// we check each state (set of lineages), if the better contains all the states in each of the trees
//	for(int tr=0; tr<(int)cfgBetter.size(); ++tr)
//	{
//		// 
//		for( set<LineageConfig,LTLinCfg> :: iterator it = cfgWorse[tr].begin(); it != cfgWorse[tr].end(); ++it  )
//		{
//			// 
//			if(cfgBetter[tr].find(*it) == cfgBetter[tr].end()  )
//			{
//				return false;
//			}
//			if( it->GetProb() > (cfgBetter[tr].find(*it))->GetProb()  )
//			{
//				return false;
//			}
//		}
//	}
//	return true;
//}

//bool STFinderConfigStore :: IsCfgInferior( const set<int>& staxa, int grid, vector<set< LineageConfig,LTLinCfg> > &lcsNew   )
//{
//	// we say a cfg is inferior if this cfg is bean by an existing cfg (that is, the cfg 
//}


void STFinderConfigStore :: DumpStatistics() const
{
	cout <<"--------------------------------------------\n";
	cout << "Total number of considered cfgs: " << numTotExamedCfgs << endl;
	cout << "Number of skipped cfgs: " << numSkippedCfgs << endl;
	cout << "Number of beaten cfgs: " << numBeteanCfgs << endl;
}



///////////////////////////////////////////////////////////////////////////////////

MultiGeneTreeHelper :: MultiGeneTreeHelper()
{
}

MultiGeneTreeHelper :: ~MultiGeneTreeHelper()
{
	for(int i=0; i<(int)listGTHelperPtrs.size(); ++i )
	{
		delete listGTHelperPtrs[i];
	}
	listGTHelperPtrs.clear();
}


// adding a tree
void MultiGeneTreeHelper :: AppendGTree( PhylogenyTreeBasic *ptrGT )
{
	YW_ASSERT_INFO( ptrGT != NULL, "Can not deal with empty gene tree" );
	// create a new GTreeHelper
	GeneSpeciesTreeHelper *pGSTHelper = new GeneSpeciesTreeHelper( dummyTreeSpecies, *ptrGT );
	listGTHelperPtrs.push_back( pGSTHelper );
}

void MultiGeneTreeHelper :: CollectSpecies()
{
	// exam each tree and collect their labels (species)
	set<int> species;
	for(int i=0;i<(int)listGTHelperPtrs.size(); ++i)
	{
		set<int> speciesStep;
		listGTHelperPtrs[i]->GetLeavesSpeciesGT(speciesStep);
//cout << "SpeicesStep: ";
//DumpIntSet( speciesStep );
		if( species.size() == 0 )
		{
			species = speciesStep;
		}
		YW_ASSERT_INFO( species == speciesStep, "Fatal error: gene trees species inconsistent" );
	}
	// convert to vector format
	PopulateVecBySet(setSpecies, species);
	numSpecies = species.size();
}

// querying
GeneSpeciesTreeHelper * MultiGeneTreeHelper :: GetGTHelperPtr(int tr) const
{
	YW_ASSERT_INFO( tr <(int)listGTHelperPtrs.size(), "Gene tree out of range" );
	return listGTHelperPtrs[tr];
}

void MultiGeneTreeHelper :: GetGeneAllelesForSpecies(int gt, int taxon, set<int> &geneAlleles)
{
	// 
	GeneSpeciesTreeHelper *pgt = GetGTHelperPtr(gt);
	pgt->GetGeneAllelesForSpecies( taxon, geneAlleles );
}

void MultiGeneTreeHelper :: GetSpeciesAt(const vector<int> &speciesPos, vector<int> &species  )
{
	// collect a subset of species specified by the positions
	for(int i=0; i<(int)speciesPos.size(); ++i)
	{
		int pos = speciesPos[i];
		YW_ASSERT_INFO( pos < (int)setSpecies.size(), "Species position out of bound" );
		species.push_back( setSpecies[pos] );
	}
}

void MultiGeneTreeHelper :: FormLinConfig(int tr, int snid, const set<int> &linsGT, LineageConfig &linConfig ) const
{
	// simply pass to one of its tree (any works since it is actually neurtral to tree)
	//YW_ASSERT_INFO(GetNumGTrees() >=1, "Can not have empty set of trees");
	GetGTHelperPtr(tr)->FormLinConfig( snid, linsGT, linConfig );
}

void MultiGeneTreeHelper :: FormLinConfig(int tr, int snid, const LineageConfig &linsGT1, const LineageConfig &linsGT2, LineageConfig &linConfig ) const
{
	//YW_ASSERT_INFO(GetNumGTrees() >=1, "Can not have empty set of trees");
	GetGTHelperPtr(tr)->FormLinConfig( snid, linsGT1, linsGT2, linConfig );
}

void MultiGeneTreeHelper :: FastCollectAncConfig( int tr, double lenOrig, 
												 const set<LineageConfig,LTLinCfg> &setOrigCfgs, vector< AncLinConfig *> &listAncCfgsNew )
{
	GetGTHelperPtr(tr)->FastCollectAncConfig(lenOrig, setOrigCfgs, listAncCfgsNew );
}

int MultiGeneTreeHelper :: GetRootIdGT(int tr)
{
	return GetGTHelperPtr(tr)->GetRootIdGT();
}

double MultiGeneTreeHelper :: CalcCoalCoeffForTwoCfg( int tr, const LineageConfig &linCfg1, const LineageConfig &linCfg2 ) const
{
	return GetGTHelperPtr(tr)->CalcCoalCoeffForTwoCfg(linCfg1, linCfg2);
}

double MultiGeneTreeHelper :: CalcCoalProbBranch(int tr, int u, int v, double len ) const
{
	return GetGTHelperPtr(tr)->CalcCoalProbBranch(u,v,len);
}



///////////////////////////////////////////////////////////////////////////////////
// need a list of gene trees

OptSpeciesTreeFinder :: OptSpeciesTreeFinder( const vector<PhylogenyTreeBasic *> &listGPtrs ) : listGTreePtrs(listGPtrs)
{
	numGridSz = DEFAULT_NUM_GRID_SIZE;
	szGridStep = DEFAULT_SZ_GRID_STEP;		
	fLeafLevel0 = true;				// by default, start from leve 0.0 for all leaves
	//fLeafLevel0 = false;				// by default, allow leaf to stay in any position
	knownUB = 0.0;					// set to this large value
	fTrimmedRowsSpace = false;

	Init();
}

// during init, we perform a quick search
void OptSpeciesTreeFinder :: Init()
{
	// initialize tree helper
	for(int i=0;i<(int)listGTreePtrs.size(); ++i)
	{
		mgtHelper.AppendGTree( listGTreePtrs[i] );
	}
	mgtHelper.CollectSpecies();

	// misc
	storeLinCfgs.SetTreeHelper(&mgtHelper);
	storeLinCfgs.SetGridInfo(szGridStep);
}



// return the MLE prob value
double OptSpeciesTreeFinder :: FindOptST( MarginalTree &mleST )
{
	//
	int numSpecies = mgtHelper.GetNumSpecies();
	YW_ASSERT_INFO( numSpecies >= 2, "Must have at least two species" );

//#if 0
	// first start a heuristic search
	HeuSpeciesTreeFinder hstFinder( listGTreePtrs, numGridSz, szGridStep, numSpecies );
	MarginalTree trDummy;
	double probMaxHeu = hstFinder.InferByMinInconsistency(trDummy);
	cout << "Heuristic search gives a tree with prob = " << probMaxHeu << endl;
	this->knownUB = probMaxHeu;
//#endif

	// we first decide what clusters to use
	// by default we will search over all clusters
	// but if trimmed search flag is set, we only do a more limited search
	listGeneTreeClustersProcessed.clear();
	listGeneTreeClustersProcessed.resize(numSpecies+1);

	// this is the set of species
	set<int> speciesAll;
	mgtHelper.GetSpeciesSet(speciesAll);


	if( fTrimmedRowsSpace == true)
	{
cout << "Start search for optimal species tree in the trimmed search space...\n";
		// 
		ClusterCandidateFinder ccFinder( listGTreePtrs );
		const int CLUSTER_LEVEL = 1;
		ccFinder.FindCandidates(CLUSTER_LEVEL, listGeneTreeClustersProcessed);

		// be sure to take the last final row set
		listGeneTreeClustersProcessed[numSpecies].insert(speciesAll);
	}
	else
	{
		// simply enumeate for all
		for(int nr = 1; nr <= numSpecies; ++nr)
		{
cout << "Preprocessing nr = " << nr << endl;
			// Now, we enumerate all combinations of nr rows
			// We do this by first get the position vector of each such cases
			vector<int> posvec;
			GetFirstCombo( nr, numSpecies, posvec );
			while(true)
			{
	//cout << "*****************************************************************\nNow treat cell for: " ;
	//DumpIntVec( posvec );
				// Create a vector, and set the index vector
				//vector<int> subsetIndex;
				vector<int> subsetRows;
				mgtHelper.GetSpeciesAt( posvec, subsetRows  );
				//GetIntVec(numSpecies, posvec, subsetIndex );
				//subsetRows = posvec;
	//cout << "subset of species = " ;
	//DumpIntVec( subsetRows );

				// now process this subset of rows
				set<int> subsetRowsSS;
				PopulateSetByVec(subsetRowsSS, subsetRows);
				listGeneTreeClustersProcessed[nr].insert(subsetRowsSS);
				//FindOptSTForSpecies( subsetRows );

	//cout << "******************************************************\n"; 
	//set<int> ssRows;
	//PopulateSetByVec( ssRows, subsetRows );
	//int numCfgs = storeLinCfgs.GetNumLinCfgsAt( ssRows );
	//cout << "Total number of configs = " << numCfgs << endl;
	//storeLinCfgs.DumpCfgsAt(ssRows);
	//storeLinCfgs.DumpCfgsStatisticsAt(ssRows);
	//cout << "******************************************************\n"; 
				// Get the next position
				if( GetNextCombo( nr, numSpecies, posvec ) == false )
				{
					break;
				}
			}

		}
	}

	// now, we do it for all the configs we found
	for(int nr = 1; nr <= numSpecies; ++nr)
	{
//mdcTable.Dump();
cout << "**************************Processing nr = " << nr << endl;
		// Now, we enumerate all combinations of nr rows
		// We do this by first get the position vector of each such cases
		// for each level, at least one item must be able to find matches, if not, then we fail
		for( set<set<int> > :: iterator itts = listGeneTreeClustersProcessed[nr].begin(); itts != listGeneTreeClustersProcessed[nr].end();  ++itts  )
		{

			// Create a vector, and set the index vector
			//vector<int> subsetIndex;
			//vector<int> subsetRows;
			//mgtHelper.GetSpeciesAt( posvec, subsetRows  );
			//GetIntVec(numSpecies, posvec, subsetIndex );
			vector<int> curCluster;
			PopulateVecBySet(curCluster, *itts);
//cout << "*****************************************************************\nNow treat cell for: " ;
//DumpIntVec( curCluster );
			FindOptSTForSpecies( curCluster );
		}
	}


#if 0
	// approximate flag is on, then we only deal with a subset of rows
	if( fTrimmedRowsSpace == true)
	{
cout << "Start search for optimal species tree in the trimmed search space...\n";
		// 
		vector< set< set<int> > > listGeneTreeClusters(numSpecies+1);
		ClusterCandidateFinder ccFinder( listGTreePtrs );
		const int CLUSTER_LEVEL = 1;
		ccFinder.FindCandidates(CLUSTER_LEVEL, listGeneTreeClusters);

		// single rows
		for(int i=0; i<numSpecies; ++i)
		{
			// 
			vector<int> subsetRows;
			subsetRows.push_back( i );
			//
			FindOptSTForSpecies( subsetRows );
		}
		// now other rows
		for(int nr = 2; nr <= numSpecies; ++nr)
		{
	//mdcTable.Dump();
	cout << "**************************nr = " << nr << endl;
			// Now, we enumerate all combinations of nr rows
			// We do this by first get the position vector of each such cases
			// for each level, at least one item must be able to find matches, if not, then we fail
			for( set<set<int> > :: iterator itts = listGeneTreeClusters[nr].begin(); itts != listGeneTreeClusters[nr].end();  ++itts  )
			{

	//cout << "*****************************************************************\nNow treat cell for: " ;
	//DumpIntVec( posvec );
				// Create a vector, and set the index vector
				//vector<int> subsetIndex;
				//vector<int> subsetRows;
				//mgtHelper.GetSpeciesAt( posvec, subsetRows  );
				//GetIntVec(numSpecies, posvec, subsetIndex );
				vector<int> curCluster;
				PopulateVecBySet(curCluster, *itts);
				FindOptSTForSpecies( curCluster );

			}
		}
	}
	else
	{
		// try all subsets of species
		for(int nr = 1; nr <= numSpecies; ++nr)
		{
	cout << "**************************nr = " << nr << endl;
			// Now, we enumerate all combinations of nr rows
			// We do this by first get the position vector of each such cases
			vector<int> posvec;
			GetFirstCombo( nr, numSpecies, posvec );
			while(true)
			{
	//cout << "*****************************************************************\nNow treat cell for: " ;
	//DumpIntVec( posvec );
				// Create a vector, and set the index vector
				//vector<int> subsetIndex;
				vector<int> subsetRows;
				mgtHelper.GetSpeciesAt( posvec, subsetRows  );
				//GetIntVec(numSpecies, posvec, subsetIndex );
				//subsetRows = posvec;
	//cout << "subset of species = " ;
	//DumpIntVec( subsetRows );

				// now process this subset of rows
				FindOptSTForSpecies( subsetRows );

	//cout << "******************************************************\n"; 
	//set<int> ssRows;
	//PopulateSetByVec( ssRows, subsetRows );
	//int numCfgs = storeLinCfgs.GetNumLinCfgsAt( ssRows );
	//cout << "Total number of configs = " << numCfgs << endl;
	//storeLinCfgs.DumpCfgsAt(ssRows);
	//storeLinCfgs.DumpCfgsStatisticsAt(ssRows);
	//cout << "******************************************************\n"; 
				// Get the next position
				if( GetNextCombo( nr, numSpecies, posvec ) == false )
				{
					break;
				}
			}

		}
	}
#endif

	// not done yet
//	YW_ASSERT_INFO(false, "TBD");

	double probMax = storeLinCfgs.CalcTotProbAt(speciesAll);
cout << "******************************************************\n"; 
	cout << "Maximum prob over the grid is: " << probMax << endl;
cout << "******************************************************\n"; 

	//MarginalTree mTreeRes;
	storeLinCfgs.TraceBackBuildTree(speciesAll, mleST);
cout << "******************************************************\n"; 
	cout << "Found optimal tree = ";
	mleST.Dump();

	// dump some additional statistics
	storeLinCfgs.DumpStatistics();

	return probMax;
}

// useful functions
//void GetSpeciesAtNode( TreeNode *pnode, set<int> &speciesUnder )
//{
//	YW_ASSERT_INFO( pnode != NULL, "Fail" );
//	vector<string> listLeafLabels;
//	pnode->GetAllLeafLabeles( listLeafLabels );
//	speciesUnder.clear();
//	for( int jj=0; jj<(int)listLeafLabels.size(); ++jj )
//	{
//		// what species is this label?
//		int sp = GetSpeciesFromLabel( listLeafLabels[jj] );
//		speciesUnder.insert( sp );
//	}
//}

double OptSpeciesTreeFinder :: FindOptBranchLen( PhylogenyTreeBasic &streeTopology, MarginalTree &mleST )
{
	// different from opt stree finding, we are given a tree topology
	// and our goal is to find the branch length of the tree to max the product of prob. of each tree
	// we simply perform a tree traversal (bottom up)
	int numSpecies = mgtHelper.GetNumSpecies();
	YW_ASSERT_INFO( numSpecies >= 2, "Must have at least two species" );


	// try all subsets of species
	//streeTopology.InitPostorderWalk();
	PhylogenyTreeIterator phyItor(streeTopology);
	phyItor.Init();
	//while(true)
	while(phyItor.IsDone() == false )
	{
		TreeNode *pnode = phyItor.GetCurrNode();
		//streeTopology.NextPostorderWalk();
		if( pnode == NULL)
		{
			YW_ASSERT_INFO(false, "Should not be here4");
			break;
		}
		// get leaves
		//vector<string> listLeafLabels;
		//pnode->GetAllLeafLabeles( listLeafLabels );
		set<int> setSpecies;
		GetSpeciesAtNode(pnode, setSpecies);
		//for( int jj=0; jj<(int)listLeafLabels.size(); ++jj )
		//{
		//	// what species is this label?
		//	int sp = GetSpeciesFromLabel( listLeafLabels[jj] );
		//	setSpecies.insert( sp );
		//}

cout << "**************************curr species:  " << endl;
DumpIntSet( setSpecies );

		// Now, we enumerate all combinations of nr rows
		// We do this by first get the position vector of each such cases


		// now process this subset of rows
		vector<int> setSpeciesVec;
		PopulateVecBySet(setSpeciesVec, setSpecies);
		FindOptSTForSpecies( setSpeciesVec, pnode );

cout << "******************************************************\n"; 
//set<int> ssRows;
//PopulateSetByVec( ssRows, subsetRows );
int numCfgs = storeLinCfgs.GetNumLinCfgsAt( setSpecies );
cout << "Total number of configs = " << numCfgs << endl;
storeLinCfgs.DumpCfgsAt(setSpecies);
storeLinCfgs.DumpCfgsStatisticsAt(setSpecies);
cout << "******************************************************\n"; 

		// move to next
		phyItor.Next();
	}

	// not done yet
//	YW_ASSERT_INFO(false, "TBD");

	set<int> sp;
	mgtHelper.GetSpeciesSet(sp);
	double probMax = storeLinCfgs.CalcTotProbAt(sp);
cout << "******************************************************\n"; 
	cout << "Maximum prob over the grid is: " << probMax << endl;
cout << "******************************************************\n"; 

	return probMax;
}



//////////  implementation specific  ////////////////////////////////

void OptSpeciesTreeFinder :: FindOptSTForSpecies( const vector<int> &rows, TreeNode *pnodecurr )
{
	YW_ASSERT_INFO( rows.size() >=1, "Rows can not be empty" );
	set<int> srows;
	PopulateSetByVec(srows, rows);
	//vector<STFinderConfig> listResCfgs;		// currently no use
	if( fLeafLevel0 == true && rows.size() == 1 )
	{
		FindOptSTForSpeciesHt( rows, 0 );;
	}
	else
	{
		// first need to try all possible levels
		for( int grid = 0; grid < numGridSz; ++grid )
		{
			//double ht = grid * szGridStep;
			// find smaller subsets that can combine to form rows 
			if( pnodecurr == NULL)
			{
				FindOptSTForSpeciesHt( rows, grid );

				// YW: 061410, do not prune it anymore. Focus more on stepwise pruning. TBD
				// now prune it
				//storeLinCfgs.PruneCfgs(srows, grid, this->knownUB );
			}
			else
			{
				FindOptSTForSpeciesHt( rows, grid, pnodecurr );
			}
		}
		// see whether we can get rid of some cfgs at different grid
		//storeLinCfgs.PruneCfgsRows( srows );
	}
}

void OptSpeciesTreeFinder :: ProcLeafNodeOpt( int grid, const vector<int> &rows, const set<int> &srows)
{
	// 
	// get label for it
	YW_ASSERT_INFO( rows.size() == 1, "Not leaf" );
	int lbl = rows[0];
	//int iv = lbl;			// node id = lbl ??? Does not really matter, since we will re-label the nodes later
	int sid = storeLinCfgs.CalcSNodeId(srows);
//cout << "sid = " << sid << endl;

	// collect lineage info for each taxa
	//vector<> ;
	vector< set< LineageConfig,LTLinCfg > > lcSetSingle;
	for(int tr=0; tr<GetNumGeneTrees(); ++tr)
	{
		set<int> geneAlleles;
		mgtHelper.GetGeneAllelesForSpecies(tr, lbl, geneAlleles);
//cout << "tree " << tr << ", leaves with this label = ";
//DumpIntSet(geneAlleles);
		LineageConfig linConfig;
		mgtHelper.FormLinConfig(tr, sid, geneAlleles, linConfig );
		linConfig.SetProb(1.0);		// leaves are prob 1.0
		set< LineageConfig,LTLinCfg > ssTemp;
		ssTemp.insert( linConfig );
		lcSetSingle.push_back(ssTemp);
	}

	// find and add all ancestral cfg it is reachable from here
//#ifdef CODE_NEW_STORE_ANC_CFG
	StoreAncestralCfgAt(srows, grid, lcSetSingle);
//#else
	//storeLinCfgs.AddLinCfg(srows, grid, lcSetSingle);
//#endif
}


void OptSpeciesTreeFinder :: FindOptSTForSpeciesHt( const vector<int> &rows, int grid, TreeNode *pncurr )
{
	set<int> srows;
	PopulateSetByVec( srows, rows );
	//STNodeInfo snodeInfo( srows, grid );

	// if size is 1 (i.e. leaf), then we should proceed as it is
	if( rows.size() == 1)
	{
		 ProcLeafNodeOpt( grid, rows, srows);
	}
	else
	{
		YW_ASSERT_INFO( pncurr != NULL, "Can not pass in NULL node" );
		// enumerate all its subsets by try all subsets of species
		// to avoid duplicate, we always select first row
//cout << "Now treat cell for: " ;
//DumpIntVec( posvec );

		// find selected rows
		set<int> rowss1, rowss2;
		// make sure the node has only two leaves
		YW_ASSERT_INFO( pncurr->GetChildrenNum() == 2, "Not a binary tree" );
		GetSpeciesAtNode( pncurr->GetChild(0), rowss1);
		GetSpeciesAtNode( pncurr->GetChild(1), rowss2);

		// figure out what kind of 

		YW_ASSERT_INFO(rowss2.size() + rowss1.size() == rows.size(), "size wrong2" );
		//SplitToSets( rows, const vector<int> &vecItemsSelected, rowss1, rorss2 );

		// find out what kind of LinCfgs we have
		// do nothing if the subsets are not processed
		if( storeLinCfgs.IsLCSetProcessed( rowss1) == false || storeLinCfgs.IsLCSetProcessed( rowss2) == false  )
		{
			return;
		}

		LINCfgsAtGrid & mapCfgASS1 = storeLinCfgs.GetLCSetForTaxa(rowss1);
		LINCfgsAtGrid & mapCfgASS2 = storeLinCfgs.GetLCSetForTaxa(rowss2);
		// iterate over all grid lower (strictly?) tha the current grid
		for( LINCfgsAtGrid :: iterator it1 = mapCfgASS1.begin(); it1 != mapCfgASS1.end(); ++it1 )
		{
			if( it1->first >= grid )
			{
				continue;
			}
			double ht1 = (grid - it1->first)*szGridStep;

			//
			for( LINCfgsAtGrid :: iterator it2 = mapCfgASS2.begin(); it2 != mapCfgASS2.end(); ++it2 )
			{
				if( it2->first >= grid )
				{
					continue;
				}
				double ht2 = (grid - it2->first)*szGridStep;
				// now create all possible combined configs from left and right
				ProcessTwoChoicesFaster( srows, grid, ht1, it1->second, ht2, it2->second );

			}
		}

	}
}

void OptSpeciesTreeFinder :: FindOptSTForSpeciesHt( const vector<int> &rows, int grid )
{
	//double ht =  grid * szGridStep;

	// find rows for Ht
	//listResCfgs.clear();

	// form the nodeinfo
	set<int> srows;
	PopulateSetByVec( srows, rows );
	//STNodeInfo snodeInfo( srows, grid );
	int sid = storeLinCfgs.CalcSNodeId(srows);

	// if size is 1 (i.e. leaf), then we should proceed as it is
	if( rows.size() == 1)
	{
		 ProcLeafNodeOpt( grid, rows, srows);
#if 0
		// 
//cout << "Is leaf\n";
		// get label for it
		int lbl = rows[0];
		//int iv = lbl;			// node id = lbl ??? Does not really matter, since we will re-label the nodes later
		int sid = storeLinCfgs.CalcSNodeId(srows);
//cout << "sid = " << sid << endl;

		// collect lineage info for each taxa
		//vector<> ;
		vector< set< LineageConfig,LTLinCfg > > lcSetSingle;
		for(int tr=0; tr<GetNumGeneTrees(); ++tr)
		{
			set<int> geneAlleles;
			mgtHelper.GetGeneAllelesForSpecies(tr, lbl, geneAlleles);
//cout << "tree " << tr << ", leaves with this label = ";
//DumpIntSet(geneAlleles);
			LineageConfig linConfig;
			mgtHelper.FormLinConfig(tr, sid, geneAlleles, linConfig );
			linConfig.SetProb(1.0);		// leaves are prob 1.0
			set< LineageConfig,LTLinCfg > ssTemp;
			ssTemp.insert( linConfig );
			lcSetSingle.push_back(ssTemp);
		}
		storeLinCfgs.AddLinCfg(srows, grid, lcSetSingle);
#endif
	}
	else
	{
//cout << "Non-leaf\n";
		// combine each possible subset

		// enumerate all its subsets by try all subsets of species
		// to avoid duplicate, we always select first row
		for( int nr = 1; nr < (int)rows.size(); ++nr)
		{
			// only work with processed subsets
			for( set<set<int> > :: iterator itts = listGeneTreeClustersProcessed[nr].begin(); itts != listGeneTreeClustersProcessed[nr].end();  ++itts  )
			{
				// avoid duplicates by (1) the subset must be contained in rows and (2) it contains the last species in the subset
				if(  itts->find(rows[rows.size()-1] ) == itts->end() ||  IsSetContainer(srows, *itts) == false )
				{
					continue;
				}
//cout << "Processing smaller subset: ";
//DumpIntSet(*itts);


			// Now, we enumerate all combinations of nr rows
			// We do this by first get the position vector of each such cases
			//vector<int> posvec;
			//GetFirstCombo( nr, rows.size()-1, posvec );
			//while(true)
			//{
//cout << "Now treat cell for: " ;
//DumpIntVec( posvec );
				// Create a vector, and set the index vector
				//vector<int> subsetIndex;
				//vector<int> subsetRows;
				//GetIntVec(numSpecies, posvec, subsetIndex );
				//subsetRows = posvec;
				// now process this subset of rows
				//FindOptSTForRows( subsetRows );

				// find selected rows
				set<int> rowss1, rowss2;
				rowss1 = *itts;
				//for( int ii=0; ii<(int)posvec.size(); ++ii )
				//{
				//	YW_ASSERT_INFO( posvec[ii] < (int) rows.size(), "Array out of bound" );
				//	rowss1.insert( rows[ posvec[ii] ] );
				//}
				//rowss1.insert( rows[rows.size()-1] );
				// split rows into ss1 and ss2
				//PopulateSetByVec(rowss2, rows);
				rowss2 = srows;
				//YW_ASSERT_INFO(rowss2.size() == rows.size(), "size wrong" );
				SubtractSets( rowss2, rowss1 );
				YW_ASSERT_INFO(rowss2.size() + rowss1.size() == rows.size(), "size wrong2" );
				//SplitToSets( rows, const vector<int> &vecItemsSelected, rowss1, rorss2 );
//if(storeLinCfgs.IsLCSetProcessed( rowss1) == false )
//{
//cout <<"Not processed: ";
//DumpIntSet( rowss1 );
//}
//if(storeLinCfgs.IsLCSetProcessed( rowss2) == false )
//{
//cout <<"Not processed: ";
//DumpIntSet( rowss2 );
//}

				// find out what kind of LinCfgs we have
				//if( listGeneTreeClustersProcessed[rowss2.size()].find(rowss2) != listGeneTreeClustersProcessed[rowss2.size()].end()  )
				if( storeLinCfgs.IsLCSetProcessed( rowss1) == true && storeLinCfgs.IsLCSetProcessed( rowss2) == true )
				{
//cout << "Now processing smaller subset: ";
//DumpIntSet(rowss1);
					
					LINCfgsAtGrid & mapCfgASS1 = storeLinCfgs.GetLCSetForTaxa(rowss1);
					LINCfgsAtGrid & mapCfgASS2 = storeLinCfgs.GetLCSetForTaxa(rowss2);
#ifdef CODE_NEW_STORE_ANC_CFG
					//YW_ASSERT_INFO(mapCfgASS1.find(grid) != mapCfgASS1.end(), "Fail to find the grid points" );
					//YW_ASSERT_INFO(mapCfgASS2.find(grid) != mapCfgASS2.end(), "Fail to find the grid points" );
					if( mapCfgASS1.find(grid) != mapCfgASS1.end() && mapCfgASS2.find(grid) != mapCfgASS2.end())
					{
						for( int iii=0; iii<(int) mapCfgASS1[grid].size(); ++iii )
						{
							for( int jjj=0; jjj<(int) mapCfgASS2[grid].size(); ++jjj  )
							{
								ProcessTwoChoicesStepAnces(sid, srows, grid, mapCfgASS1[grid][iii], mapCfgASS2[grid][jjj] );
							}
						}
					}

#else
	//#if 0
					// 060410
					// collect ancestral cfgs first
					vector< vector<vector<AncLinConfig *> > > vecLeftAncLists;
					vector<double> vecLeftHts;
					//vector<int> vecleftGrid;
					vector< vector<vector<AncLinConfig *> > > vecRightAncLists;
					vector<double> vecRightHts;
					// iterate over all grid lower (strictly?) tha the current grid
					for( LINCfgsAtGrid :: iterator it1 = mapCfgASS1.begin(); it1 != mapCfgASS1.end(); ++it1 )
					{
#ifdef CODE_NEW_STORE_ANC_CFG
						if( it1->first != grid )
						{
							continue;
						}
#else
						if( it1->first >= grid )
						{
							continue;
						}
#endif
						double ht1 = (grid - it1->first)*szGridStep;

						// construct vecLeftAncLists
						for( int pp1 = 0; pp1< (int)it1->second.size(); ++pp1  )
						{
							vector<vector<AncLinConfig *> > configsNewLeft;
							for(int ii=0; ii<(int)it1->second[pp1].size(); ++ii)
							{
					//cout << "ProcessTwoChoices: LEFT cfg num: " << pp1 << ", tree " << ii << ", current LinCfg:\n";
					//for( set<LineageConfig,LTLinCfg>:: iterator ittt=setLCs1[pp1][ii].begin(); ittt!=setLCs1[pp1][ii].end();++ittt )
					//{
					//ittt->Dump();
					//}
								vector<AncLinConfig *>  configsNewLeftStep;
								mgtHelper.FastCollectAncConfig(ii, ht1, it1->second[pp1][ii], configsNewLeftStep  );
								configsNewLeft.push_back(configsNewLeftStep);
					//cout << "Ancestral LEFT config: \n";
					//for(int ppp=0; ppp<(int)configsNewLeftStep.size();++ppp)
					//{
					//configsNewLeftStep[ppp]->Dump();
					//}
							}
							AddandPruneCandidateList(vecLeftAncLists, vecLeftHts, configsNewLeft, ht1);
							//{
							//	vecLeftHts.push_back( ht1 );
							//}
							//vecLeftAncLists.push_back( configsNewLeft );
							//vecLeftHts.push_back( ht1 );
						}

					}
					for( LINCfgsAtGrid :: iterator it2 = mapCfgASS2.begin(); it2 != mapCfgASS2.end(); ++it2 )
					{
#ifdef CODE_NEW_STORE_ANC_CFG
						if( it2->first != grid )
						{
							continue;
						}
#else
						if( it2->first >= grid )
						{
							continue;
						}
#endif
						double ht2 = (grid - it2->first)*szGridStep;

						// construct vecLeftAncLists
						for( int pp1 = 0; pp1< (int)it2->second.size(); ++pp1  )
						{
							vector<vector<AncLinConfig *> > configsNewRight;
							for(int ii=0; ii<(int)it2->second[pp1].size(); ++ii)
							{
					//cout << "ProcessTwoChoices: LEFT cfg num: " << pp1 << ", tree " << ii << ", current LinCfg:\n";
					//for( set<LineageConfig,LTLinCfg>:: iterator ittt=setLCs1[pp1][ii].begin(); ittt!=setLCs1[pp1][ii].end();++ittt )
					//{
					//ittt->Dump();
					//}
								vector<AncLinConfig *>  configsNewRightStep;
								mgtHelper.FastCollectAncConfig(ii, ht2, it2->second[pp1][ii], configsNewRightStep  );
								configsNewRight.push_back(configsNewRightStep);
					//cout << "Ancestral LEFT config: \n";
					//for(int ppp=0; ppp<(int)configsNewLeftStep.size();++ppp)
					//{
					//configsNewLeftStep[ppp]->Dump();
					//}
							}
							//vecRightHts.push_back( ht2 );
							//vecRightAncLists.push_back( configsNewRight );
							AddandPruneCandidateList(vecRightAncLists, vecRightHts, configsNewRight, ht2);
							//{
							//	vecRightHts.push_back( ht2 );
							//}

						}
					}

					// find candidates
					for(int kkkk1=0; kkkk1<(int)vecLeftAncLists.size(); ++kkkk1)
					{
						for(int kkkk2=0; kkkk2<(int)vecRightAncLists.size(); ++kkkk2)
						{
							ProcessTwoChoicesStep(sid, srows, grid, rowss1, vecLeftHts[kkkk1], vecLeftAncLists[kkkk1], vecRightHts[kkkk2], vecRightAncLists[kkkk2]);
						}
					}


					// release memory
					for(int jj1=0; jj1<(int)vecLeftAncLists.size(); ++jj1)
					{
						for(int jj2=0; jj2<(int)vecLeftAncLists[jj1].size(); ++jj2)
						{
							for(int jj3=0; jj3<(int)vecLeftAncLists[jj1][jj2].size(); ++jj3)
							{
								//for(int jj4=0; jj4<(int)vecLeftAncLists[jj1][jj2][jj3].size(); ++jj4)
								//{
								delete vecLeftAncLists[jj1][jj2][jj3];
								//}
							}
						}
					}
					for(int jj1=0; jj1<(int)vecRightAncLists.size(); ++jj1)
					{
						for(int jj2=0; jj2<(int)vecRightAncLists[jj1].size(); ++jj2)
						{
							for(int jj3=0; jj3<(int)vecRightAncLists[jj1][jj2].size(); ++jj3)
							{
								//for(int jj4=0; jj4<(int)vecRightAncLists[jj1][jj2][jj3].size(); ++jj4)
								//{
								delete vecRightAncLists[jj1][jj2][jj3];
								//}
							}
						}
					}

	//#endif
#endif


#if 0
					// iterate over all grid lower (strictly?) tha the current grid
					for( LINCfgsAtGrid :: iterator it1 = mapCfgASS1.begin(); it1 != mapCfgASS1.end(); ++it1 )
					{
						if( it1->first >= grid )
						{
							continue;
						}
						double ht1 = (grid - it1->first)*szGridStep;

						//
						for( LINCfgsAtGrid :: iterator it2 = mapCfgASS2.begin(); it2 != mapCfgASS2.end(); ++it2 )
						{
							if( it2->first >= grid )
							{
								continue;
							}
							double ht2 = (grid - it2->first)*szGridStep;
							// now create all possible combined configs from left and right
							ProcessTwoChoices( srows, grid, ht1, it1->second, ht2, it2->second );

						}
					}
#endif
				}

				// Get the next position
				//if( GetNextCombo( nr, rows.size()-1, posvec ) == false )
				//{
				//	break;
				//}
			}

		}
	}
}

void OptSpeciesTreeFinder :: ProcessTwoChoices( const set<int> &srows, int grid,
											   double ht1, const vector<vector<  set<LineageConfig,LTLinCfg> > > &setLCs1, 
											   double ht2, const vector<vector<  set<LineageConfig,LTLinCfg> > > &setLCs2)
{
	int sid = storeLinCfgs.CalcSNodeId(srows);
//cout << "sid = " << sid << endl;


	//YW_ASSERT_INFO( setLCs1.size() == setLCs2.size(), "ProcessTwoChoices: input size wrong" );

	// search through combination of two partitions: left and right
//	for( vector< vector < set<LineageConfig,LTLinCfg> > > :: iterator it1 = setLCs1.begin(); it1 != setLCs1.end(); ++it1  )
	for( int pp1 = 0; pp1< (int)setLCs1.size(); ++pp1  )
	{
		// find all reachable configs from this AC
		vector<vector<AncLinConfig *> > configsNewLeft;
		for(int ii=0; ii<(int)setLCs1[pp1].size(); ++ii)
		{
//cout << "ProcessTwoChoices: LEFT cfg num: " << pp1 << ", tree " << ii << ", current LinCfg:\n";
//for( set<LineageConfig,LTLinCfg>:: iterator ittt=setLCs1[pp1][ii].begin(); ittt!=setLCs1[pp1][ii].end();++ittt )
//{
//ittt->Dump();
//}
			vector<AncLinConfig *>  configsNewLeftStep;
			mgtHelper.FastCollectAncConfig(ii, ht1, setLCs1[pp1][ii], configsNewLeftStep  );
			configsNewLeft.push_back(configsNewLeftStep);
//cout << "Ancestral LEFT config: \n";
//for(int ppp=0; ppp<(int)configsNewLeftStep.size();++ppp)
//{
//configsNewLeftStep[ppp]->Dump();
//}
		}
//cout << "configsNewLeft.size = " << configsNewLeft.size() << endl;
	

		//for( vector< vector<  set<LineageConfig,LTLinCfg> > > :: iterator it2 = setLCs2.begin(); it2 != setLCs2.end(); ++it2  )
		for(int pp2=0; pp2<(int)setLCs2.size(); ++pp2)
		{
			vector<set<LineageConfig,LTLinCfg> > lcsStep;


			vector<vector<AncLinConfig *> > configsNewRight;
			for(int jj=0; jj<(int)setLCs2[pp2].size(); ++jj)
			{
//cout << "ProcessTwoChoices: RIGHT cfg num: " << pp2 << ", tree " << jj << ", current LinCfg:\n";
//for( set<LineageConfig,LTLinCfg>:: iterator ittt2=setLCs2[pp2][jj].begin(); ittt2!=setLCs2[pp2][jj].end();++ittt2 )
//{
//ittt2->Dump();
//}
				vector<AncLinConfig *>  configsNewRightStep;
				mgtHelper.FastCollectAncConfig( jj, ht2, setLCs2[pp2][jj], configsNewRightStep  );
				configsNewRight.push_back(configsNewRightStep);
//cout << "Ancestral RIGHT config: \n";
//for(int ppp2=0; ppp2<(int)configsNewRightStep.size();++ppp2)
//{
//configsNewRightStep[ppp2]->Dump();
//}
			}
			//gstHelper.FastCollectAncConfig( nodeRight, *it2, configsNewRight  );
//cout << "configsNewRight.size = " << configsNewRight.size() << endl;
			// now let us merge them pairwise to form new cfg
			// append and insert into state depot
			for(int kk=0; kk<(int)configsNewLeft.size(); ++kk)
			{
				set<LineageConfig,LTLinCfg> ssTemp;
				for( int ii=0; ii< (int)configsNewLeft[kk].size();  ++ii )
				{
//cout << "Here\n";
//cout << "Left ances: ";
//configsNewLeft[kk][ii]->Dump();
					for(  int jj = 0; jj<  (int)configsNewRight[kk].size(); ++jj )
					{
//cout << "Right ances: ";
//configsNewRight[kk][jj]->Dump();

						//int iv = 0;		// tmp value for iv

						// form a new one
						LineageConfig lcNew;
						mgtHelper.FormLinConfig(kk, sid,configsNewLeft[kk][ii]->GetLinCfg(),  configsNewRight[kk][jj]->GetLinCfg(), lcNew);
						// setup prob
						lcNew.SetProb(  configsNewLeft[kk][ii]->GetProb()*configsNewRight[kk][jj]->GetProb() );
						//statesDepot[iv].insert( lcNew );
						//storeLinCfgs.AddLinCfg(iv, lcNew );

						// is this cfg new?
						//YW_ASSERT_INFO( lcsStep.find(lcNew) == lcsStep.end(), "Can not happen");
						//{
						// add it
						ssTemp.insert(lcNew);
						//lcsStep.insert(lcNew);
						//}
						//else
						//{
						//	// 
						//}

						//numProc++;
						//if( (numProc % 10000 ) == 0 )
						//{
						//	cout << "Processing " << numProc << "...\n";
						//}
//cout << "After FormLinConfig, find a new LC: ";
//lcNew.Dump();
					}
				}
				lcsStep.push_back(ssTemp);
			}

			// add to the final list
			StoreAncestralCfgAt(srows, grid, lcsStep);
			//storeLinCfgs.AddLinCfg(srows, grid, lcsStep);
		}
	}

	// need to free memory
}



void OptSpeciesTreeFinder :: ProcessTwoChoicesStep( int sid, const set<int> &srows, int grid, const set<int> &srowsLeft,
											   double ht1, vector<vector<AncLinConfig *> > &configsNewLeft, 
											   double ht2, vector<vector<AncLinConfig *> > &configsNewRight)
{
//cout << "sid = " << sid << endl;


	//YW_ASSERT_INFO( setLCs1.size() == setLCs2.size(), "ProcessTwoChoices: input size wrong" );
	YW_ASSERT_INFO( configsNewLeft.size() == configsNewRight.size(), "Wrong" );

	// search through combination of two partitions: left and right
//	for( vector< vector < set<LineageConfig,LTLinCfg> > > :: iterator it1 = setLCs1.begin(); it1 != setLCs1.end(); ++it1  )
	// find all reachable configs from this AC

//cout << "configsNewLeft.size = " << configsNewLeft.size() << endl;

//cout << "configsNewRight.size = " << configsNewRight.size() << endl;
	// now let us merge them pairwise to form new cfg
	// append and insert into state depot
	vector<set<LineageConfig,LTLinCfg> > lcsStep;
	for(int kk=0; kk<(int)configsNewLeft.size(); ++kk)
	{
		set<LineageConfig,LTLinCfg> ssTemp;
		for( int ii=0; ii< (int)configsNewLeft[kk].size();  ++ii )
		{
//cout << "Here\n";
//cout << "Left ances: ";
//configsNewLeft[kk][ii]->Dump();
			for(  int jj = 0; jj<  (int)configsNewRight[kk].size(); ++jj )
			{
//cout << "Right ances: ";
//configsNewRight[kk][jj]->Dump();

				// form a new one
				LineageConfig lcNew;
				mgtHelper.FormLinConfig(kk, sid, configsNewLeft[kk][ii]->GetLinCfg(),  configsNewRight[kk][jj]->GetLinCfg(), lcNew);
				// setup prob
				lcNew.SetProb(  configsNewLeft[kk][ii]->GetProb()*configsNewRight[kk][jj]->GetProb() );
				//statesDepot[iv].insert( lcNew );
				//storeLinCfgs.AddLinCfg(iv, lcNew );

				// is this cfg new?
				//YW_ASSERT_INFO( lcsStep.find(lcNew) == lcsStep.end(), "Can not happen");
				//{
				// add it
				ssTemp.insert(lcNew);

//cout << "After FormLinConfig, find a new LC: ";
//lcNew.Dump();
			}
		}
		lcsStep.push_back(ssTemp);
	}

	// add to the final list
	//storeLinCfgs.AddLinCfg(srows, grid, lcsStep);
	StoreAncestralCfgAt(srows, grid, lcsStep);
	//int gridLeft = GetGrid( ht1 );
	//int gridRight = GetGrid( ht2 );
	//storeLinCfgs.AddLinCfgSrc( srows, grid, srowsLeft, gridLeft, gridRight, lcsStep );
}


void OptSpeciesTreeFinder :: ProcessTwoChoicesStepAnces(int sid, const set<int> &srows, int grid, 
														const vector<  set<LineageConfig,LTLinCfg>  >&setLCs1,
								const  vector<  set<LineageConfig,LTLinCfg> >  &setLCs2)
{
	// we simply combine the two by multiplying the prob here
	YW_ASSERT_INFO( setLCs1.size() == setLCs2.size(), "Wrong" );
	vector<set<LineageConfig,LTLinCfg> > lcsStep;
	for(int kk=0; kk<(int)setLCs1.size(); ++kk)
	{
		set<LineageConfig,LTLinCfg> ssTemp;
		for( set<LineageConfig,LTLinCfg> :: iterator itt1 = setLCs1[kk].begin(); itt1 != setLCs1[kk].end(); ++itt1 )
		{
//cout << "Here\n";
//cout << "Left ances: ";
//configsNewLeft[kk][ii]->Dump();
			for(  set<LineageConfig,LTLinCfg> :: iterator itt2 = setLCs2[kk].begin(); itt2 != setLCs2[kk].end(); ++itt2 )
			{
//cout << "Right ances: ";
//configsNewRight[kk][jj]->Dump();

				// form a new one
				LineageConfig lcNew;
				mgtHelper.FormLinConfig(kk, sid, *itt1,  *itt2, lcNew);
				// setup prob
				lcNew.SetProb(  itt1->GetProb()*itt2->GetProb() );
				//statesDepot[iv].insert( lcNew );
				//storeLinCfgs.AddLinCfg(iv, lcNew );

				// is this cfg new?
				//YW_ASSERT_INFO( lcsStep.find(lcNew) == lcsStep.end(), "Can not happen");
				//{
				// add it
				ssTemp.insert(lcNew);

//cout << "After FormLinConfig, find a new LC: ";
//lcNew.Dump();
			}
		}
		lcsStep.push_back(ssTemp);
	}

	// add to the final list
	//storeLinCfgs.AddLinCfg(srows, grid, lcsStep);
	StoreAncestralCfgAt(srows, grid, lcsStep);
}



// hopefully a faster implementation of finding config for the two source cfgs
void OptSpeciesTreeFinder :: ProcessTwoChoicesFaster( const set<int> &srows, int grid,
											   double ht1, const vector<vector<  set<LineageConfig,LTLinCfg> > > &setLCs1, 
											   double ht2, const vector<vector<  set<LineageConfig,LTLinCfg> > > &setLCs2)
{
	int sid = storeLinCfgs.CalcSNodeId(srows);
//cout << "sid = " << sid << endl;


	//YW_ASSERT_INFO( setLCs1.size() == setLCs2.size(), "ProcessTwoChoices: input size wrong" );

	// search through combination of two partitions: left and right



	vector<vector<vector<AncLinConfig *> > > listConfigsNewLeft;
	vector<vector<vector<AncLinConfig *> > > listConfigsNewRight;


//	for( vector< vector < set<LineageConfig,LTLinCfg> > > :: iterator it1 = setLCs1.begin(); it1 != setLCs1.end(); ++it1  )
	for( int pp1 = 0; pp1< (int)setLCs1.size(); ++pp1  )
	{
		// find all reachable configs from this AC
		vector<vector<AncLinConfig *> > configsNewLeft;
		for(int ii=0; ii<(int)setLCs1[pp1].size(); ++ii)
		{
//cout << "ProcessTwoChoices: LEFT cfg num: " << pp1 << ", tree " << ii << ", current LinCfg:\n";
//for( set<LineageConfig,LTLinCfg>:: iterator ittt=setLCs1[pp1][ii].begin(); ittt!=setLCs1[pp1][ii].end();++ittt )
//{
//ittt->Dump();
//}
			vector<AncLinConfig *>  configsNewLeftStep;
			mgtHelper.FastCollectAncConfig(ii, ht1, setLCs1[pp1][ii], configsNewLeftStep  );
			configsNewLeft.push_back(configsNewLeftStep);
//cout << "Ancestral LEFT config: \n";
//for(int ppp=0; ppp<(int)configsNewLeftStep.size();++ppp)
//{
//configsNewLeftStep[ppp]->Dump();
//}
		}
		// save it
		listConfigsNewLeft.push_back(configsNewLeft);
//cout << "configsNewLeft.size = " << configsNewLeft.size() << endl;
	}
	for( int pp2 = 0; pp2< (int)setLCs2.size(); ++pp2  )
	{
		// find all reachable configs from this AC
		vector<vector<AncLinConfig *> > configsNewRight;
		for(int ii=0; ii<(int)setLCs2[pp2].size(); ++ii)
		{
//cout << "ProcessTwoChoices: LEFT cfg num: " << pp1 << ", tree " << ii << ", current LinCfg:\n";
//for( set<LineageConfig,LTLinCfg>:: iterator ittt=setLCs1[pp1][ii].begin(); ittt!=setLCs1[pp1][ii].end();++ittt )
//{
//ittt->Dump();
//}
			vector<AncLinConfig *>  configsNewRightStep;
			mgtHelper.FastCollectAncConfig(ii, ht2, setLCs2[pp2][ii], configsNewRightStep  );
			configsNewRight.push_back(configsNewRightStep);
//cout << "Ancestral LEFT config: \n";
//for(int ppp=0; ppp<(int)configsNewLeftStep.size();++ppp)
//{
//configsNewLeftStep[ppp]->Dump();
//}
		}
		// save it
		listConfigsNewRight.push_back(configsNewRight);
//cout << "configsNewLeft.size = " << configsNewLeft.size() << endl;
	}

	// test how to combine the two parts
	for(int tt1=0; tt1<(int)listConfigsNewLeft.size(); ++tt1)
	{
		for(int tt2=0; tt2<(int)listConfigsNewRight.size(); ++tt2)
		{
			YW_ASSERT_INFO( listConfigsNewLeft[tt1].size() ==  listConfigsNewRight[tt2].size(), "Size mismatch");
			vector<set<LineageConfig,LTLinCfg> > lcsStep;
			for(int kk=0; kk<(int)listConfigsNewLeft[tt1].size(); ++kk)
			{
				set<LineageConfig,LTLinCfg> ssTemp;
				for( int ii=0; ii< (int)listConfigsNewLeft[tt1][kk].size();  ++ii )
				{
//cout << "Here\n";
//cout << "Left ances: ";
//configsNewLeft[kk][ii]->Dump();
					for(  int jj = 0; jj<  (int)listConfigsNewRight[tt2][kk].size(); ++jj )
					{
//cout << "Right ances: ";
//configsNewRight[kk][jj]->Dump();

						//int iv = 0;		// tmp value for iv

						// form a new one
						LineageConfig lcNew;
						mgtHelper.FormLinConfig(kk, sid,listConfigsNewLeft[tt1][kk][ii]->GetLinCfg(),  listConfigsNewRight[tt2][kk][jj]->GetLinCfg(), lcNew);
						// setup prob
						lcNew.SetProb(  listConfigsNewLeft[tt1][kk][ii]->GetProb()*listConfigsNewRight[tt2][kk][jj]->GetProb() );
						//statesDepot[iv].insert( lcNew );
						//storeLinCfgs.AddLinCfg(iv, lcNew );

						// is this cfg new?
						//YW_ASSERT_INFO( lcsStep.find(lcNew) == lcsStep.end(), "Can not happen");
						//{
						// add it
						ssTemp.insert(lcNew);
						//lcsStep.insert(lcNew);
						//}
						//else
						//{
						//	// 
						//}

						//numProc++;
						//if( (numProc % 10000 ) == 0 )
						//{
						//	cout << "Processing " << numProc << "...\n";
						//}
//cout << "After FormLinConfig, find a new LC: ";
//lcNew.Dump();
					}
				}
				lcsStep.push_back(ssTemp);
			}
			// add to the final list
			//storeLinCfgs.AddLinCfg(srows, grid, lcsStep);
			StoreAncestralCfgAt(srows, grid, lcsStep);
		}
	}
		

	// need to free memory
	// 
	for(int i=0; i<(int)listConfigsNewLeft.size(); ++i)
	{
		for(int j=0; j<(int)listConfigsNewLeft[i].size(); ++j)
		{
			for(int k=0; k<(int)listConfigsNewLeft[i][j].size(); ++k)
			{
				delete listConfigsNewLeft[i][j][k];
			}
		}
	}
	for(int i=0; i<(int)listConfigsNewRight.size(); ++i)
	{
		for(int j=0; j<(int)listConfigsNewRight[i].size(); ++j)
		{
			for(int k=0; k<(int)listConfigsNewRight[i][j].size(); ++k)
			{
				delete listConfigsNewRight[i][j][k];
			}
		}
	}
}


bool OptSpeciesTreeFinder :: AddandPruneCandidateList(vector< vector<vector<AncLinConfig *> > > &vecAncCandidates, 
													  vector<double> &vecDist, vector<vector<AncLinConfig *> > &itemNew, double htNew )
{
	// return true if added, false if not added
//cout << "Before pruning in PruneCandidateList size: " << vecAncCandidates.size() << endl;
	//
	vector< vector<set<LineageConfig,LTLinCfg> > >  vecAncCandSets(vecAncCandidates.size());
	vector<double> vecDistNew;
	for(int i=0; i<(int)vecAncCandidates.size(); ++i  )
	{
		vecAncCandSets[i].resize( vecAncCandidates[i].size() );
		// insert the corresponding
		for(int j=0; j<(int)vecAncCandidates[i].size(); ++j)
		{
			//for( set<LineageConfig,LTLinCfg> :: iterator it = vecAncCandidates[i][j].begin(); it != vecAncCandidates[i][j].end(); ++it  )
			for(int k=0; k<(int)vecAncCandidates[i][j].size(); ++k)
			{
				YW_ASSERT_INFO( vecAncCandSets[i][j].find( vecAncCandidates[i][j][k]->GetLinCfg()  ) == vecAncCandSets[i][j].end(), "Wrong1" );
				vecAncCandSets[i][j].insert(vecAncCandidates[i][j][k]->GetLinCfg()  );
			}
		}
	}
	vector<set<LineageConfig,LTLinCfg> > itemNewCfg(itemNew.size() );
	for(int j=0; j<(int)itemNew.size(); ++j)
	{
		//for( set<LineageConfig,LTLinCfg> :: iterator it = vecAncCandidates[i][j].begin(); it != vecAncCandidates[i][j].end(); ++it  )
		for(int k=0; k<(int)itemNew[j].size(); ++k)
		{
			YW_ASSERT_INFO( itemNewCfg[j].find( itemNew[j][k]->GetLinCfg()  ) == itemNewCfg[j].end(), "Wrong2" );
			itemNewCfg[j].insert(itemNew[j][k]->GetLinCfg() );
		}
	}
//cout << "Here\n";
	//YW_ASSERT_INFO( vecAncCandidates.size() ==  );
	// 
	vector< vector<vector<AncLinConfig *> > > vecAncCandidatesNew;
	vector<bool> vecToKeep;
	//
	//skip if any
	bool fPoor = false;
	for( int i=0; i<(int)vecAncCandidates.size(); ++i )
	{
		bool fKept = false;
		if( storeLinCfgs.IsLinCfgsBetter(itemNewCfg, vecAncCandSets[i] ) == false )
		{
			fKept = true;;
		}
		else
		{
			// 
//cout << "This original item is beaten\n";
		}

		// for a technical reason: need to ensure consistency of the height
		// we do not prune those already in the list. LATER>>>
		// TBD. YW: 060410
		//bool fKept = true;
		vecToKeep.push_back( fKept );

		if( storeLinCfgs.IsLinCfgsBetter( vecAncCandSets[i], itemNewCfg ) ==  true )
		{
			fPoor = true;
			break;
		}
	}
	// do nothing if this is a poor choice
	if( fPoor == true )
	{
//cout << "AddandPruneCandidateList: item poor\n";
		// free the buffer
		for(int ii=0; ii<(int)itemNew.size(); ++ii)
		{
			for(int jj=0; jj<(int)itemNew[ii].size(); ++jj)
			{
				delete itemNew[ii][jj];
			}
		}
//cout << "---this cfg is skipped\n";
		return false;
	}
//cout << "here\n";
	// 
	for(int ii=0; ii<(int)vecToKeep.size(); ++ii)
	{
		if( vecToKeep[ii] == true )
		{
			vecAncCandidatesNew.push_back( vecAncCandidates[ii] );
			vecDistNew.push_back( vecDist[ii] );
		}
		else
		{
			// free up the buffer
			for(int kk=0; kk<(int)vecAncCandidates[ii].size(); ++kk)
			{
				for(int jj=0; jj<(int)vecAncCandidates[ii][kk].size(); ++jj)
				{
					delete vecAncCandidates[ii][kk][jj];
				}
			}
		}
	}

	// need to add it
	vecAncCandidatesNew.push_back( itemNew );
	vecDistNew.push_back( htNew );
	vecAncCandidates = vecAncCandidatesNew;
	vecDist = vecDistNew;
//cout << "After pruning in PruneCandidateList size: " << vecAncCandidates.size() << endl;
	return true;
}


void OptSpeciesTreeFinder :: StoreAncestralCfgAt(const set<int> &srows, int gridCurr, vector< set< LineageConfig,LTLinCfg > > &lcSetSingle)
{
	// 
#ifdef CODE_NEW_STORE_ANC_CFG
	// at current grid point, store it and then find out what nodes are reachable
	storeLinCfgs.AddLinCfg(srows, gridCurr, lcSetSingle);


	// find all ancestral relationship at grid upper wards, and store those instead
	for( int grid = gridCurr+1; grid < numGridSz; ++grid )
	{
		// perform extension for each of the grid
		double ht1 = (grid - gridCurr)*szGridStep;

		// construct vecLeftAncLists
		vector<vector<AncLinConfig *> > configsNewLeft;
		for(int ii=0; ii<(int)lcSetSingle.size(); ++ii)
		{
//cout << "ProcessTwoChoices: LEFT cfg num: " << pp1 << ", tree " << ii << ", current LinCfg:\n";
//for( set<LineageConfig,LTLinCfg>:: iterator ittt=setLCs1[pp1][ii].begin(); ittt!=setLCs1[pp1][ii].end();++ittt )
//{
//ittt->Dump();
//}
			vector<AncLinConfig *>  configsNewLeftStep;
			mgtHelper.FastCollectAncConfig(ii, ht1, lcSetSingle[ii], configsNewLeftStep  );
			configsNewLeft.push_back(configsNewLeftStep);
//cout << "Ancestral LEFT config: \n";
//for(int ppp=0; ppp<(int)configsNewLeftStep.size();++ppp)
//{
//configsNewLeftStep[ppp]->Dump();
//}
		}


		//AddandPruneCandidateList(vecLeftAncLists, vecLeftHts, configsNewLeft, ht1);
		//{
		//	vecLeftHts.push_back( ht1 );
		//}
		//vecLeftAncLists.push_back( configsNewLeft );
		//vecLeftHts.push_back( ht1 );


		vector<set<LineageConfig,LTLinCfg> >  vecAncCandSets(configsNewLeft.size());
		//vector<double> vecDistNew;
		for(int i=0; i<(int)configsNewLeft.size(); ++i  )
		{
			//vecAncCandSets[i].resize( configsNewLeft[i].size() );
			// insert the corresponding
			for(int j=0; j<(int)configsNewLeft[i].size(); ++j)
			{
				//for( set<LineageConfig,LTLinCfg> :: iterator it = vecAncCandidates[i][j].begin(); it != vecAncCandidates[i][j].end(); ++it  )
				//for(int k=0; k<(int)vecAncCandidates[i][j].size(); ++k)
				//{
				YW_ASSERT_INFO( vecAncCandSets[i].find( configsNewLeft[i][j]->GetLinCfg()  ) == vecAncCandSets[i].end(), "Wrong1" );
				vecAncCandSets[i].insert(configsNewLeft[i][j]->GetLinCfg()  );
				//}
			}
		}

		// add this into cfg
		storeLinCfgs.AddLinCfg(srows, grid, vecAncCandSets);
		
	}

#else
	// simply store the current 
	storeLinCfgs.AddLinCfg(srows, gridCurr, lcSetSingle);
#endif
}

int OptSpeciesTreeFinder :: GetGrid(double ht) const
{
	const double RATIO_SMALL = 1.0000000000001;
	return (int)(ht*RATIO_SMALL/szGridStep);
}

