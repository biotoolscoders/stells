#ifndef OPT_SPECIES_TREE_FINDER_H
#define OPT_SPECIES_TREE_FINDER_H

#include "GeneSpeciesTreeProb.h"

// Problem: given a set of binary gene trees (which assumes to be indpendent), only topology and ignore branch length
// find the species tree (binary, topology plus branch length) that maximize the product of prob. of obsering each gene
// tree on this species tree
// Thus, this is a MLE scheme


//////////////////////////////////////////////////////////////////////////////////
// useful data structure


//////////////////////////////////////////////////////////////////////////////////
// what configuration
void SetMaxKeptCfgsLimit(int limit);


//////////////////////////////////////////////////////////////////////////////////
// configuration for a subset of 

//class STFinderConfig
//{
//public:
//	STFinderConfig() {}
//	~STFinderConfig() {}
//
//	// editing: add a set of config
//	void AddLinCfgs( const set<LineageConfig> &sLinCfgs );
//	void AddSingleLinCfg(const LineageConfig &lcfg);
//
//	// is this config better than the given one?
//	bool IsBetter(const STFinderConfig& rhs);
//
//private:
//	
//	// what ancestral cfgs do we have?
//	// need a list to represent cfgs for multiple tree
//	vector< set< LineageConfig > > listSetLinCfgs;
//};




//////////////////////////////////////////////////////////////////////////////////

class MultiGeneTreeHelper
{
public:
	MultiGeneTreeHelper();
	~MultiGeneTreeHelper();

	// config
	void SetNumSpecies( int nS ) { numSpecies = nS; }
	void CollectSpecies();
	void AppendGTree( PhylogenyTreeBasic *ptrGT );

	// briding to single tree operation
	void FormLinConfig(int tr, int snid, const set<int> &linsGT, LineageConfig &linConfig ) const;
	void FormLinConfig(int tr, int snid, const LineageConfig &linsGT1, const LineageConfig &linsGT2, LineageConfig &linConfig ) const;
	void GetGeneAllelesForSpecies(int gt, int taxon, set<int> &geneAlleles);
	void FastCollectAncConfig( int tr, double lenOrig, const set<LineageConfig,LTLinCfg> &setOrigCfgs, vector< AncLinConfig *> &listAncCfgsNew );
	int GetRootIdGT(int tr); 
	double CalcCoalCoeffForTwoCfg( int tr, const LineageConfig &linCfg1, const LineageConfig &linCfg2 ) const;
	double CalcCoalProbBranch( int tr, int u, int v, double len ) const;

	// querying
	int GetNumGTrees() const { return listGTHelperPtrs.size(); }
	int GetNumSpecies() const { return numSpecies; }
	void GetSpeciesSet(set<int> &sp) const { PopulateSetByVec( sp, setSpecies ); }
	GeneSpeciesTreeHelper *GetGTHelperPtr(int tr) const;
	void GetSpeciesAt(const vector<int> &speciesPos, vector<int> &species  );
	//int GetRootIdGT(int k) { return listGTHelperPtrs[k]->GetRootIdGT(); }
	void FormRootCfgAt(int k, LineageConfig &finalLC)
	{
		LineageCluster flc;
		int rtGT = GetRootIdGT(k);
		flc.Init(rtGT, 1, -1);
		finalLC.AddLC( flc );
	}

private:
	int numSpecies;
	vector<int> setSpecies;			// set of species stored in the trees (note: must be identical to all given gene trees)
	vector<GeneSpeciesTreeHelper *> listGTHelperPtrs;
	MarginalTree dummyTreeSpecies;
};


//////////////////////////////////////////////////////////////////////////////////
// stores for intermediate configurations
//class STNodeInfo
//{
//public:
//	STNodeInfo( const set<int> &sss, int level  ) : subsetSpecies( sss), level( gridLevel ) {}
//
//private:
//
//	//int grid;
//	set<int> subsetSpecies;
//	int gridLevel;
//} ; 

// <grid position, list of config at this height/subset of taxa<  list of trees<>  > >
typedef map<int, vector< vector<set<LineageConfig,LTLinCfg> >  > > LINCfgsAtGrid;

//#if 0
typedef struct
{
	vector<set< LineageConfig,LTLinCfg> > cfgsLeft;
	vector<set< LineageConfig,LTLinCfg> > cfgsRight;
	set<int>  speciesLeft;
	set<int>  speciesRight;
	int gridLeft;
	int gridRight;
} LINCFG_SRC_INFO;
//#endif


class STFinderConfigStore
{
public:
	// 
	STFinderConfigStore();
	~STFinderConfigStore();

	void SetTreeHelper(MultiGeneTreeHelper *pMGTH) {gstHelperPtr = pMGTH; }
	void SetGridInfo(double gridLen) {szGridStep = gridLen;}


	// add a record of LinCfg: for the purpose of computing the probablity, need to know which
	// LinCfg it derives from. For leaves, we also support a plain version: with no probility
	void AddLinCfg( const set<int>& staxa, int grid, vector<set< LineageConfig,LTLinCfg> > &lcsNew );
	//void AddLinCfgSrc( const set<int> &srows, int grid, const set<int> &srowsLeft, 
	//									  int gridLeft, int gridRight, vector<set<LineageConfig,LTLinCfg> > &lcsTot );

	int GetNumLinCfgsAt( const set<int> &nodeId) ;
	int GetNumLinCfgsAtGrid( const set<int> &nodeId, int grid);
	void DumpCfgsAt( const set<int> &nodeId) ;
	void DumpCfgsStatisticsAt( const set<int> &nodeId);
	double CalcTotProbAt(const set<int> &nodesRoot);
	void PruneCfgs(const set<int>& staxa, int grid, double probCurEst);
	void PruneCfgsRows(const set<int>& staxa);
	//bool IsCfgInferior( const set<int>& staxa, int grid, vector<set< LineageConfig,LTLinCfg> > &lcsNew   );
	void TraceBackBuildTree( const set<int> &nodesRoot, MarginalTree &treeOpt );
	void PruneLessLikeliCfgs(vector< vector<  set<LineageConfig,LTLinCfg> > >  &listCfgsTest) const;

	//double CalcTotProbAt(int nodeId);
	//void DumpConfigsAt(int nodeId);
	LINCfgsAtGrid &GetLCSetForTaxa(  const set<int> &ss ) 
	{
		YW_ASSERT_INFO( mapConfigForNodes.find(ss) != mapConfigForNodes.end(), "Fail to find1.4" );
		return mapConfigForNodes[ss];
	}
	//set< LineageConfig,LTLinCfg > & GetLCSetAt(int node)
	//{
	//	YW_ASSERT_INFO( statesDepot.find(node) != statesDepot.end(), "Fail to find" );
	//	return statesDepot[node];
	//}
	//void SetLCSetAt(int node, set< LineageConfig,LTLinCfg > &setCfgs)
	//{
	//	if( statesDepot.find(node) == statesDepot.end() )
	//	{
	//		statesDepot.insert( map<int, set< LineageConfig,LTLinCfg > > :: value_type( node, setCfgs )  );
	//	}
	//	else
	//	{
	//		statesDepot[node] = setCfgs;
	//	}
	//}
	void Reset() { mapConfigForNodes.clear(); numSkippedCfgs=0; numBeteanCfgs = 0;}
	int CalcSNodeId( const set<int> &staxa );
	void DumpStatistics() const;
	bool IsLinCfgsBetter(const vector<set<LineageConfig,LTLinCfg> > &sLinNew1, const vector<set<LineageConfig,LTLinCfg> > &sLinNew2) const;
	bool IsLCSetProcessed(  const set<int> &ss ) 
	{
		return mapConfigForNodes.find(ss) != mapConfigForNodes.end();
	}

private:
	// impl functions
	void AppendLinCfgsTo( vector<vector<  set<LineageConfig,LTLinCfg> > > &listSLinCfgs, const vector<set<LineageConfig,LTLinCfg> > &sLinNew ) const;
	bool IsCfgBetter(  vector<set<LineageConfig,LTLinCfg> > &cfgBetter, int grid1, vector<set<LineageConfig,LTLinCfg> >  &cfgWorse, int grid2);
	bool IsLinCfgsBetter(const set<LineageConfig,LTLinCfg> &sLinNew1, const set<LineageConfig,LTLinCfg> &sLinNew2) const;
	void IncNumSkipped() {numSkippedCfgs++;}
	void IncNumBeaten() {numBeteanCfgs++;}
	void IncNumExamedCfgs() {numTotExamedCfgs++;}
	double GetGridSize() const { return szGridStep; }
	double GetDistGrid(int gupper, int glower) { YW_ASSERT_INFO( gupper >= glower, "Fail in GetDistGrid" ); return (gupper-glower)*GetGridSize(); }
	void FindOptSubsets(const set<int> &setTot, int grid, const vector<set<LineageConfig,LTLinCfg> >& cfgsTot, LINCFG_SRC_INFO &cfgSrcInfo );
	bool AreTwoCfgsSame( const vector<set<LineageConfig,LTLinCfg> >& listCfg1, const vector<set<LineageConfig,LTLinCfg> >& listCfg2 );
	void BuildTreeByBranching( const set<int> &nodesRoot, int rootGrid, MarginalTree &treeOpt, map< set<int>, LINCFG_SRC_INFO >  &mapBranchingSave );
	string GetNewickStrForBranching( const set<int> &setTaxa, int gridCur, map< set<int>, LINCFG_SRC_INFO >  &mapBranchingSave );

	// data items
	MultiGeneTreeHelper *gstHelperPtr;
	// list of items to store for each subset of nodes
	map< set<int>, LINCfgsAtGrid >  mapConfigForNodes;
	//map< vector<set< LineageConfig,LTLinCfg> >*,  LINCFG_SRC_INFO > mapConfigSrc; 

	// some auxilary statistics
	int numSkippedCfgs;		// # of cfgs not made into the list when trying to insert
	int numBeteanCfgs;		// # of cfgs kicked out by new inserts
	int numTotExamedCfgs;
	double szGridStep;
};



//////////////////////////////////////////////////////////////////////////////////

class OptSpeciesTreeFinder
{
public:
	// need a list of gene trees
	OptSpeciesTreeFinder( const vector<PhylogenyTreeBasic *> &listGTreePtrs );

	// config functions
	void SetNumSpecies( int numSpecies ) { mgtHelper.SetNumSpecies( numSpecies ); }
	void SetApproxFlag(bool f) { fTrimmedRowsSpace  = f; }


	// return the MLE prob value
	double FindOptST( MarginalTree &mleST );
	double FindOptBranchLen( PhylogenyTreeBasic &streeTopology, MarginalTree &mleST );


private:
	// during init, we perform a quick search
	void Init();

	// implementation methods
	int GetNumGeneTrees() const { return listGTreePtrs.size(); }
	void FindOptSTForSpecies( const vector<int> &rows, TreeNode *pnodecurr = NULL );
	void FindOptSTForSpeciesHt( const vector<int> &rows, int grid );
	void ProcessTwoChoices( const set<int> &rows, int grid, double ht1, const vector<vector<  set<LineageConfig,LTLinCfg> > > &setLCs1, 
											   double ht2, const vector<vector<  set<LineageConfig,LTLinCfg> > > &setLCs2);
	void ProcessTwoChoicesFaster( const set<int> &srows, int grid,
											double ht1, const vector<vector<  set<LineageConfig,LTLinCfg> > > &setLCs1, 
											   double ht2, const vector<vector<  set<LineageConfig,LTLinCfg> > > &setLCs2);

	void ProcessTwoChoicesStep( int sid, const set<int> &srows, int grid, const set<int> &srowsLeft,
											   double ht1, vector<vector<AncLinConfig *> > &configsNewLeft, 
											   double ht2, vector<vector<AncLinConfig *> > &configsNewRight);
	void ProcessTwoChoicesStepAnces(int sid, const set<int> &srows, int grid, const vector< set<LineageConfig,LTLinCfg> > &setLCs1,
								const vector<  set<LineageConfig,LTLinCfg> > &setLCs2);

	// common subroutines
	void FindOptSTForSpeciesHt( const vector<int> &rows, int grid, TreeNode *pncurr );
	void ProcLeafNodeOpt( int grid, const vector<int> &rows, const set<int> &srows);
	//bool AddandPruneCandidateList(vector< vector<vector<AncLinConfig *> > > &vecAncCandidates, vector<vector<AncLinConfig *> > &itemNew );
	bool AddandPruneCandidateList(vector< vector<vector<AncLinConfig *> > > &vecAncCandidates, 
													  vector<double> &vecDist, vector<vector<AncLinConfig *> > &itemNew, double htNew );
	void StoreAncestralCfgAt(const set<int> &srows, int grid, vector< set< LineageConfig,LTLinCfg > > &lcSetSingle);
	int GetGrid(double ht) const;


	/////////////////////////////////////////////////////////////////////////
	// search information 
	vector<PhylogenyTreeBasic *> listGTreePtrs;
	MultiGeneTreeHelper mgtHelper;
	STFinderConfigStore storeLinCfgs;

	// range of search
	int numGridSz;					// how many levels of points to place?
	double szGridStep;				// how far between the grid step
	bool fLeafLevel0;				// start from leve 0.0 for all leaves?
	double knownUB;					// a known solution with this has been derived before
	bool fTrimmedRowsSpace;			// do we start with some smaller subsets of rows
	vector< set< set<int> > > listGeneTreeClustersProcessed;		// store what ever we have in the clusters
};



#endif
