//
//  NexusUtils.cpp
//  
//
//  Created by Yufeng Wu on 5/7/15.
//
//

#include "NexusUtils.h"
#include <fstream>
#include <cstdlib>
#include <sstream>

//*****************************************************************************
// Alignment


MSAMatrix :: MSAMatrix()
{
    //
}

MSAMatrix :: MSAMatrix(const MSAMatrix &rhs) : listSeqs(rhs.listSeqs), listSeqNames(rhs.listSeqNames), mapNameToIndices(rhs.mapNameToIndices)
{
    // 
}

void MSAMatrix :: Init(int numSeqs, int numChars)
{
    //
    listSeqs.clear();
    listSeqs.resize( numSeqs );
    for(int i=0; i<numSeqs; ++i)
    {
        listSeqs[i].resize(numChars);
    }
    listSeqNames.clear();
    for(int i=0; i<numSeqs; ++i)
    {
        string nm = "EMPTY";
        listSeqNames.push_back(nm);
    }
    mapNameToIndices.clear();
}

void MSAMatrix :: SetCharAt(int seq, int pos, char ch)
{
    //
    listSeqs[seq][pos] = ch;
}

char MSAMatrix :: GetCharAt(int seq, int pos) const
{
    //
    return listSeqs[seq][pos];
}

void MSAMatrix :: SetSeqName(int seq, const string &name)
{
    //
    listSeqNames[seq] = name;
    
    // also store the other direction for quick checking
    mapNameToIndices.insert( map<string,int> :: value_type(name,seq) );
}

string MSAMatrix :: GetSeqName(int seq) const
{
    //
    return listSeqNames[seq];
}

int MSAMatrix :: GetSeqIndex(const string &name) const
{
    //
    MSAMatrix *pthis = const_cast<MSAMatrix *>(this);
    return pthis->mapNameToIndices[name];
}

void MSAMatrix :: Dump() const
{
    //
    for(int i=0; i<GetNumSeqs(); ++i)
    {
        cout << listSeqNames[i] << "  ";
        for(int j=0; j<GetNumChars(); ++j)
        {
            cout << listSeqs[i][j];
        }
        cout << endl;
    }
    cout <<"Sequence name info: ";
    for(map<string,int> :: const_iterator it = mapNameToIndices.begin(); it != mapNameToIndices.end(); ++it)
    {
        cout << "<" << it->first << ", " << it->second << ">  ";
    }
    cout << endl;
}

//*****************************************************************************
// Nexus file reader into an MSAMatrix


NexusAlignmentIO :: NexusAlignmentIO()
{
    //
}

void NexusAlignmentIO :: ReadFromFileTrimFormat(const char *filename, vector<MSAMatrix> &listMSAs)
{
    listMSAs.clear();
    
    // format: trimmed down NEXUS format
    // seperate different MSA by one or more #### in the first char of the line
    // then follow by the number of rows and columns
    // then each line like: <species name>   <sequence in ACGT>
    ifstream fileIn( filename );
    if(!fileIn)
	{
		cout << "Can not open Nexus file: "<< filename <<endl;
		exit(1);
	}
    
    // read line by line
    // read marginal trees in newick format
	// here there is no preamble, one line per tree
    MSAMatrix msaCur;
    bool modeHeader = true;
    int seqIndex = 0;
    
	while( fileIn.eof() == false )
	{
        const int SZ_BUF = 102400;
        char buf[SZ_BUF];
        fileIn.getline(buf, SZ_BUF);
		string strText(buf);
		if( strText.size() == 0 )
		{
			continue;
		}
//cout << "strText: " << strText << endl;
        
        // start a new MSA if find a line start w/ #
        if( strText[0] == '#')
        {
            modeHeader = true;
            
            // add the current msa if not empty
            if( msaCur.IsEmpty() ==false )
            {
                listMSAs.push_back(msaCur);
            }
        }
        else if( modeHeader == true)
        {
            int numSeqs = 0, numChars = 0;
            std::stringstream ss(strText);
            ss >> numSeqs >> numChars;
            msaCur.Init(numSeqs, numChars);
//cout << "numSeqs: " << numSeqs << ", numChars: " << numChars << endl;
            modeHeader = false;
            seqIndex = 0;
        }
        else
        {
            // now read in the sequences
            string sname, seqcur;
            std::stringstream ss(strText);
            ss >> sname >> seqcur;
//cout << "Sname: " << sname << endl;
            for(int i=0; i<(int)seqcur.length(); ++i)
            {
                msaCur.SetCharAt( seqIndex, i, seqcur[i] );
            }
            msaCur.SetSeqName( seqIndex, sname );
            ++seqIndex;
//cout << "SeqIndex: " << seqIndex << endl;
        }
        
    }
    
    // add the current msa if not empty
    if( msaCur.IsEmpty() ==false )
    {
        listMSAs.push_back(msaCur);
    }
    
    
    fileIn.close();
}


