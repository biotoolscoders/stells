#include "SpeciesTreeExplorer.h"
#include "STBranchLenFinder.h"



//////////////////////////////////////////////////////////////////////////////////
// Finding candidate trees from a single tree through NNI


// take a single tree and explore its NNI trees
NNINgbrTreesFinder :: NNINgbrTreesFinder(PhylogenyTreeBasic &stcur) : speciesTreeCur( stcur )
{
}

// find NNI neighbor trees (represented by Newick)
void NNINgbrTreesFinder :: Find(set<string> &setNgbrNWTrees)
{
	setNgbrNWTrees.clear();
	// iterate each non-leaf node
	PhylogenyTreeIterator itorPT(speciesTreeCur);
	itorPT.Init();
	while( itorPT.IsDone() == false )
	{
		TreeNode *pntree = itorPT.GetCurrNode();
		// only consider non-leaf and non-root
		if( pntree->IsLeaf() == false  &&  pntree != speciesTreeCur.GetRoot() )
		{
			// try to move it around
			vector<TreeNode *> listSibs;
			pntree->GetSiblings(listSibs);
			// only work with binary tree for now
			YW_ASSERT_INFO( listSibs.size() == 1, "Tree not binary" );
			TreeNode *pnsib = listSibs[0];
			YW_ASSERT_INFO( pntree->GetChildrenNum() == 2, "Not binary tree. Wrong" );
			TreeNode *pnchild1 = pntree->GetChild(0);
			TreeNode *pnchild2 = pntree->GetChild(1);

			// perform temp change of parent-ship and get Newick
			string nwtreetmp1;
			GetTempChangedTreeAt( pnsib, pnchild1, nwtreetmp1 );
			string nwtreetmp2;
			GetTempChangedTreeAt( pnsib, pnchild2, nwtreetmp2 );

			// add to record
			setNgbrNWTrees.insert(nwtreetmp1);
			setNgbrNWTrees.insert(nwtreetmp2);
		}

		// move on to next
		itorPT.Next();
	}
}



// temparary change the tree by swapping the two nodes and get the modified tree
void NNINgbrTreesFinder :: GetTempChangedTreeAt( TreeNode *tnchange1, TreeNode *tnchange2, string & nwtreetmp )
{
	// keep track of nodes so we can detach and attach it
	TreeNode *pncpar1 = tnchange1->GetParent();
	TreeNode *pncpar2 = tnchange2->GetParent();
	YW_ASSERT_INFO(pncpar1 != NULL && pncpar2 != NULL, "Can not swap nodes if parents are null");
	pncpar1->RemoveChild(tnchange1);
	pncpar2->RemoveChild(tnchange2);
	vector<int> labelsEmpty;
	pncpar1->AddChild(tnchange2, labelsEmpty);
	pncpar2->AddChild(tnchange1, labelsEmpty);

	//now order the original tree before computing the Newick
	speciesTreeCur.Order();
	speciesTreeCur.ConsNewick(nwtreetmp);

	// now attach it back
	pncpar1->RemoveChild(tnchange2);
	pncpar2->RemoveChild(tnchange1);
	pncpar1->AddChild(tnchange1, labelsEmpty);
	pncpar2->AddChild(tnchange2, labelsEmpty);
}







//////////////////////////////////////////////////////////////////////////////////
//extern const double DEF_MIN_BRANCH_LEN;
//extern const double DEF_MAX_BRANCH_LEN;
const double DEF_MIN_BRANCH_LEN = 0.005;
const double DEF_MAX_BRANCH_LEN = 5.0;
extern double minRatioHillClimb;


SpeciesTreeExplorer :: SpeciesTreeExplorer( int ns, vector<PhylogenyTreeBasic *> &lgtp, const vector<int> &listMP, TaxaMapper &mapperTI ) 
: numSpecies(ns), listGeneTreePtrs(lgtp), listMultiplicity(listMP), mapperTaxaIds(mapperTI), fBrentMode(true), fOutputTreeHere(true)
{
	curLoglikeli = -1.0*HAP_MAX_INT;
	YW_ASSERT_INFO(listGeneTreePtrs.size() > 0, "Fail");

	// initialize
	minBranchLenHillClimb = DEF_MIN_BRANCH_LEN;
	maxBranchLenHillClimb = DEF_MAX_BRANCH_LEN;
	fExploreNeighorTrees = true;

	// other init
	numNewTreesExplored = 0;
}

SpeciesTreeExplorer :: ~SpeciesTreeExplorer()
{
    // nothing for now
}

// setup branch length range
void SpeciesTreeExplorer :: SetBranchLenRange(double minBL, double maxBL)
{
    //
    minBranchLenHillClimb = minBL;
    maxBranchLenHillClimb = maxBL;
}

// explore from a set of 
void SpeciesTreeExplorer :: ExploreFrom( const vector<string> &listNWTreesInit  )
{
#if 0
cout << "SpeciesTreeExplorer :: ExploreFrom\n";
for(int i=0; i<(int)listGeneTreePtrs.size(); ++i)
{
cout << "Gene tree: ";
string strNW;
listGeneTreePtrs[i]->ConsNewick(strNW);
cout << "gene tree: " << strNW << endl;
}
#endif
    
	// 
	for(int tr=0; tr<(int)listNWTreesInit.size(); ++tr)
	{
//cout << "SpeciesTreeExplorer: Exploring from initial tree: " << listNWTreesInit[tr] << endl;
		double initLoglikeli = -1.0*HAP_MAX_INT;
		ExploreFromOneTree(listNWTreesInit[tr] , true, initLoglikeli);
	}

    if( fOutputTreeHere == true )
    {
        // report some statistics
        cout << "Highest log likelihood of tree (found at tree space exploring) = " << GetCurBestLoglikeli() << endl;
        string nwST = bestSpciesMargTree.GetNewick();
    //cout << "(BEFORE conversion) The newick format of the inferred MLE species tree: \n" << nwST << endl;
        string nwSTConv = mapperTaxaIds.ConvIdStringWithOrigTaxa(nwST);
        cout << "The newick format of the inferred MLE species tree: " << nwSTConv << endl;

        cout << "Number of explored trees: " << numNewTreesExplored << endl;
    }
}


void SpeciesTreeExplorer :: ExploreFromOneTree(const string &treeNWInit, bool fEvaluateInit, double initLogLikeli)
{
	// explore the space of trees from a single starting tree
	// is this new (not explored already)?
	//if( processedNWTrees.find( treeNWInit) != processedNWTrees.end() )
	//{
	//	return;
	//}
	//processedNWTrees.insert(treeNWInit);
	//numNewTreesExplored++;
//if( fEvaluateInit == true )
//{
//cout << "Exploring from an initial tree: " << treeNWInit << endl;
//}
	// construct a phylogenetic tree and explore from it
	//PhylogenyTreeBasic treeToExplore;
	//treeToExplore.ConsOnNewick( strNWTree );
//#if 0
	// create a stack of tree/cur prob. Represent: is this tree needs to be evaluated or not (or just to explore the ngbrs);
	// the tree to explore and the current prob
	stack< pair<bool, pair<string, double> > > stackTreesToExplore;
	pair<string, double>  pp1(treeNWInit,  GetDummyWorseLoglikeli() );
	pair<bool, pair<string, double> > pp( true, pp1 );
	stackTreesToExplore.push(pp);

	while( stackTreesToExplore.empty() == false )
	{
		//
		pair<bool, pair<string, double> > ppcur = stackTreesToExplore.top();
		stackTreesToExplore.pop();

		double initLogLikeli = ppcur.second.second;
		if( ppcur.first == true)
		{
			// need to evaluate the prob
			double probOneTree = EvaluateOneTree(ppcur.second.first);
			initLogLikeli = probOneTree;
		}

		// done if we do not explore tree space neighbours
		if( fExploreNeighorTrees == false )
		{
			break;
		}

		// now evaluate its neighbours
		// now search its neighbourhood
		string strTreeNWNext;

		PhylogenyTreeBasic treeToExplore;
		treeToExplore.ConsOnNewick( ppcur.second.first );
		// find its ngbr
		NNINgbrTreesFinder nningbrFinder( treeToExplore );
		set<string> setNgbrNWTrees;
		nningbrFinder.Find( setNgbrNWTrees );
	//cout << "Size of ngbr trees: " << setNgbrNWTrees.size() << endl;
		for( set<string> :: iterator itt= setNgbrNWTrees.begin(); itt != setNgbrNWTrees.end(); ++itt )
		{
	//cout << "--- ngbr tree: " << *itt << endl;
			//stackCandidateTrees.push(*itt);
			double probNgbrTr = EvaluateOneTree(*itt);
			if( probNgbrTr > initLogLikeli )
			{
//cout << "--- ngbr tree: " << *itt << endl;
//cout << "************************** Prob improved by this tree to " << probNgbrTr << endl;
				initLogLikeli = probNgbrTr;
				strTreeNWNext = *itt;
			}
		}

		// continue if we find another good choice
		if( strTreeNWNext.length() > 0 )
		{
			//
			//ExploreFromOneTree( strTreeNWNext, false, initLogLikeli );
			pair<string, double>  pp2(strTreeNWNext,  initLogLikeli );
			pair<bool, pair<string, double> > pp3( false, pp2 );
			stackTreesToExplore.push(pp3);
		}	
	}
//#endif

}

double SpeciesTreeExplorer :: EvaluateOneTree(const string &treeNW)
{
	if( processedNWTrees.find( treeNW) != processedNWTrees.end() )
	{
		// simple just return a smaller value
		//return GetDummyWorseLoglikeli();
		return processedNWTrees[treeNW].first;
	}
	//processedNWTrees.insert(treeNW);
	numNewTreesExplored++;
//cout << "Exploring a new tree (in neighbourhood search): " << treeNW << endl;


	//
	MarginalTree mTree;
	ReadinMarginalTreesNewickWLenString( treeNW, GetNumSpecies(), mTree );
	//heuSTSampler.SampleBU(mTree);
	MarginalTree treePH1WLen = mTree;
	// init branch length of every edge to be 1.0
	const double DEFAULT_BRANCH_LEN = 1.0;
	for( int b=0; b<treePH1WLen.GetTotNodesNum()-1; ++b )
	{
		treePH1WLen.SetBranchLen(b, DEFAULT_BRANCH_LEN);
	}
    
//#if 0
    // create prob components
    vector<GenericGeneSpeciesTreeProb *> listGSTProbFinder;
    PreCreateListGTPComp(treePH1WLen, listGeneTreePtrs, listGSTProbFinder);
//#endif
    
	STBranchLenFinder blFinder(listGeneTreePtrs, treePH1WLen, minBranchLenHillClimb, maxBranchLenHillClimb );
//#if 0
    blFinder.SetGeneTreeProbComp( listGSTProbFinder );
//#endif
	blFinder.SetBrentMode( fBrentMode);
	blFinder.SetMultiplictyofTrees(listMultiplicity);
	// inform branch tree finder the current best likelihood, 
	// which may help to determine whether it is profitable to do more
	blFinder.SetKnownMaxLikeli(curLoglikeli);

//#if 0
	if( minRatioHillClimb > 0.0 )
	{
		blFinder.SetHillClimbRatioThres(minRatioHillClimb);
	}
//#endif		
	MarginalTree streeBLen;
	double probval = blFinder.HillClimbBranchLen(streeBLen);
//cout << "Best branch length finder gives: " << probval << endl;
//cout << "The resulting tree: ";
//streeBLen.Dump();
	//string nwST = streeBLen.GetNewick();
	//cout << "The newick format of the inferred species tree with branch length: " << nwST << endl;

	//if( t == 1 )
	//{
	//	mleTreeSearchProb = probval;
	//	mTreeMLE = streeBLen;
	//	lvOptRes = lv;
//cout << "Max prob. updated to " << probval << endl;
	//}
	if( curLoglikeli < probval )
	{
		curLoglikeli = probval;
		bestSpciesMargTree = streeBLen;
//cout << "Max log-likelihood updated to " << probval << endl;
	}
	// remember it
	pair<double,MarginalTree> tt(probval,streeBLen);
	processedNWTrees.insert(map<string,pair<double,MarginalTree> > :: value_type(treeNW, tt) );

	return probval;
}

static int QSortCompareDoubleIntPair( const void *arg1, const void *arg2 )
{
   /* Compare all of both strings: */
    // assume sorting in accending order, and use the first value in the int pair to sort
    double n1 = ((pair<double,int> *) arg1)->first;
    double n2 = ((pair<double,int> *) arg2)->first;
//cout <<"arg1 = " << n1 << ", arg2 = " << n2 << endl;
    if( n1 > n2)
    {
        return 1;
    }
    else if( n1 < n2)
    {
        return -1;
    }
    else 
    {
        return 0;
    }
}

void SpeciesTreeExplorer :: OutputNearOptTrees(string fileNameInit)
{
	// output near optimal trees
	string fileNameUse = fileNameInit + "-nearopt.trees";

	// find a list of near opt trees For this, iterate through the list of trees
	vector< pair<string, double> > listProcTreesProb;
	for( map<string,pair<double,MarginalTree> > :: iterator itt = processedNWTrees.begin(); itt != processedNWTrees.end(); ++itt )
	{
		pair<string,double> pp;
		pp.first = itt->second.second.GetNewick();
		pp.second = itt->second.first;
		listProcTreesProb.push_back( pp );
	}
	// create a vector for sorting
	pair<double,int> arraySortTreeIndProb[listProcTreesProb.size()];
	for(int t=0; t<(int)listProcTreesProb.size(); ++t)
	{
		arraySortTreeIndProb[t].first = listProcTreesProb[t].second;
		arraySortTreeIndProb[t].second = t;
	}
    qsort( (void *)arraySortTreeIndProb, listProcTreesProb.size(), sizeof( pair<double,int>  ), QSortCompareDoubleIntPair );

	// now output these trees from the end
	ofstream outFileProbs( fileNameUse.c_str() );
	if(!outFileProbs)
	{
		cout << "Can not open near optimal output file: "<< fileNameUse <<endl;
		exit(1);
	}

	int numTreeOut = 0;
	for(int t=(int)listProcTreesProb.size()-1; t>=0 && numTreeOut < numNearOptTreesKept; t--)
	{
		//
		numTreeOut ++;
		outFileProbs << "[" << listProcTreesProb[ arraySortTreeIndProb[t].second ].second << "]";
		string strTr = mapperTaxaIds.ConvIdStringWithOrigTaxa(listProcTreesProb[ arraySortTreeIndProb[t].second ].first);
		outFileProbs << strTr << ";\n";
	}

	outFileProbs.close();
}

string SpeciesTreeExplorer :: GetBestInfSpeicesTree() const
{
    //
    return bestSpciesMargTree.GetNewick();
}

void SpeciesTreeExplorer :: PreCreateListGTPComp( MarginalTree &treeSpec, vector<PhylogenyTreeBasic *> &listGeneTreePtrs, vector<GenericGeneSpeciesTreeProb *> &listGSTProbFinder )
{
//#if 0
    if( GetNumThreads() > 1 )
    {
        PreCreateListGTPCompMultithread( treeSpec, listGeneTreePtrs, listGSTProbFinder );
        return;
    }
//#endif
    // take simple approach for now
    for( int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr )
    {
        //
        GenericGeneSpeciesTreeProb *ptr = CreateGeneTreeProbComp(treeSpec, *(listGeneTreePtrs[tr]));
        listGSTProbFinder.push_back(ptr);
    }
}

typedef struct
{
    vector<PhylogenyTreeBasic *>listPtrGenetrees;
    int trStart;
    int trEnd;
    MarginalTree *ptrSpecTree;
    vector<GenericGeneSpeciesTreeProb *> listResProbComps;
} STProbInitThreadInfo;

static void *ThreadFuncProbInit(void *ptr)
{
    //
    STProbInitThreadInfo *ptinfo = (STProbInitThreadInfo *)ptr;
//cout << "Init with a thread: [" << ptinfo->trStart << "," << ptinfo->trEnd << "]\n";
    for(int tr=ptinfo->trStart; tr<=ptinfo->trEnd; ++tr)
    {
        GenericGeneSpeciesTreeProb *ptr = CreateGeneTreeProbComp(*ptinfo->ptrSpecTree, *ptinfo->listPtrGenetrees[tr]);
        ptinfo->listResProbComps.push_back( ptr );
    }
    return NULL;
}

void SpeciesTreeExplorer :: PreCreateListGTPCompMultithread( MarginalTree &treeSpec, vector<PhylogenyTreeBasic *> &listGeneTreePtrs, vector<GenericGeneSpeciesTreeProb *> &listGSTProbFinder )
{
    // create multiple threads for faster initialization
    
    // create all the thread for processing the trees by spliting the tasks evenly
    // init threads
    int numThreadsUse = GetNumThreads();
    // if not that many trees, reduce it
    if( numThreadsUse > (int) listGeneTreePtrs.size() )
    {
        //
        numThreadsUse = (int)listGeneTreePtrs.size();
    }
    
    pthread_t* pid = new pthread_t[numThreadsUse];
    STProbInitThreadInfo *pThreadInfo = new STProbInitThreadInfo[numThreadsUse];
    
    // start the threads
    int numTreesPerThread = (int)listGeneTreePtrs.size()/numThreadsUse;
    YW_ASSERT_INFO(numTreesPerThread>=1, "Must have at least one tree to process");
    int numLeftOver = (int)listGeneTreePtrs.size() - numThreadsUse * numTreesPerThread ;
    YW_ASSERT_INFO( numLeftOver >= 0, "Must be non-negative");
    int trCurToProc = 0;
    for(int i=0;i<numThreadsUse;++i)
    {
//cout << "Starting thread " << i << endl;
        // wait for all threads finishing
        pThreadInfo[i].trStart = trCurToProc;
        pThreadInfo[i].trEnd = trCurToProc + numTreesPerThread-1;
        trCurToProc += numTreesPerThread;
        // if there is leftover to do, add one more
        if( numLeftOver > 0 )
        {
            // add one more
            ++pThreadInfo[i].trEnd;
            ++trCurToProc;
            --numLeftOver;
        }
        pThreadInfo[i].listPtrGenetrees = listGeneTreePtrs;
        pThreadInfo[i].ptrSpecTree = &treeSpec;
        
        // start thread
        int ret = pthread_create(&pid[i], NULL, &ThreadFuncProbInit, (void *)&pThreadInfo[i]);
        if(ret)
        {
            cout << "Fatal error in creating pthread!" << endl;
            exit(1 );
        }
        
    }
    
    
    // free up resource
    for(int i=0;i<numThreadsUse;++i)
    {
        //wait for all threads finishing
        pthread_join(pid[i], NULL);
    }
    delete [] pid;
//cout << "Init finished.\n";;
    // collect results
    for( int i = 0; i<numThreadsUse; ++i )
    {
        for( int jj=0; jj<(int)pThreadInfo[i].listResProbComps.size(); ++jj)
        {
            listGSTProbFinder.push_back( pThreadInfo[i].listResProbComps[jj] );
        }
    }
    delete [] pThreadInfo;
}

